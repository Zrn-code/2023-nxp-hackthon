/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Page_Reserve(lv_ui *ui)
{
	//Write codes Page_Reserve
	ui->Page_Reserve = lv_obj_create(NULL);
	lv_obj_set_size(ui->Page_Reserve, 480, 272);

	//Write style for Page_Reserve, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_Reserve, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Reserve, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Reserve_contBG
	ui->Page_Reserve_contBG = lv_obj_create(ui->Page_Reserve);
	lv_obj_set_pos(ui->Page_Reserve_contBG, 0, 0);
	lv_obj_set_size(ui->Page_Reserve_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Page_Reserve_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Page_Reserve_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Reserve_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Reserve_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Reserve_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Reserve_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Reserve_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Reserve_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Reserve_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Reserve_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Reserve_text_title
	ui->Page_Reserve_text_title = lv_label_create(ui->Page_Reserve);
	lv_label_set_text(ui->Page_Reserve_text_title, "Choose Mode");
	lv_label_set_long_mode(ui->Page_Reserve_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_Reserve_text_title, 135, 23);
	lv_obj_set_size(ui->Page_Reserve_text_title, 210, 32);

	//Write style for Page_Reserve_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Reserve_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Reserve_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Reserve_BUT_back
	ui->Page_Reserve_BUT_back = lv_btn_create(ui->Page_Reserve);
	ui->Page_Reserve_BUT_back_label = lv_label_create(ui->Page_Reserve_BUT_back);
	lv_label_set_text(ui->Page_Reserve_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Page_Reserve_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_Reserve_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_Reserve_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_Reserve_BUT_back, 25, 17);
	lv_obj_set_size(ui->Page_Reserve_BUT_back, 35, 32);

	//Write style for Page_Reserve_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_Reserve_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Reserve_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Reserve_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Reserve_BUT_store
	ui->Page_Reserve_BUT_store = lv_imgbtn_create(ui->Page_Reserve);
	lv_obj_add_flag(ui->Page_Reserve_BUT_store, LV_OBJ_FLAG_CHECKABLE);
	lv_imgbtn_set_src(ui->Page_Reserve_BUT_store, LV_IMGBTN_STATE_RELEASED, NULL, &_package_alpha_102x89, NULL);
	ui->Page_Reserve_BUT_store_label = lv_label_create(ui->Page_Reserve_BUT_store);
	lv_label_set_text(ui->Page_Reserve_BUT_store_label, "");
	lv_label_set_long_mode(ui->Page_Reserve_BUT_store_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_Reserve_BUT_store_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_Reserve_BUT_store, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_Reserve_BUT_store, 33, 111);
	lv_obj_set_size(ui->Page_Reserve_BUT_store, 102, 89);

	//Write style for Page_Reserve_BUT_store, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_store, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_store, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_BUT_store, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Reserve_BUT_store, Part: LV_PART_MAIN, State: LV_STATE_PRESSED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_store, 255, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_store, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_store, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_store, 0, LV_PART_MAIN|LV_STATE_PRESSED);

	//Write style for Page_Reserve_BUT_store, Part: LV_PART_MAIN, State: LV_STATE_CHECKED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_store, 255, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_store, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_store, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_store, 0, LV_PART_MAIN|LV_STATE_CHECKED);

	//Write style for Page_Reserve_BUT_store, Part: LV_PART_MAIN, State: LV_IMGBTN_STATE_RELEASED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_store, 255, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);

	//Write codes Page_Reserve_text_store
	ui->Page_Reserve_text_store = lv_label_create(ui->Page_Reserve);
	lv_label_set_text(ui->Page_Reserve_text_store, "store\n");
	lv_label_set_long_mode(ui->Page_Reserve_text_store, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_Reserve_text_store, 27, 211);
	lv_obj_set_size(ui->Page_Reserve_text_store, 108, 14);

	//Write style for Page_Reserve_text_store, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Reserve_text_store, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_text_store, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Reserve_text_store, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_text_store, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_text_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Reserve_BUT_take
	ui->Page_Reserve_BUT_take = lv_imgbtn_create(ui->Page_Reserve);
	lv_obj_add_flag(ui->Page_Reserve_BUT_take, LV_OBJ_FLAG_CHECKABLE);
	lv_imgbtn_set_src(ui->Page_Reserve_BUT_take, LV_IMGBTN_STATE_RELEASED, NULL, &_takeaway_alpha_105x110, NULL);
	ui->Page_Reserve_BUT_take_label = lv_label_create(ui->Page_Reserve_BUT_take);
	lv_label_set_text(ui->Page_Reserve_BUT_take_label, "");
	lv_label_set_long_mode(ui->Page_Reserve_BUT_take_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_Reserve_BUT_take_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_Reserve_BUT_take, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_Reserve_BUT_take, 188, 90);
	lv_obj_set_size(ui->Page_Reserve_BUT_take, 105, 110);

	//Write style for Page_Reserve_BUT_take, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_take, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_take, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_BUT_take, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Reserve_BUT_take, Part: LV_PART_MAIN, State: LV_STATE_PRESSED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_take, 255, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_take, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_take, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_take, 0, LV_PART_MAIN|LV_STATE_PRESSED);

	//Write style for Page_Reserve_BUT_take, Part: LV_PART_MAIN, State: LV_STATE_CHECKED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_take, 255, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_take, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_take, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_take, 0, LV_PART_MAIN|LV_STATE_CHECKED);

	//Write style for Page_Reserve_BUT_take, Part: LV_PART_MAIN, State: LV_IMGBTN_STATE_RELEASED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_take, 255, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);

	//Write codes Page_Reserve_text_take
	ui->Page_Reserve_text_take = lv_label_create(ui->Page_Reserve);
	lv_label_set_text(ui->Page_Reserve_text_take, "Take\n");
	lv_label_set_long_mode(ui->Page_Reserve_text_take, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_Reserve_text_take, 217, 209);
	lv_obj_set_size(ui->Page_Reserve_text_take, 47, 16);

	//Write style for Page_Reserve_text_take, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Reserve_text_take, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_text_take, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Reserve_text_take, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_text_take, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Reserve_BUT_storage
	ui->Page_Reserve_BUT_storage = lv_imgbtn_create(ui->Page_Reserve);
	lv_obj_add_flag(ui->Page_Reserve_BUT_storage, LV_OBJ_FLAG_CHECKABLE);
	lv_imgbtn_set_src(ui->Page_Reserve_BUT_storage, LV_IMGBTN_STATE_RELEASED, NULL, &_warehouse_alpha_105x90, NULL);
	ui->Page_Reserve_BUT_storage_label = lv_label_create(ui->Page_Reserve_BUT_storage);
	lv_label_set_text(ui->Page_Reserve_BUT_storage_label, "");
	lv_label_set_long_mode(ui->Page_Reserve_BUT_storage_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_Reserve_BUT_storage_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_Reserve_BUT_storage, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_Reserve_BUT_storage, 345, 110);
	lv_obj_set_size(ui->Page_Reserve_BUT_storage, 105, 90);

	//Write style for Page_Reserve_BUT_storage, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_storage, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_storage, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_BUT_storage, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Reserve_BUT_storage, Part: LV_PART_MAIN, State: LV_STATE_PRESSED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_storage, 255, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_storage, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_storage, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_storage, 0, LV_PART_MAIN|LV_STATE_PRESSED);

	//Write style for Page_Reserve_BUT_storage, Part: LV_PART_MAIN, State: LV_STATE_CHECKED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_storage, 255, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_color(ui->Page_Reserve_BUT_storage, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_font(ui->Page_Reserve_BUT_storage, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_BUT_storage, 0, LV_PART_MAIN|LV_STATE_CHECKED);

	//Write style for Page_Reserve_BUT_storage, Part: LV_PART_MAIN, State: LV_IMGBTN_STATE_RELEASED.
	lv_obj_set_style_img_opa(ui->Page_Reserve_BUT_storage, 255, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);

	//Write codes Page_Reserve_text_storage
	ui->Page_Reserve_text_storage = lv_label_create(ui->Page_Reserve);
	lv_label_set_text(ui->Page_Reserve_text_storage, "Storage");
	lv_label_set_long_mode(ui->Page_Reserve_text_storage, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_Reserve_text_storage, 350, 209);
	lv_obj_set_size(ui->Page_Reserve_text_storage, 100, 32);

	//Write style for Page_Reserve_text_storage, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Reserve_text_storage, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Reserve_text_storage, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Reserve_text_storage, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Reserve_text_storage, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Reserve_text_storage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Page_Reserve);

	
	//Init events for screen.
	events_init_Page_Reserve(ui);
}
