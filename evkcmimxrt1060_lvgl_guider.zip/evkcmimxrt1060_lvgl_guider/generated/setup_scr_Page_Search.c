/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Page_Search(lv_ui *ui)
{
	//Write codes Page_Search
	ui->Page_Search = lv_obj_create(NULL);
	lv_obj_set_size(ui->Page_Search, 480, 272);

	//Write style for Page_Search, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_Search, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Search_contBG
	ui->Page_Search_contBG = lv_obj_create(ui->Page_Search);
	lv_obj_set_pos(ui->Page_Search_contBG, 0, 0);
	lv_obj_set_size(ui->Page_Search_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Page_Search_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Page_Search_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Search_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Search_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Search_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Search_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Search_text_title
	ui->Page_Search_text_title = lv_label_create(ui->Page_Search);
	lv_label_set_text(ui->Page_Search_text_title, "Search Medicine");
	lv_label_set_long_mode(ui->Page_Search_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_Search_text_title, 135, 23);
	lv_obj_set_size(ui->Page_Search_text_title, 210, 32);

	//Write style for Page_Search_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Search_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Search_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Search_text_syptoms
	ui->Page_Search_text_syptoms = lv_label_create(ui->Page_Search);
	lv_label_set_text(ui->Page_Search_text_syptoms, "Syptoms:");
	lv_label_set_long_mode(ui->Page_Search_text_syptoms, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_Search_text_syptoms, 10, 67);
	lv_obj_set_size(ui->Page_Search_text_syptoms, 113, 26);

	//Write style for Page_Search_text_syptoms, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Search_text_syptoms, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_text_syptoms, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Search_text_syptoms, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_text_syptoms, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_runningnose
	ui->Page_Search_cb_runningnose = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_runningnose, "running nose");
	lv_obj_set_pos(ui->Page_Search_cb_runningnose, 39, 126);

	//Write style for Page_Search_cb_runningnose, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_runningnose, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_runningnose, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_runningnose, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_runningnose, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_runningnose, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_runningnose, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_runningnose, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_runningnose, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_runningnose, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_runningnose, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_runningnose, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_runningnose, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_runningnose, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_runningnose, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_runningnose, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_runningnose, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_headache
	ui->Page_Search_cb_headache = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_headache, "headache");
	lv_obj_set_pos(ui->Page_Search_cb_headache, 39, 93);

	//Write style for Page_Search_cb_headache, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_headache, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_headache, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_headache, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_headache, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_headache, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_headache, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_headache, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_headache, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_headache, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_headache, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_headache, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_headache, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_headache, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_headache, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_headache, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_headache, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_sorethroat
	ui->Page_Search_cb_sorethroat = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_sorethroat, "sore throat");
	lv_obj_set_pos(ui->Page_Search_cb_sorethroat, 39, 157);

	//Write style for Page_Search_cb_sorethroat, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_sorethroat, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_sorethroat, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_sorethroat, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_sorethroat, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_sorethroat, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_sorethroat, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_sorethroat, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_sorethroat, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_sorethroat, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_sorethroat, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_sorethroat, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_sorethroat, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_sorethroat, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_sorethroat, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_sorethroat, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_sorethroat, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_muscleaches
	ui->Page_Search_cb_muscleaches = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_muscleaches, "muscle aches");
	lv_obj_set_pos(ui->Page_Search_cb_muscleaches, 39, 187);

	//Write style for Page_Search_cb_muscleaches, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_muscleaches, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_muscleaches, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_muscleaches, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_muscleaches, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_muscleaches, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_muscleaches, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_muscleaches, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_muscleaches, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_muscleaches, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_muscleaches, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_muscleaches, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_muscleaches, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_muscleaches, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_muscleaches, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_muscleaches, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_muscleaches, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_cough
	ui->Page_Search_cb_cough = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_cough, "cough");
	lv_obj_set_pos(ui->Page_Search_cb_cough, 178, 93);

	//Write style for Page_Search_cb_cough, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_cough, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_cough, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_cough, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_cough, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_cough, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_cough, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_cough, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_cough, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_cough, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_cough, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_cough, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_cough, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_cough, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_cough, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_cough, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_cough, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_fever
	ui->Page_Search_cb_fever = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_fever, "fever");
	lv_obj_set_pos(ui->Page_Search_cb_fever, 178, 126);

	//Write style for Page_Search_cb_fever, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_fever, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_fever, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_fever, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_fever, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_fever, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_fever, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_fever, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_fever, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_fever, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_fever, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_fever, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_fever, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_fever, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_fever, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_fever, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_fever, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_losstaste
	ui->Page_Search_cb_losstaste = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_losstaste, "loss of taste");
	lv_obj_set_pos(ui->Page_Search_cb_losstaste, 178, 157);

	//Write style for Page_Search_cb_losstaste, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_losstaste, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_losstaste, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_losstaste, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_losstaste, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_losstaste, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_losstaste, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_losstaste, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_losstaste, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_losstaste, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_losstaste, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_losstaste, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_losstaste, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_losstaste, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_losstaste, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_losstaste, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_losstaste, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_diarrhea
	ui->Page_Search_cb_diarrhea = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_diarrhea, "diarrhea");
	lv_obj_set_pos(ui->Page_Search_cb_diarrhea, 178, 187);

	//Write style for Page_Search_cb_diarrhea, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_diarrhea, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_diarrhea, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_diarrhea, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_diarrhea, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_diarrhea, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_diarrhea, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_diarrhea, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_diarrhea, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_diarrhea, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_diarrhea, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_diarrhea, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_diarrhea, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_diarrhea, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_diarrhea, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_diarrhea, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_diarrhea, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_stomachache
	ui->Page_Search_cb_stomachache = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_stomachache, "stomachache");
	lv_obj_set_pos(ui->Page_Search_cb_stomachache, 317, 93);

	//Write style for Page_Search_cb_stomachache, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_stomachache, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_stomachache, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_stomachache, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_stomachache, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_stomachache, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_stomachache, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_stomachache, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_stomachache, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_stomachache, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_stomachache, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_stomachache, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_stomachache, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_stomachache, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_stomachache, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_stomachache, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_stomachache, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_drowsiness
	ui->Page_Search_cb_drowsiness = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_drowsiness, "drowsiness");
	lv_obj_set_pos(ui->Page_Search_cb_drowsiness, 317, 126);

	//Write style for Page_Search_cb_drowsiness, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_drowsiness, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_drowsiness, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_drowsiness, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_drowsiness, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_drowsiness, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_drowsiness, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_drowsiness, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_drowsiness, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_drowsiness, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_drowsiness, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_drowsiness, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_drowsiness, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_drowsiness, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_drowsiness, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_drowsiness, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_drowsiness, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_chestpain
	ui->Page_Search_cb_chestpain = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_chestpain, "chest pain");
	lv_obj_set_pos(ui->Page_Search_cb_chestpain, 317, 157);

	//Write style for Page_Search_cb_chestpain, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_chestpain, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_chestpain, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_chestpain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_chestpain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_chestpain, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_chestpain, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_chestpain, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_chestpain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_chestpain, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_chestpain, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_chestpain, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_chestpain, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_chestpain, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_chestpain, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_chestpain, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_chestpain, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_cb_Nausea
	ui->Page_Search_cb_Nausea = lv_checkbox_create(ui->Page_Search);
	lv_checkbox_set_text(ui->Page_Search_cb_Nausea, "Nausea");
	lv_obj_set_pos(ui->Page_Search_cb_Nausea, 317, 187);

	//Write style for Page_Search_cb_Nausea, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_Search_cb_Nausea, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_cb_Nausea, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_Search_cb_Nausea, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_cb_Nausea, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_Nausea, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_Nausea, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_Nausea, lv_color_hex(0xC2D9FF), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_cb_Nausea, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Page_Search_cb_Nausea, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_Search_cb_Nausea, 2, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_Search_cb_Nausea, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_Search_cb_Nausea, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_Search_cb_Nausea, LV_BORDER_SIDE_FULL, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_cb_Nausea, 6, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_Search_cb_Nausea, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_cb_Nausea, lv_color_hex(0xffffff), LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write codes Page_Search_BUT_Next
	ui->Page_Search_BUT_Next = lv_btn_create(ui->Page_Search);
	ui->Page_Search_BUT_Next_label = lv_label_create(ui->Page_Search_BUT_Next);
	lv_label_set_text(ui->Page_Search_BUT_Next_label, "NEXT");
	lv_label_set_long_mode(ui->Page_Search_BUT_Next_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_Search_BUT_Next_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_Search_BUT_Next, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_Search_BUT_Next, 366, 224);
	lv_obj_set_size(ui->Page_Search_BUT_Next, 100, 37);

	//Write style for Page_Search_BUT_Next, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_Search_BUT_Next, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_Search_BUT_Next, lv_color_hex(0x0506a0), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_BUT_Next, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_BUT_Next, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_BUT_Next, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Search_BUT_Next, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_BUT_Next, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Search_BUT_Next, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_Search_BUT_back
	ui->Page_Search_BUT_back = lv_btn_create(ui->Page_Search);
	ui->Page_Search_BUT_back_label = lv_label_create(ui->Page_Search_BUT_back);
	lv_label_set_text(ui->Page_Search_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Page_Search_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_Search_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_Search_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_Search_BUT_back, 25, 17);
	lv_obj_set_size(ui->Page_Search_BUT_back, 35, 32);

	//Write style for Page_Search_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_Search_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_Search_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_Search_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_Search_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_Search_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_Search_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_Search_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Page_Search);

	
	//Init events for screen.
	events_init_Page_Search(ui);
}
