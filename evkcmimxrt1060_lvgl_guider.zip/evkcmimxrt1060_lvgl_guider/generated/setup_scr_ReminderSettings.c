/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_ReminderSettings(lv_ui *ui)
{
	//Write codes ReminderSettings
	ui->ReminderSettings = lv_obj_create(NULL);
	lv_obj_set_size(ui->ReminderSettings, 480, 272);

	//Write style for ReminderSettings, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_contBG
	ui->ReminderSettings_contBG = lv_obj_create(ui->ReminderSettings);
	lv_obj_set_pos(ui->ReminderSettings_contBG, 0, 0);
	lv_obj_set_size(ui->ReminderSettings_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->ReminderSettings_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for ReminderSettings_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->ReminderSettings_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->ReminderSettings_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->ReminderSettings_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->ReminderSettings_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->ReminderSettings_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->ReminderSettings_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_BUT_back2
	ui->ReminderSettings_BUT_back2 = lv_btn_create(ui->ReminderSettings_contBG);
	ui->ReminderSettings_BUT_back2_label = lv_label_create(ui->ReminderSettings_BUT_back2);
	lv_label_set_text(ui->ReminderSettings_BUT_back2_label, "<");
	lv_label_set_long_mode(ui->ReminderSettings_BUT_back2_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->ReminderSettings_BUT_back2_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->ReminderSettings_BUT_back2, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->ReminderSettings_BUT_back2, 24, 17);
	lv_obj_set_size(ui->ReminderSettings_BUT_back2, 35, 32);

	//Write style for ReminderSettings_BUT_back2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->ReminderSettings_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_BUT_back2, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->ReminderSettings_BUT_back2, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->ReminderSettings_BUT_back2, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->ReminderSettings_BUT_back2, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_text_title
	ui->ReminderSettings_text_title = lv_label_create(ui->ReminderSettings_contBG);
	lv_label_set_text(ui->ReminderSettings_text_title, "Reminder Settings");
	lv_label_set_long_mode(ui->ReminderSettings_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->ReminderSettings_text_title, 79, 22);
	lv_obj_set_size(ui->ReminderSettings_text_title, 323, 32);

	//Write style for ReminderSettings_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->ReminderSettings_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->ReminderSettings_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->ReminderSettings_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_BUT_back
	ui->ReminderSettings_BUT_back = lv_btn_create(ui->ReminderSettings);
	ui->ReminderSettings_BUT_back_label = lv_label_create(ui->ReminderSettings_BUT_back);
	lv_label_set_text(ui->ReminderSettings_BUT_back_label, "Save");
	lv_label_set_long_mode(ui->ReminderSettings_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->ReminderSettings_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->ReminderSettings_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->ReminderSettings_BUT_back, 366, 224);
	lv_obj_set_size(ui->ReminderSettings_BUT_back, 100, 37);

	//Write style for ReminderSettings_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_BUT_back, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_BUT_back, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->ReminderSettings_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_BUT_back, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->ReminderSettings_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->ReminderSettings_BUT_back, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->ReminderSettings_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_text_frequency
	ui->ReminderSettings_text_frequency = lv_label_create(ui->ReminderSettings);
	lv_label_set_text(ui->ReminderSettings_text_frequency, "Frequency");
	lv_label_set_long_mode(ui->ReminderSettings_text_frequency, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->ReminderSettings_text_frequency, 62, 184);
	lv_obj_set_size(ui->ReminderSettings_text_frequency, 112, 20);

	//Write style for ReminderSettings_text_frequency, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->ReminderSettings_text_frequency, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->ReminderSettings_text_frequency, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->ReminderSettings_text_frequency, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_text_frequency, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_text_volume
	ui->ReminderSettings_text_volume = lv_label_create(ui->ReminderSettings);
	lv_label_set_text(ui->ReminderSettings_text_volume, "Volume");
	lv_label_set_long_mode(ui->ReminderSettings_text_volume, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->ReminderSettings_text_volume, 74, 146);
	lv_obj_set_size(ui->ReminderSettings_text_volume, 100, 32);

	//Write style for ReminderSettings_text_volume, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->ReminderSettings_text_volume, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->ReminderSettings_text_volume, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->ReminderSettings_text_volume, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_text_volume, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_text_offon
	ui->ReminderSettings_text_offon = lv_label_create(ui->ReminderSettings);
	lv_label_set_text(ui->ReminderSettings_text_offon, "Off / On");
	lv_label_set_long_mode(ui->ReminderSettings_text_offon, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->ReminderSettings_text_offon, 74, 106);
	lv_obj_set_size(ui->ReminderSettings_text_offon, 100, 32);

	//Write style for ReminderSettings_text_offon, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->ReminderSettings_text_offon, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->ReminderSettings_text_offon, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->ReminderSettings_text_offon, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_text_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_INPUT_Slider_freq
	ui->ReminderSettings_INPUT_Slider_freq = lv_slider_create(ui->ReminderSettings);
	lv_slider_set_range(ui->ReminderSettings_INPUT_Slider_freq, 0, 100);
	lv_slider_set_mode(ui->ReminderSettings_INPUT_Slider_freq, LV_SLIDER_MODE_NORMAL);
	lv_slider_set_value(ui->ReminderSettings_INPUT_Slider_freq, 50, LV_ANIM_OFF);
	lv_obj_set_pos(ui->ReminderSettings_INPUT_Slider_freq, 196, 190);
	lv_obj_set_size(ui->ReminderSettings_INPUT_Slider_freq, 160, 8);

	//Write style for ReminderSettings_INPUT_Slider_freq, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_Slider_freq, 60, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_Slider_freq, lv_color_hex(0x2195f6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_Slider_freq, 50, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->ReminderSettings_INPUT_Slider_freq, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_INPUT_Slider_freq, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for ReminderSettings_INPUT_Slider_freq, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_Slider_freq, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_Slider_freq, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_Slider_freq, 50, LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write style for ReminderSettings_INPUT_Slider_freq, Part: LV_PART_KNOB, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_Slider_freq, 255, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_Slider_freq, lv_color_hex(0x2195f6), LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_Slider_freq, 50, LV_PART_KNOB|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_INPUT_Slider_Vol
	ui->ReminderSettings_INPUT_Slider_Vol = lv_slider_create(ui->ReminderSettings);
	lv_slider_set_range(ui->ReminderSettings_INPUT_Slider_Vol, 0, 100);
	lv_slider_set_mode(ui->ReminderSettings_INPUT_Slider_Vol, LV_SLIDER_MODE_NORMAL);
	lv_slider_set_value(ui->ReminderSettings_INPUT_Slider_Vol, 50, LV_ANIM_OFF);
	lv_obj_set_pos(ui->ReminderSettings_INPUT_Slider_Vol, 196, 152);
	lv_obj_set_size(ui->ReminderSettings_INPUT_Slider_Vol, 160, 8);

	//Write style for ReminderSettings_INPUT_Slider_Vol, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_Slider_Vol, 60, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_Slider_Vol, lv_color_hex(0x2195f6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_Slider_Vol, 50, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->ReminderSettings_INPUT_Slider_Vol, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_INPUT_Slider_Vol, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for ReminderSettings_INPUT_Slider_Vol, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_Slider_Vol, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_Slider_Vol, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_Slider_Vol, 50, LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write style for ReminderSettings_INPUT_Slider_Vol, Part: LV_PART_KNOB, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_Slider_Vol, 255, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_Slider_Vol, lv_color_hex(0x2195f6), LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_Slider_Vol, 50, LV_PART_KNOB|LV_STATE_DEFAULT);

	//Write codes ReminderSettings_INPUT_SW_offon
	ui->ReminderSettings_INPUT_SW_offon = lv_switch_create(ui->ReminderSettings);
	lv_obj_set_pos(ui->ReminderSettings_INPUT_SW_offon, 256, 106);
	lv_obj_set_size(ui->ReminderSettings_INPUT_SW_offon, 40, 20);

	//Write style for ReminderSettings_INPUT_SW_offon, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_SW_offon, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_SW_offon, lv_color_hex(0xe6e2e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->ReminderSettings_INPUT_SW_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_SW_offon, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->ReminderSettings_INPUT_SW_offon, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for ReminderSettings_INPUT_SW_offon, Part: LV_PART_INDICATOR, State: LV_STATE_CHECKED.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_SW_offon, 255, LV_PART_INDICATOR|LV_STATE_CHECKED);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_SW_offon, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_CHECKED);
	lv_obj_set_style_border_width(ui->ReminderSettings_INPUT_SW_offon, 0, LV_PART_INDICATOR|LV_STATE_CHECKED);

	//Write style for ReminderSettings_INPUT_SW_offon, Part: LV_PART_KNOB, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->ReminderSettings_INPUT_SW_offon, 255, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->ReminderSettings_INPUT_SW_offon, lv_color_hex(0xffffff), LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->ReminderSettings_INPUT_SW_offon, 0, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->ReminderSettings_INPUT_SW_offon, 10, LV_PART_KNOB|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->ReminderSettings);

	
	//Init events for screen.
	events_init_ReminderSettings(ui);
}
