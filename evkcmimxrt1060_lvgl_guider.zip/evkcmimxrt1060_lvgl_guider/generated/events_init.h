/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/


#ifndef EVENTS_INIT_H_
#define EVENTS_INIT_H_
#ifdef __cplusplus
extern "C" {
#endif

#include "gui_guider.h"

void events_init(lv_ui *ui);

void events_init_Home(lv_ui *ui);
void events_init_Video(lv_ui *ui);
void events_init_Page_Reserve(lv_ui *ui);
void events_init_Reserve_Storeby(lv_ui *ui);
void events_init_Reverse_Camera(lv_ui *ui);
void events_init_Reserve_Manual(lv_ui *ui);
void events_init_Reserve_Take(lv_ui *ui);
void events_init_Reserve_Storage(lv_ui *ui);
void events_init_Page_Search(lv_ui *ui);
void events_init_Search_reccomend(lv_ui *ui);
void events_init_Page_History(lv_ui *ui);
void events_init_Page_Remind(lv_ui *ui);
void events_init_Remind_delete(lv_ui *ui);
void events_init_Page_settings(lv_ui *ui);
void events_init_Networksetting(lv_ui *ui);
void events_init_ReminderSettings(lv_ui *ui);
void events_init_MemberManagement(lv_ui *ui);
void events_init_AddMember(lv_ui *ui);
void events_init_Modifymember(lv_ui *ui);

#ifdef __cplusplus
}
#endif
#endif /* EVENT_CB_H_ */
