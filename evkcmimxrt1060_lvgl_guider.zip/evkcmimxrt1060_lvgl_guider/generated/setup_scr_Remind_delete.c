/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Remind_delete(lv_ui *ui)
{
	//Write codes Remind_delete
	ui->Remind_delete = lv_obj_create(NULL);
	lv_obj_set_size(ui->Remind_delete, 480, 272);

	//Write style for Remind_delete, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Remind_delete, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Remind_delete, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Remind_delete_contBG
	ui->Remind_delete_contBG = lv_obj_create(ui->Remind_delete);
	lv_obj_set_pos(ui->Remind_delete_contBG, 0, 0);
	lv_obj_set_size(ui->Remind_delete_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Remind_delete_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Remind_delete_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Remind_delete_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Remind_delete_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Remind_delete_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Remind_delete_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Remind_delete_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Remind_delete_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Remind_delete_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Remind_delete_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Remind_delete_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Remind_delete_BUT_back2
	ui->Remind_delete_BUT_back2 = lv_btn_create(ui->Remind_delete_contBG);
	ui->Remind_delete_BUT_back2_label = lv_label_create(ui->Remind_delete_BUT_back2);
	lv_label_set_text(ui->Remind_delete_BUT_back2_label, "<");
	lv_label_set_long_mode(ui->Remind_delete_BUT_back2_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Remind_delete_BUT_back2_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Remind_delete_BUT_back2, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Remind_delete_BUT_back2, 24, 17);
	lv_obj_set_size(ui->Remind_delete_BUT_back2, 35, 32);

	//Write style for Remind_delete_BUT_back2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Remind_delete_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Remind_delete_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Remind_delete_BUT_back2, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Remind_delete_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Remind_delete_BUT_back2, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Remind_delete_BUT_back2, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Remind_delete_BUT_back2, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Remind_delete_label_1
	ui->Remind_delete_label_1 = lv_label_create(ui->Remind_delete_contBG);
	lv_label_set_text(ui->Remind_delete_label_1, "Delete Reminder");
	lv_label_set_long_mode(ui->Remind_delete_label_1, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Remind_delete_label_1, 79, 22);
	lv_obj_set_size(ui->Remind_delete_label_1, 323, 32);

	//Write style for Remind_delete_label_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Remind_delete_label_1, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Remind_delete_label_1, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Remind_delete_label_1, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Remind_delete_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Remind_delete_ddlist_1
	ui->Remind_delete_ddlist_1 = lv_dropdown_create(ui->Remind_delete);
	lv_dropdown_set_options(ui->Remind_delete_ddlist_1, "");
	lv_obj_set_pos(ui->Remind_delete_ddlist_1, 74, 115);
	lv_obj_set_size(ui->Remind_delete_ddlist_1, 216, 42);

	//Write style for Remind_delete_ddlist_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Remind_delete_ddlist_1, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Remind_delete_ddlist_1, &lv_font_montserratMedium_24, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Remind_delete_ddlist_1, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Remind_delete_ddlist_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Remind_delete_ddlist_1, lv_color_hex(0xe1e6ee), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Remind_delete_ddlist_1, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Remind_delete_ddlist_1, 8, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Remind_delete_ddlist_1, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Remind_delete_ddlist_1, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Remind_delete_ddlist_1, 3, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Remind_delete_ddlist_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Remind_delete_ddlist_1, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Remind_delete_ddlist_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_CHECKED for &style_Remind_delete_ddlist_1_extra_list_selected_checked
	static lv_style_t style_Remind_delete_ddlist_1_extra_list_selected_checked;
	ui_init_style(&style_Remind_delete_ddlist_1_extra_list_selected_checked);
	
	lv_style_set_text_color(&style_Remind_delete_ddlist_1_extra_list_selected_checked, lv_color_hex(0xffffff));
	lv_style_set_text_font(&style_Remind_delete_ddlist_1_extra_list_selected_checked, &lv_font_montserratMedium_15);
	lv_style_set_border_width(&style_Remind_delete_ddlist_1_extra_list_selected_checked, 1);
	lv_style_set_border_opa(&style_Remind_delete_ddlist_1_extra_list_selected_checked, 255);
	lv_style_set_border_color(&style_Remind_delete_ddlist_1_extra_list_selected_checked, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Remind_delete_ddlist_1_extra_list_selected_checked, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Remind_delete_ddlist_1_extra_list_selected_checked, 3);
	lv_style_set_bg_opa(&style_Remind_delete_ddlist_1_extra_list_selected_checked, 255);
	lv_style_set_bg_color(&style_Remind_delete_ddlist_1_extra_list_selected_checked, lv_color_hex(0x00a1b5));
	lv_obj_add_style(lv_dropdown_get_list(ui->Remind_delete_ddlist_1), &style_Remind_delete_ddlist_1_extra_list_selected_checked, LV_PART_SELECTED|LV_STATE_CHECKED);

	//Write style state: LV_STATE_DEFAULT for &style_Remind_delete_ddlist_1_extra_list_main_default
	static lv_style_t style_Remind_delete_ddlist_1_extra_list_main_default;
	ui_init_style(&style_Remind_delete_ddlist_1_extra_list_main_default);
	
	lv_style_set_max_height(&style_Remind_delete_ddlist_1_extra_list_main_default, 90);
	lv_style_set_text_color(&style_Remind_delete_ddlist_1_extra_list_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Remind_delete_ddlist_1_extra_list_main_default, &lv_font_montserratMedium_15);
	lv_style_set_border_width(&style_Remind_delete_ddlist_1_extra_list_main_default, 1);
	lv_style_set_border_opa(&style_Remind_delete_ddlist_1_extra_list_main_default, 255);
	lv_style_set_border_color(&style_Remind_delete_ddlist_1_extra_list_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Remind_delete_ddlist_1_extra_list_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Remind_delete_ddlist_1_extra_list_main_default, 3);
	lv_style_set_bg_opa(&style_Remind_delete_ddlist_1_extra_list_main_default, 255);
	lv_style_set_bg_color(&style_Remind_delete_ddlist_1_extra_list_main_default, lv_color_hex(0xffffff));
	lv_obj_add_style(lv_dropdown_get_list(ui->Remind_delete_ddlist_1), &style_Remind_delete_ddlist_1_extra_list_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Remind_delete_ddlist_1_extra_list_scrollbar_default
	static lv_style_t style_Remind_delete_ddlist_1_extra_list_scrollbar_default;
	ui_init_style(&style_Remind_delete_ddlist_1_extra_list_scrollbar_default);
	
	lv_style_set_radius(&style_Remind_delete_ddlist_1_extra_list_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Remind_delete_ddlist_1_extra_list_scrollbar_default, 255);
	lv_style_set_bg_color(&style_Remind_delete_ddlist_1_extra_list_scrollbar_default, lv_color_hex(0x190482));
	lv_obj_add_style(lv_dropdown_get_list(ui->Remind_delete_ddlist_1), &style_Remind_delete_ddlist_1_extra_list_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Remind_delete_BUT_back
	ui->Remind_delete_BUT_back = lv_btn_create(ui->Remind_delete);
	ui->Remind_delete_BUT_back_label = lv_label_create(ui->Remind_delete_BUT_back);
	lv_label_set_text(ui->Remind_delete_BUT_back_label, "OK");
	lv_label_set_long_mode(ui->Remind_delete_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Remind_delete_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Remind_delete_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Remind_delete_BUT_back, 392, 216);
	lv_obj_set_size(ui->Remind_delete_BUT_back, 71, 37);

	//Write style for Remind_delete_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Remind_delete_BUT_back, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Remind_delete_BUT_back, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Remind_delete_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Remind_delete_BUT_back, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Remind_delete_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Remind_delete_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Remind_delete_BUT_back, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Remind_delete_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Remind_delete_BUT_Delete
	ui->Remind_delete_BUT_Delete = lv_btn_create(ui->Remind_delete);
	ui->Remind_delete_BUT_Delete_label = lv_label_create(ui->Remind_delete_BUT_Delete);
	lv_label_set_text(ui->Remind_delete_BUT_Delete_label, "Delete");
	lv_label_set_long_mode(ui->Remind_delete_BUT_Delete_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Remind_delete_BUT_Delete_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Remind_delete_BUT_Delete, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Remind_delete_BUT_Delete, 316, 118);
	lv_obj_set_size(ui->Remind_delete_BUT_Delete, 100, 37);

	//Write style for Remind_delete_BUT_Delete, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Remind_delete_BUT_Delete, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Remind_delete_BUT_Delete, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Remind_delete_BUT_Delete, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Remind_delete_BUT_Delete, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Remind_delete_BUT_Delete, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Remind_delete_BUT_Delete, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Remind_delete_BUT_Delete, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Remind_delete_BUT_Delete, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Remind_delete_win_delete
	ui->Remind_delete_win_delete = lv_win_create(ui->Remind_delete, 40);
	lv_win_add_title(ui->Remind_delete_win_delete, "System");
	ui->Remind_delete_win_delete_item0 = lv_win_add_btn(ui->Remind_delete_win_delete, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *Remind_delete_win_delete_label = lv_label_create(lv_win_get_content(ui->Remind_delete_win_delete));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->Remind_delete_win_delete), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(Remind_delete_win_delete_label, "Reminder deleted!\n");
	lv_obj_set_pos(ui->Remind_delete_win_delete, 44, 48);
	lv_obj_set_size(ui->Remind_delete_win_delete, 400, 177);
	lv_obj_add_flag(ui->Remind_delete_win_delete, LV_OBJ_FLAG_HIDDEN);

	//Write style for Remind_delete_win_delete, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Remind_delete_win_delete, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Remind_delete_win_delete, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->Remind_delete_win_delete, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Remind_delete_win_delete, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Remind_delete_win_delete_extra_content_main_default
	static lv_style_t style_Remind_delete_win_delete_extra_content_main_default;
	ui_init_style(&style_Remind_delete_win_delete_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_Remind_delete_win_delete_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_Remind_delete_win_delete_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_Remind_delete_win_delete_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Remind_delete_win_delete_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_Remind_delete_win_delete_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_Remind_delete_win_delete_extra_content_main_default, 2);
	lv_obj_add_style(lv_win_get_content(ui->Remind_delete_win_delete), &style_Remind_delete_win_delete_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Remind_delete_win_delete_extra_header_main_default
	static lv_style_t style_Remind_delete_win_delete_extra_header_main_default;
	ui_init_style(&style_Remind_delete_win_delete_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_Remind_delete_win_delete_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_Remind_delete_win_delete_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_Remind_delete_win_delete_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Remind_delete_win_delete_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_Remind_delete_win_delete_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_Remind_delete_win_delete_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->Remind_delete_win_delete), &style_Remind_delete_win_delete_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Remind_delete_win_delete_extra_btns_main_default
	static lv_style_t style_Remind_delete_win_delete_extra_btns_main_default;
	ui_init_style(&style_Remind_delete_win_delete_extra_btns_main_default);
	
	lv_style_set_radius(&style_Remind_delete_win_delete_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_Remind_delete_win_delete_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Remind_delete_win_delete_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_Remind_delete_win_delete_extra_btns_main_default, 0);
	lv_obj_add_style(ui->Remind_delete_win_delete_item0, &style_Remind_delete_win_delete_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Remind_delete);

	
	//Init events for screen.
	events_init_Remind_delete(ui);
}
