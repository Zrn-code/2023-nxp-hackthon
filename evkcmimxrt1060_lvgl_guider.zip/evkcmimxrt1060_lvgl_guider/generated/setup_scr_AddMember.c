/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_AddMember(lv_ui *ui)
{
	//Write codes AddMember
	ui->AddMember = lv_obj_create(NULL);
	ui->g_kb_AddMember = lv_keyboard_create(ui->AddMember);
	lv_obj_add_event_cb(ui->g_kb_AddMember, kb_event_cb, LV_EVENT_ALL, NULL);
	lv_obj_add_flag(ui->g_kb_AddMember, LV_OBJ_FLAG_HIDDEN);
	lv_obj_set_style_text_font(ui->g_kb_AddMember, &lv_font_simsun_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_size(ui->AddMember, 480, 272);

	//Write style for AddMember, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->AddMember, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->AddMember, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_contBG
	ui->AddMember_contBG = lv_obj_create(ui->AddMember);
	lv_obj_set_pos(ui->AddMember_contBG, 0, 0);
	lv_obj_set_size(ui->AddMember_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->AddMember_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for AddMember_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->AddMember_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->AddMember_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->AddMember_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_BUT_back
	ui->AddMember_BUT_back = lv_btn_create(ui->AddMember_contBG);
	ui->AddMember_BUT_back_label = lv_label_create(ui->AddMember_BUT_back);
	lv_label_set_text(ui->AddMember_BUT_back_label, "<");
	lv_label_set_long_mode(ui->AddMember_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->AddMember_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->AddMember_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->AddMember_BUT_back, 24, 17);
	lv_obj_set_size(ui->AddMember_BUT_back, 35, 32);

	//Write style for AddMember_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->AddMember_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->AddMember_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->AddMember_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_text_title
	ui->AddMember_text_title = lv_label_create(ui->AddMember_contBG);
	lv_label_set_text(ui->AddMember_text_title, "Member's information");
	lv_label_set_long_mode(ui->AddMember_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->AddMember_text_title, 79, 22);
	lv_obj_set_size(ui->AddMember_text_title, 323, 32);

	//Write style for AddMember_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->AddMember_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_BUT_Add
	ui->AddMember_BUT_Add = lv_btn_create(ui->AddMember);
	ui->AddMember_BUT_Add_label = lv_label_create(ui->AddMember_BUT_Add);
	lv_label_set_text(ui->AddMember_BUT_Add_label, "Add");
	lv_label_set_long_mode(ui->AddMember_BUT_Add_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->AddMember_BUT_Add_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->AddMember_BUT_Add, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->AddMember_BUT_Add, 366, 224);
	lv_obj_set_size(ui->AddMember_BUT_Add, 100, 37);

	//Write style for AddMember_BUT_Add, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->AddMember_BUT_Add, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->AddMember_BUT_Add, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->AddMember_BUT_Add, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_BUT_Add, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_BUT_Add, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->AddMember_BUT_Add, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_BUT_Add, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_BUT_Add, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_text_name
	ui->AddMember_text_name = lv_label_create(ui->AddMember);
	lv_label_set_text(ui->AddMember_text_name, "Name");
	lv_label_set_long_mode(ui->AddMember_text_name, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->AddMember_text_name, 54, 114);
	lv_obj_set_size(ui->AddMember_text_name, 100, 32);

	//Write style for AddMember_text_name, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->AddMember_text_name, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_text_name, &lv_font_montserratMedium_17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->AddMember_text_name, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_text_name, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_text_name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_text_age
	ui->AddMember_text_age = lv_label_create(ui->AddMember);
	lv_label_set_text(ui->AddMember_text_age, "Age");
	lv_label_set_long_mode(ui->AddMember_text_age, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->AddMember_text_age, 190, 114);
	lv_obj_set_size(ui->AddMember_text_age, 100, 32);

	//Write style for AddMember_text_age, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->AddMember_text_age, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_text_age, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->AddMember_text_age, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_text_age, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_text_age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_text_gender
	ui->AddMember_text_gender = lv_label_create(ui->AddMember);
	lv_label_set_text(ui->AddMember_text_gender, "Gender");
	lv_label_set_long_mode(ui->AddMember_text_gender, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->AddMember_text_gender, 328, 114);
	lv_obj_set_size(ui->AddMember_text_gender, 100, 32);

	//Write style for AddMember_text_gender, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->AddMember_text_gender, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_text_gender, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->AddMember_text_gender, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_text_gender, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_text_gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes AddMember_INPUT_Gender
	ui->AddMember_INPUT_Gender = lv_dropdown_create(ui->AddMember);
	lv_dropdown_set_options(ui->AddMember_INPUT_Gender, "Male\nFemale");
	lv_obj_set_pos(ui->AddMember_INPUT_Gender, 321, 138);
	lv_obj_set_size(ui->AddMember_INPUT_Gender, 119, 35);

	//Write style for AddMember_INPUT_Gender, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->AddMember_INPUT_Gender, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_INPUT_Gender, &lv_font_montserratMedium_17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->AddMember_INPUT_Gender, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->AddMember_INPUT_Gender, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->AddMember_INPUT_Gender, lv_color_hex(0xe1e6ee), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->AddMember_INPUT_Gender, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_INPUT_Gender, 8, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_INPUT_Gender, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_INPUT_Gender, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_INPUT_Gender, 3, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_INPUT_Gender, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->AddMember_INPUT_Gender, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_INPUT_Gender, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_CHECKED for &style_AddMember_INPUT_Gender_extra_list_selected_checked
	static lv_style_t style_AddMember_INPUT_Gender_extra_list_selected_checked;
	ui_init_style(&style_AddMember_INPUT_Gender_extra_list_selected_checked);
	
	lv_style_set_text_color(&style_AddMember_INPUT_Gender_extra_list_selected_checked, lv_color_hex(0xffffff));
	lv_style_set_text_font(&style_AddMember_INPUT_Gender_extra_list_selected_checked, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_AddMember_INPUT_Gender_extra_list_selected_checked, 1);
	lv_style_set_border_opa(&style_AddMember_INPUT_Gender_extra_list_selected_checked, 255);
	lv_style_set_border_color(&style_AddMember_INPUT_Gender_extra_list_selected_checked, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_AddMember_INPUT_Gender_extra_list_selected_checked, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_AddMember_INPUT_Gender_extra_list_selected_checked, 3);
	lv_style_set_bg_opa(&style_AddMember_INPUT_Gender_extra_list_selected_checked, 255);
	lv_style_set_bg_color(&style_AddMember_INPUT_Gender_extra_list_selected_checked, lv_color_hex(0x00a1b5));
	lv_obj_add_style(lv_dropdown_get_list(ui->AddMember_INPUT_Gender), &style_AddMember_INPUT_Gender_extra_list_selected_checked, LV_PART_SELECTED|LV_STATE_CHECKED);

	//Write style state: LV_STATE_DEFAULT for &style_AddMember_INPUT_Gender_extra_list_main_default
	static lv_style_t style_AddMember_INPUT_Gender_extra_list_main_default;
	ui_init_style(&style_AddMember_INPUT_Gender_extra_list_main_default);
	
	lv_style_set_max_height(&style_AddMember_INPUT_Gender_extra_list_main_default, 90);
	lv_style_set_text_color(&style_AddMember_INPUT_Gender_extra_list_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_AddMember_INPUT_Gender_extra_list_main_default, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_AddMember_INPUT_Gender_extra_list_main_default, 1);
	lv_style_set_border_opa(&style_AddMember_INPUT_Gender_extra_list_main_default, 255);
	lv_style_set_border_color(&style_AddMember_INPUT_Gender_extra_list_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_AddMember_INPUT_Gender_extra_list_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_AddMember_INPUT_Gender_extra_list_main_default, 3);
	lv_style_set_bg_opa(&style_AddMember_INPUT_Gender_extra_list_main_default, 255);
	lv_style_set_bg_color(&style_AddMember_INPUT_Gender_extra_list_main_default, lv_color_hex(0xffffff));
	lv_obj_add_style(lv_dropdown_get_list(ui->AddMember_INPUT_Gender), &style_AddMember_INPUT_Gender_extra_list_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_AddMember_INPUT_Gender_extra_list_scrollbar_default
	static lv_style_t style_AddMember_INPUT_Gender_extra_list_scrollbar_default;
	ui_init_style(&style_AddMember_INPUT_Gender_extra_list_scrollbar_default);
	
	lv_style_set_radius(&style_AddMember_INPUT_Gender_extra_list_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_AddMember_INPUT_Gender_extra_list_scrollbar_default, 255);
	lv_style_set_bg_color(&style_AddMember_INPUT_Gender_extra_list_scrollbar_default, lv_color_hex(0x190482));
	lv_obj_add_style(lv_dropdown_get_list(ui->AddMember_INPUT_Gender), &style_AddMember_INPUT_Gender_extra_list_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes AddMember_INPUT_Age
	ui->AddMember_INPUT_Age = lv_textarea_create(ui->AddMember);
	lv_textarea_set_text(ui->AddMember_INPUT_Age, "");
	lv_textarea_set_password_bullet(ui->AddMember_INPUT_Age, "*");
	lv_textarea_set_password_mode(ui->AddMember_INPUT_Age, false);
	lv_textarea_set_one_line(ui->AddMember_INPUT_Age, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->AddMember_INPUT_Age, ta_event_cb, LV_EVENT_ALL, ui->g_kb_AddMember);
	#endif
	lv_obj_set_pos(ui->AddMember_INPUT_Age, 183, 138);
	lv_obj_set_size(ui->AddMember_INPUT_Age, 115, 37);

	//Write style for AddMember_INPUT_Age, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->AddMember_INPUT_Age, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_INPUT_Age, &lv_font_montserratMedium_17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->AddMember_INPUT_Age, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_INPUT_Age, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_INPUT_Age, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->AddMember_INPUT_Age, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->AddMember_INPUT_Age, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->AddMember_INPUT_Age, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->AddMember_INPUT_Age, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->AddMember_INPUT_Age, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_INPUT_Age, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_INPUT_Age, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_INPUT_Age, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_INPUT_Age, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_INPUT_Age, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for AddMember_INPUT_Age, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->AddMember_INPUT_Age, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_INPUT_Age, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes AddMember_INPUT_Name
	ui->AddMember_INPUT_Name = lv_textarea_create(ui->AddMember);
	lv_textarea_set_text(ui->AddMember_INPUT_Name, "");
	lv_textarea_set_password_bullet(ui->AddMember_INPUT_Name, "*");
	lv_textarea_set_password_mode(ui->AddMember_INPUT_Name, false);
	lv_textarea_set_one_line(ui->AddMember_INPUT_Name, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->AddMember_INPUT_Name, ta_event_cb, LV_EVENT_ALL, ui->g_kb_AddMember);
	#endif
	lv_obj_set_pos(ui->AddMember_INPUT_Name, 47, 138);
	lv_obj_set_size(ui->AddMember_INPUT_Name, 115, 37);

	//Write style for AddMember_INPUT_Name, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->AddMember_INPUT_Name, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->AddMember_INPUT_Name, &lv_font_montserratMedium_17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->AddMember_INPUT_Name, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->AddMember_INPUT_Name, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->AddMember_INPUT_Name, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->AddMember_INPUT_Name, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->AddMember_INPUT_Name, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->AddMember_INPUT_Name, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->AddMember_INPUT_Name, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->AddMember_INPUT_Name, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_INPUT_Name, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->AddMember_INPUT_Name, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->AddMember_INPUT_Name, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->AddMember_INPUT_Name, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_INPUT_Name, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for AddMember_INPUT_Name, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->AddMember_INPUT_Name, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->AddMember_INPUT_Name, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes AddMember_win_success
	ui->AddMember_win_success = lv_win_create(ui->AddMember, 40);
	lv_win_add_title(ui->AddMember_win_success, "System");
	ui->AddMember_win_success_item0 = lv_win_add_btn(ui->AddMember_win_success, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *AddMember_win_success_label = lv_label_create(lv_win_get_content(ui->AddMember_win_success));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->AddMember_win_success), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(AddMember_win_success_label, "Adding successfully!!\n");
	lv_obj_set_pos(ui->AddMember_win_success, 44, 48);
	lv_obj_set_size(ui->AddMember_win_success, 400, 177);
	lv_obj_add_flag(ui->AddMember_win_success, LV_OBJ_FLAG_HIDDEN);

	//Write style for AddMember_win_success, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->AddMember_win_success, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->AddMember_win_success, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->AddMember_win_success, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->AddMember_win_success, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_AddMember_win_success_extra_content_main_default
	static lv_style_t style_AddMember_win_success_extra_content_main_default;
	ui_init_style(&style_AddMember_win_success_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_AddMember_win_success_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_AddMember_win_success_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_AddMember_win_success_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_AddMember_win_success_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_AddMember_win_success_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_AddMember_win_success_extra_content_main_default, 2);
	lv_obj_add_style(lv_win_get_content(ui->AddMember_win_success), &style_AddMember_win_success_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_AddMember_win_success_extra_header_main_default
	static lv_style_t style_AddMember_win_success_extra_header_main_default;
	ui_init_style(&style_AddMember_win_success_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_AddMember_win_success_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_AddMember_win_success_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_AddMember_win_success_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_AddMember_win_success_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_AddMember_win_success_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_AddMember_win_success_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->AddMember_win_success), &style_AddMember_win_success_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_AddMember_win_success_extra_btns_main_default
	static lv_style_t style_AddMember_win_success_extra_btns_main_default;
	ui_init_style(&style_AddMember_win_success_extra_btns_main_default);
	
	lv_style_set_radius(&style_AddMember_win_success_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_AddMember_win_success_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_AddMember_win_success_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_AddMember_win_success_extra_btns_main_default, 0);
	lv_obj_add_style(ui->AddMember_win_success_item0, &style_AddMember_win_success_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->AddMember);

	
	//Init events for screen.
	events_init_AddMember(ui);
}
