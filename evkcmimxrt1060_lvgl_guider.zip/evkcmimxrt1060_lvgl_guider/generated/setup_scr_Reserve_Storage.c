/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Reserve_Storage(lv_ui *ui)
{
	//Write codes Reserve_Storage
	ui->Reserve_Storage = lv_obj_create(NULL);
	lv_obj_set_size(ui->Reserve_Storage, 480, 272);

	//Write style for Reserve_Storage, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Storage, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Storage, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storage_contBG
	ui->Reserve_Storage_contBG = lv_obj_create(ui->Reserve_Storage);
	lv_obj_set_pos(ui->Reserve_Storage_contBG, 0, 0);
	lv_obj_set_size(ui->Reserve_Storage_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Reserve_Storage_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Reserve_Storage_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Storage_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storage_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Storage_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Storage_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Storage_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Storage_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Storage_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Storage_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storage_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storage_BUT_back
	ui->Reserve_Storage_BUT_back = lv_btn_create(ui->Reserve_Storage_contBG);
	ui->Reserve_Storage_BUT_back_label = lv_label_create(ui->Reserve_Storage_BUT_back);
	lv_label_set_text(ui->Reserve_Storage_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Reserve_Storage_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Storage_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Storage_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Storage_BUT_back, 25, 17);
	lv_obj_set_size(ui->Reserve_Storage_BUT_back, 35, 32);

	//Write style for Reserve_Storage_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Storage_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Storage_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storage_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storage_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Storage_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storage_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storage_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storage_text_title
	ui->Reserve_Storage_text_title = lv_label_create(ui->Reserve_Storage_contBG);
	lv_label_set_text(ui->Reserve_Storage_text_title, "Storage");
	lv_label_set_long_mode(ui->Reserve_Storage_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Storage_text_title, 135, 21);
	lv_obj_set_size(ui->Reserve_Storage_text_title, 210, 32);

	//Write style for Reserve_Storage_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Storage_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storage_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Storage_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storage_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storage_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storage_BUT_home
	ui->Reserve_Storage_BUT_home = lv_btn_create(ui->Reserve_Storage);
	ui->Reserve_Storage_BUT_home_label = lv_label_create(ui->Reserve_Storage_BUT_home);
	lv_label_set_text(ui->Reserve_Storage_BUT_home_label, "Finish");
	lv_label_set_long_mode(ui->Reserve_Storage_BUT_home_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Storage_BUT_home_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Storage_BUT_home, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Storage_BUT_home, 366, 224);
	lv_obj_set_size(ui->Reserve_Storage_BUT_home, 100, 37);

	//Write style for Reserve_Storage_BUT_home, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Storage_BUT_home, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Storage_BUT_home, lv_color_hex(0x0506a0), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Storage_BUT_home, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storage_BUT_home, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storage_BUT_home, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Storage_BUT_home, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storage_BUT_home, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storage_BUT_home, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storage_LIST_storagelist
	ui->Reserve_Storage_LIST_storagelist = lv_list_create(ui->Reserve_Storage);
	lv_obj_set_pos(ui->Reserve_Storage_LIST_storagelist, 34, 78);
	lv_obj_set_size(ui->Reserve_Storage_LIST_storagelist, 412, 130);
	lv_obj_set_scrollbar_mode(ui->Reserve_Storage_LIST_storagelist, LV_SCROLLBAR_MODE_AUTO);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Storage_LIST_storagelist_main_main_default
	static lv_style_t style_Reserve_Storage_LIST_storagelist_main_main_default;
	ui_init_style(&style_Reserve_Storage_LIST_storagelist_main_main_default);
	
	lv_style_set_pad_top(&style_Reserve_Storage_LIST_storagelist_main_main_default, 5);
	lv_style_set_pad_left(&style_Reserve_Storage_LIST_storagelist_main_main_default, 5);
	lv_style_set_pad_right(&style_Reserve_Storage_LIST_storagelist_main_main_default, 5);
	lv_style_set_pad_bottom(&style_Reserve_Storage_LIST_storagelist_main_main_default, 5);
	lv_style_set_bg_opa(&style_Reserve_Storage_LIST_storagelist_main_main_default, 255);
	lv_style_set_bg_color(&style_Reserve_Storage_LIST_storagelist_main_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_border_width(&style_Reserve_Storage_LIST_storagelist_main_main_default, 1);
	lv_style_set_border_opa(&style_Reserve_Storage_LIST_storagelist_main_main_default, 255);
	lv_style_set_border_color(&style_Reserve_Storage_LIST_storagelist_main_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Reserve_Storage_LIST_storagelist_main_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Reserve_Storage_LIST_storagelist_main_main_default, 3);
	lv_style_set_shadow_width(&style_Reserve_Storage_LIST_storagelist_main_main_default, 0);
	lv_obj_add_style(ui->Reserve_Storage_LIST_storagelist, &style_Reserve_Storage_LIST_storagelist_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Storage_LIST_storagelist_main_scrollbar_default
	static lv_style_t style_Reserve_Storage_LIST_storagelist_main_scrollbar_default;
	ui_init_style(&style_Reserve_Storage_LIST_storagelist_main_scrollbar_default);
	
	lv_style_set_radius(&style_Reserve_Storage_LIST_storagelist_main_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Reserve_Storage_LIST_storagelist_main_scrollbar_default, 255);
	lv_style_set_bg_color(&style_Reserve_Storage_LIST_storagelist_main_scrollbar_default, lv_color_hex(0xffffff));
	lv_obj_add_style(ui->Reserve_Storage_LIST_storagelist, &style_Reserve_Storage_LIST_storagelist_main_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Storage_LIST_storagelist_extra_btns_main_default
	static lv_style_t style_Reserve_Storage_LIST_storagelist_extra_btns_main_default;
	ui_init_style(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default);
	
	lv_style_set_pad_top(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, 5);
	lv_style_set_pad_left(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, 5);
	lv_style_set_pad_right(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, 5);
	lv_style_set_pad_bottom(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, 5);
	lv_style_set_border_width(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, 0);
	lv_style_set_text_color(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, &lv_font_montserratMedium_12);
	lv_style_set_radius(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, 3);
	lv_style_set_bg_opa(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, lv_color_hex(0xffffff));

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Storage_LIST_storagelist_extra_texts_main_default
	static lv_style_t style_Reserve_Storage_LIST_storagelist_extra_texts_main_default;
	ui_init_style(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default);
	
	lv_style_set_pad_top(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, 5);
	lv_style_set_pad_left(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, 5);
	lv_style_set_pad_right(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, 5);
	lv_style_set_pad_bottom(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, 5);
	lv_style_set_border_width(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, 0);
	lv_style_set_text_color(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, &lv_font_montserratMedium_12);
	lv_style_set_radius(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, 3);
	lv_style_set_bg_opa(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, 255);
	lv_style_set_bg_color(&style_Reserve_Storage_LIST_storagelist_extra_texts_main_default, lv_color_hex(0xffffff));

	//Update current screen layout.
	lv_obj_update_layout(ui->Reserve_Storage);

	
	//Init events for screen.
	events_init_Reserve_Storage(ui);
}
