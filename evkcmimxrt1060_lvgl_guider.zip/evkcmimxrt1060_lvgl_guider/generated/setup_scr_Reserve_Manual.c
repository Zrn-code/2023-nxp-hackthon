/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Reserve_Manual(lv_ui *ui)
{
	//Write codes Reserve_Manual
	ui->Reserve_Manual = lv_obj_create(NULL);
	ui->g_kb_Reserve_Manual = lv_keyboard_create(ui->Reserve_Manual);
	lv_obj_add_event_cb(ui->g_kb_Reserve_Manual, kb_event_cb, LV_EVENT_ALL, NULL);
	lv_obj_add_flag(ui->g_kb_Reserve_Manual, LV_OBJ_FLAG_HIDDEN);
	lv_obj_set_style_text_font(ui->g_kb_Reserve_Manual, &lv_font_simsun_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_size(ui->Reserve_Manual, 480, 272);

	//Write style for Reserve_Manual, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Manual, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_contBG
	ui->Reserve_Manual_contBG = lv_obj_create(ui->Reserve_Manual);
	lv_obj_set_pos(ui->Reserve_Manual_contBG, 0, 0);
	lv_obj_set_size(ui->Reserve_Manual_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Reserve_Manual_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Reserve_Manual_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Manual_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Manual_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_BUT_back
	ui->Reserve_Manual_BUT_back = lv_btn_create(ui->Reserve_Manual_contBG);
	ui->Reserve_Manual_BUT_back_label = lv_label_create(ui->Reserve_Manual_BUT_back);
	lv_label_set_text(ui->Reserve_Manual_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Reserve_Manual_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Manual_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Manual_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Manual_BUT_back, 25, 17);
	lv_obj_set_size(ui->Reserve_Manual_BUT_back, 35, 32);

	//Write style for Reserve_Manual_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Manual_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Manual_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_text_title
	ui->Reserve_Manual_text_title = lv_label_create(ui->Reserve_Manual);
	lv_label_set_text(ui->Reserve_Manual_text_title, "Storing Medicine");
	lv_label_set_long_mode(ui->Reserve_Manual_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Manual_text_title, 135, 23);
	lv_obj_set_size(ui->Reserve_Manual_text_title, 210, 32);

	//Write style for Reserve_Manual_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Manual_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Manual_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_text_user
	ui->Reserve_Manual_text_user = lv_label_create(ui->Reserve_Manual);
	lv_label_set_text(ui->Reserve_Manual_text_user, "User");
	lv_label_set_long_mode(ui->Reserve_Manual_text_user, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Manual_text_user, 49, 97);
	lv_obj_set_size(ui->Reserve_Manual_text_user, 100, 32);

	//Write style for Reserve_Manual_text_user, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Manual_text_user, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_text_user, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Manual_text_user, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_text_user, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_text_medicine
	ui->Reserve_Manual_text_medicine = lv_label_create(ui->Reserve_Manual);
	lv_label_set_text(ui->Reserve_Manual_text_medicine, "Medicine");
	lv_label_set_long_mode(ui->Reserve_Manual_text_medicine, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Manual_text_medicine, 190, 97);
	lv_obj_set_size(ui->Reserve_Manual_text_medicine, 100, 32);

	//Write style for Reserve_Manual_text_medicine, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Manual_text_medicine, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_text_medicine, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Manual_text_medicine, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_text_medicine, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_text_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_text_num
	ui->Reserve_Manual_text_num = lv_label_create(ui->Reserve_Manual);
	lv_label_set_text(ui->Reserve_Manual_text_num, "Numbers");
	lv_label_set_long_mode(ui->Reserve_Manual_text_num, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Manual_text_num, 329, 97);
	lv_obj_set_size(ui->Reserve_Manual_text_num, 100, 32);

	//Write style for Reserve_Manual_text_num, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Manual_text_num, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_text_num, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Manual_text_num, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_text_num, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_BUT_home
	ui->Reserve_Manual_BUT_home = lv_btn_create(ui->Reserve_Manual);
	ui->Reserve_Manual_BUT_home_label = lv_label_create(ui->Reserve_Manual_BUT_home);
	lv_label_set_text(ui->Reserve_Manual_BUT_home_label, "Finish");
	lv_label_set_long_mode(ui->Reserve_Manual_BUT_home_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Manual_BUT_home_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Manual_BUT_home, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Manual_BUT_home, 366, 224);
	lv_obj_set_size(ui->Reserve_Manual_BUT_home, 100, 37);

	//Write style for Reserve_Manual_BUT_home, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_BUT_home, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual_BUT_home, lv_color_hex(0x0506a0), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Manual_BUT_home, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_BUT_home, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_BUT_home, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Manual_BUT_home, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_BUT_home, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_BUT_home, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_BUT_store
	ui->Reserve_Manual_BUT_store = lv_btn_create(ui->Reserve_Manual);
	ui->Reserve_Manual_BUT_store_label = lv_label_create(ui->Reserve_Manual_BUT_store);
	lv_label_set_text(ui->Reserve_Manual_BUT_store_label, "store");
	lv_label_set_long_mode(ui->Reserve_Manual_BUT_store_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Manual_BUT_store_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Manual_BUT_store, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Manual_BUT_store, 259, 224);
	lv_obj_set_size(ui->Reserve_Manual_BUT_store, 100, 37);

	//Write style for Reserve_Manual_BUT_store, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_BUT_store, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual_BUT_store, lv_color_hex(0x0506a0), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Manual_BUT_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_BUT_store, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_BUT_store, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Manual_BUT_store, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_BUT_store, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_BUT_store, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_INPUT_User
	ui->Reserve_Manual_INPUT_User = lv_dropdown_create(ui->Reserve_Manual);
	lv_dropdown_set_options(ui->Reserve_Manual_INPUT_User, "");
	lv_obj_set_pos(ui->Reserve_Manual_INPUT_User, 34, 121);
	lv_obj_set_size(ui->Reserve_Manual_INPUT_User, 130, 30);

	//Write style for Reserve_Manual_INPUT_User, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reserve_Manual_INPUT_User, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_INPUT_User, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Manual_INPUT_User, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Reserve_Manual_INPUT_User, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Reserve_Manual_INPUT_User, lv_color_hex(0xe1e6ee), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Reserve_Manual_INPUT_User, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_INPUT_User, 8, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_INPUT_User, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_INPUT_User, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_INPUT_User, 3, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_INPUT_User, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual_INPUT_User, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_INPUT_User, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_CHECKED for &style_Reserve_Manual_INPUT_User_extra_list_selected_checked
	static lv_style_t style_Reserve_Manual_INPUT_User_extra_list_selected_checked;
	ui_init_style(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked);
	
	lv_style_set_text_color(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, lv_color_hex(0xffffff));
	lv_style_set_text_font(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, 1);
	lv_style_set_border_opa(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, 255);
	lv_style_set_border_color(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, 3);
	lv_style_set_bg_opa(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, 255);
	lv_style_set_bg_color(&style_Reserve_Manual_INPUT_User_extra_list_selected_checked, lv_color_hex(0x00a1b5));
	lv_obj_add_style(lv_dropdown_get_list(ui->Reserve_Manual_INPUT_User), &style_Reserve_Manual_INPUT_User_extra_list_selected_checked, LV_PART_SELECTED|LV_STATE_CHECKED);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Manual_INPUT_User_extra_list_main_default
	static lv_style_t style_Reserve_Manual_INPUT_User_extra_list_main_default;
	ui_init_style(&style_Reserve_Manual_INPUT_User_extra_list_main_default);
	
	lv_style_set_max_height(&style_Reserve_Manual_INPUT_User_extra_list_main_default, 90);
	lv_style_set_text_color(&style_Reserve_Manual_INPUT_User_extra_list_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Reserve_Manual_INPUT_User_extra_list_main_default, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_Reserve_Manual_INPUT_User_extra_list_main_default, 1);
	lv_style_set_border_opa(&style_Reserve_Manual_INPUT_User_extra_list_main_default, 255);
	lv_style_set_border_color(&style_Reserve_Manual_INPUT_User_extra_list_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Reserve_Manual_INPUT_User_extra_list_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Reserve_Manual_INPUT_User_extra_list_main_default, 3);
	lv_style_set_bg_opa(&style_Reserve_Manual_INPUT_User_extra_list_main_default, 255);
	lv_style_set_bg_color(&style_Reserve_Manual_INPUT_User_extra_list_main_default, lv_color_hex(0xffffff));
	lv_obj_add_style(lv_dropdown_get_list(ui->Reserve_Manual_INPUT_User), &style_Reserve_Manual_INPUT_User_extra_list_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default
	static lv_style_t style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default;
	ui_init_style(&style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default);
	
	lv_style_set_radius(&style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default, 0);
	lv_obj_add_style(lv_dropdown_get_list(ui->Reserve_Manual_INPUT_User), &style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_INPUT_num
	ui->Reserve_Manual_INPUT_num = lv_textarea_create(ui->Reserve_Manual);
	lv_textarea_set_text(ui->Reserve_Manual_INPUT_num, "");
	lv_textarea_set_password_bullet(ui->Reserve_Manual_INPUT_num, "*");
	lv_textarea_set_password_mode(ui->Reserve_Manual_INPUT_num, false);
	lv_textarea_set_one_line(ui->Reserve_Manual_INPUT_num, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->Reserve_Manual_INPUT_num, ta_event_cb, LV_EVENT_ALL, ui->g_kb_Reserve_Manual);
	#endif
	lv_obj_set_pos(ui->Reserve_Manual_INPUT_num, 318, 121);
	lv_obj_set_size(ui->Reserve_Manual_INPUT_num, 135, 29);

	//Write style for Reserve_Manual_INPUT_num, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reserve_Manual_INPUT_num, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_INPUT_num, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Manual_INPUT_num, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_INPUT_num, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_INPUT_num, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual_INPUT_num, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Manual_INPUT_num, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Reserve_Manual_INPUT_num, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Reserve_Manual_INPUT_num, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Reserve_Manual_INPUT_num, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_INPUT_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_INPUT_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_INPUT_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_INPUT_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_INPUT_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Reserve_Manual_INPUT_num, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_INPUT_num, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_INPUT_num, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_INPUT_medicine
	ui->Reserve_Manual_INPUT_medicine = lv_textarea_create(ui->Reserve_Manual);
	lv_textarea_set_text(ui->Reserve_Manual_INPUT_medicine, "");
	lv_textarea_set_password_bullet(ui->Reserve_Manual_INPUT_medicine, "*");
	lv_textarea_set_password_mode(ui->Reserve_Manual_INPUT_medicine, false);
	lv_textarea_set_one_line(ui->Reserve_Manual_INPUT_medicine, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->Reserve_Manual_INPUT_medicine, ta_event_cb, LV_EVENT_ALL, ui->g_kb_Reserve_Manual);
	#endif
	lv_obj_set_pos(ui->Reserve_Manual_INPUT_medicine, 173, 121);
	lv_obj_set_size(ui->Reserve_Manual_INPUT_medicine, 135, 29);

	//Write style for Reserve_Manual_INPUT_medicine, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reserve_Manual_INPUT_medicine, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Manual_INPUT_medicine, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Manual_INPUT_medicine, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Manual_INPUT_medicine, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_INPUT_medicine, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual_INPUT_medicine, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Manual_INPUT_medicine, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Reserve_Manual_INPUT_medicine, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Reserve_Manual_INPUT_medicine, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Reserve_Manual_INPUT_medicine, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_INPUT_medicine, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Manual_INPUT_medicine, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Manual_INPUT_medicine, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Manual_INPUT_medicine, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_INPUT_medicine, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Reserve_Manual_INPUT_medicine, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_INPUT_medicine, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Manual_INPUT_medicine, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Reserve_Manual_win_success
	ui->Reserve_Manual_win_success = lv_win_create(ui->Reserve_Manual, 40);
	lv_win_add_title(ui->Reserve_Manual_win_success, "System");
	ui->Reserve_Manual_win_success_item0 = lv_win_add_btn(ui->Reserve_Manual_win_success, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *Reserve_Manual_win_success_label = lv_label_create(lv_win_get_content(ui->Reserve_Manual_win_success));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->Reserve_Manual_win_success), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(Reserve_Manual_win_success_label, "Storing successfully!!\n");
	lv_obj_set_pos(ui->Reserve_Manual_win_success, 49, 48);
	lv_obj_set_size(ui->Reserve_Manual_win_success, 400, 177);
	lv_obj_add_flag(ui->Reserve_Manual_win_success, LV_OBJ_FLAG_HIDDEN);

	//Write style for Reserve_Manual_win_success, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Manual_win_success, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Manual_win_success, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->Reserve_Manual_win_success, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Manual_win_success, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Manual_win_success_extra_content_main_default
	static lv_style_t style_Reserve_Manual_win_success_extra_content_main_default;
	ui_init_style(&style_Reserve_Manual_win_success_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_Reserve_Manual_win_success_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_Reserve_Manual_win_success_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_Reserve_Manual_win_success_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Reserve_Manual_win_success_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_Reserve_Manual_win_success_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_Reserve_Manual_win_success_extra_content_main_default, 2);
	lv_obj_add_style(lv_win_get_content(ui->Reserve_Manual_win_success), &style_Reserve_Manual_win_success_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Manual_win_success_extra_header_main_default
	static lv_style_t style_Reserve_Manual_win_success_extra_header_main_default;
	ui_init_style(&style_Reserve_Manual_win_success_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_Reserve_Manual_win_success_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_Reserve_Manual_win_success_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_Reserve_Manual_win_success_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Reserve_Manual_win_success_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_Reserve_Manual_win_success_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_Reserve_Manual_win_success_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->Reserve_Manual_win_success), &style_Reserve_Manual_win_success_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reserve_Manual_win_success_extra_btns_main_default
	static lv_style_t style_Reserve_Manual_win_success_extra_btns_main_default;
	ui_init_style(&style_Reserve_Manual_win_success_extra_btns_main_default);
	
	lv_style_set_radius(&style_Reserve_Manual_win_success_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_Reserve_Manual_win_success_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Reserve_Manual_win_success_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_Reserve_Manual_win_success_extra_btns_main_default, 0);
	lv_obj_add_style(ui->Reserve_Manual_win_success_item0, &style_Reserve_Manual_win_success_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Reserve_Manual);

	
	//Init events for screen.
	events_init_Reserve_Manual(ui);
}
