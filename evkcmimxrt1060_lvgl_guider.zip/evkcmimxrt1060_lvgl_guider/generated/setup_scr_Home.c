/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Home(lv_ui *ui)
{
	//Write codes Home
	ui->Home = lv_obj_create(NULL);
	lv_obj_set_size(ui->Home, 480, 272);

	//Write style for Home, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Home, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_upimage
	ui->Home_upimage = lv_obj_create(ui->Home);
	lv_obj_set_pos(ui->Home_upimage, 0, 0);
	lv_obj_set_size(ui->Home_upimage, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Home_upimage, LV_SCROLLBAR_MODE_OFF);

	//Write style for Home_upimage, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_upimage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_upimage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_upimage, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_upimage, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_upimage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_upimage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_upimage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_upimage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_upimage, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_img_setting
	ui->Home_img_setting = lv_img_create(ui->Home_upimage);
	lv_obj_add_flag(ui->Home_img_setting, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_img_setting, &_setup_alpha_35x35);
	lv_img_set_pivot(ui->Home_img_setting, 50,50);
	lv_img_set_angle(ui->Home_img_setting, 0);
	lv_obj_set_pos(ui->Home_img_setting, 428, 14);
	lv_obj_set_size(ui->Home_img_setting, 35, 35);

	//Write style for Home_img_setting, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_img_setting, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_contMain
	ui->Home_contMain = lv_obj_create(ui->Home);
	lv_obj_set_pos(ui->Home_contMain, 35, 63);
	lv_obj_set_size(ui->Home_contMain, 410, 140);
	lv_obj_set_scrollbar_mode(ui->Home_contMain, LV_SCROLLBAR_MODE_OFF);

	//Write style for Home_contMain, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_contMain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_contMain, 7, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_contMain, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_contMain, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_contMain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_contMain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_contMain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_contMain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_contMain, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_contSetup
	ui->Home_contSetup = lv_obj_create(ui->Home_contMain);
	lv_obj_set_pos(ui->Home_contSetup, 306, 10);
	lv_obj_set_size(ui->Home_contSetup, 100, 120);
	lv_obj_set_scrollbar_mode(ui->Home_contSetup, LV_SCROLLBAR_MODE_OFF);

	//Write style for Home_contSetup, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_contSetup, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_contSetup, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_contSetup, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_contSetup, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_contSetup, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_contSetup, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_contSetup, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_contSetup, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->Home_contSetup, &_btn_bg_4_100x120, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->Home_contSetup, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_contSetup, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_img_remind
	ui->Home_img_remind = lv_img_create(ui->Home_contSetup);
	lv_obj_add_flag(ui->Home_img_remind, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_img_remind, &_reminder_alpha_37x36);
	lv_img_set_pivot(ui->Home_img_remind, 50,50);
	lv_img_set_angle(ui->Home_img_remind, 0);
	lv_obj_set_pos(ui->Home_img_remind, 52, 12);
	lv_obj_set_size(ui->Home_img_remind, 37, 36);

	//Write style for Home_img_remind, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_img_remind, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_text_remind
	ui->Home_text_remind = lv_label_create(ui->Home_contSetup);
	lv_label_set_text(ui->Home_text_remind, "Remind");
	lv_label_set_long_mode(ui->Home_text_remind, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Home_text_remind, 11, 89);
	lv_obj_set_size(ui->Home_text_remind, 77, 19);
	lv_obj_add_flag(ui->Home_text_remind, LV_OBJ_FLAG_EVENT_BUBBLE);

	//Write style for Home_text_remind, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Home_text_remind, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Home_text_remind, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Home_text_remind, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_text_remind, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_BUT_History
	ui->Home_BUT_History = lv_obj_create(ui->Home_contMain);
	lv_obj_set_pos(ui->Home_BUT_History, 206, 10);
	lv_obj_set_size(ui->Home_BUT_History, 100, 120);
	lv_obj_set_scrollbar_mode(ui->Home_BUT_History, LV_SCROLLBAR_MODE_OFF);

	//Write style for Home_BUT_History, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_BUT_History, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_BUT_History, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_BUT_History, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_BUT_History, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_BUT_History, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_BUT_History, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_BUT_History, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_BUT_History, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->Home_BUT_History, &_btn_bg_3_100x120, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->Home_BUT_History, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_BUT_History, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_img_history
	ui->Home_img_history = lv_img_create(ui->Home_BUT_History);
	lv_obj_add_flag(ui->Home_img_history, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_img_history, &_clock_alpha_39x38);
	lv_img_set_pivot(ui->Home_img_history, 50,50);
	lv_img_set_angle(ui->Home_img_history, 0);
	lv_obj_set_pos(ui->Home_img_history, 48, 15);
	lv_obj_set_size(ui->Home_img_history, 39, 38);
	lv_obj_add_flag(ui->Home_img_history, LV_OBJ_FLAG_EVENT_BUBBLE);

	//Write style for Home_img_history, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_img_history, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_text_history
	ui->Home_text_history = lv_label_create(ui->Home_BUT_History);
	lv_label_set_text(ui->Home_text_history, "History");
	lv_label_set_long_mode(ui->Home_text_history, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Home_text_history, 9, 89);
	lv_obj_set_size(ui->Home_text_history, 77, 19);
	lv_obj_add_flag(ui->Home_text_history, LV_OBJ_FLAG_EVENT_BUBBLE);

	//Write style for Home_text_history, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Home_text_history, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Home_text_history, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Home_text_history, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_text_history, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_BUT_Reserve
	ui->Home_BUT_Reserve = lv_obj_create(ui->Home_contMain);
	lv_obj_set_pos(ui->Home_BUT_Reserve, 7, 10);
	lv_obj_set_size(ui->Home_BUT_Reserve, 100, 120);
	lv_obj_set_scrollbar_mode(ui->Home_BUT_Reserve, LV_SCROLLBAR_MODE_OFF);

	//Write style for Home_BUT_Reserve, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_BUT_Reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_BUT_Reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_BUT_Reserve, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_BUT_Reserve, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_BUT_Reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_BUT_Reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_BUT_Reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_BUT_Reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->Home_BUT_Reserve, &_btn_bg_1_100x120, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->Home_BUT_Reserve, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_BUT_Reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_img_medicine
	ui->Home_img_medicine = lv_img_create(ui->Home_BUT_Reserve);
	lv_obj_add_flag(ui->Home_img_medicine, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_img_medicine, &_pills_alpha_44x40);
	lv_img_set_pivot(ui->Home_img_medicine, 50,50);
	lv_img_set_angle(ui->Home_img_medicine, 0);
	lv_obj_set_pos(ui->Home_img_medicine, 44, 13);
	lv_obj_set_size(ui->Home_img_medicine, 44, 40);

	//Write style for Home_img_medicine, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_img_medicine, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_text_reserve
	ui->Home_text_reserve = lv_label_create(ui->Home_BUT_Reserve);
	lv_label_set_text(ui->Home_text_reserve, "Reserve");
	lv_label_set_long_mode(ui->Home_text_reserve, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Home_text_reserve, 5, 87);
	lv_obj_set_size(ui->Home_text_reserve, 91, 41);
	lv_obj_add_flag(ui->Home_text_reserve, LV_OBJ_FLAG_EVENT_BUBBLE);

	//Write style for Home_text_reserve, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Home_text_reserve, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Home_text_reserve, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Home_text_reserve, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_text_reserve, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_BUT_search
	ui->Home_BUT_search = lv_obj_create(ui->Home_contMain);
	lv_obj_set_pos(ui->Home_BUT_search, 106, 10);
	lv_obj_set_size(ui->Home_BUT_search, 100, 120);
	lv_obj_set_scrollbar_mode(ui->Home_BUT_search, LV_SCROLLBAR_MODE_OFF);

	//Write style for Home_BUT_search, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_BUT_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_BUT_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_BUT_search, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_BUT_search, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_BUT_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_BUT_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_BUT_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_BUT_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->Home_BUT_search, &_btn_bg_2_100x120, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->Home_BUT_search, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_BUT_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_img_search
	ui->Home_img_search = lv_img_create(ui->Home_BUT_search);
	lv_obj_add_flag(ui->Home_img_search, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_img_search, &_search_alpha_37x40);
	lv_img_set_pivot(ui->Home_img_search, 50,50);
	lv_img_set_angle(ui->Home_img_search, 0);
	lv_obj_set_pos(ui->Home_img_search, 49, 14);
	lv_obj_set_size(ui->Home_img_search, 37, 40);
	lv_obj_add_flag(ui->Home_img_search, LV_OBJ_FLAG_EVENT_BUBBLE);

	//Write style for Home_img_search, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_img_search, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_text_search
	ui->Home_text_search = lv_label_create(ui->Home_BUT_search);
	lv_label_set_text(ui->Home_text_search, "Search");
	lv_label_set_long_mode(ui->Home_text_search, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Home_text_search, 8, 89);
	lv_obj_set_size(ui->Home_text_search, 77, 15);
	lv_obj_add_flag(ui->Home_text_search, LV_OBJ_FLAG_EVENT_BUBBLE);

	//Write style for Home_text_search, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Home_text_search, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Home_text_search, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Home_text_search, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_text_search, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_contTop
	ui->Home_contTop = lv_obj_create(ui->Home);
	lv_obj_set_pos(ui->Home_contTop, 11, 2);
	lv_obj_set_size(ui->Home_contTop, 406, 61);
	lv_obj_set_scrollbar_mode(ui->Home_contTop, LV_SCROLLBAR_MODE_OFF);

	//Write style for Home_contTop, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_contTop, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_text_date
	ui->Home_text_date = lv_label_create(ui->Home_contTop);
	lv_label_set_text(ui->Home_text_date, "22 Oct 2023  14:30");
	lv_label_set_long_mode(ui->Home_text_date, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Home_text_date, 242, 21);
	lv_obj_set_size(ui->Home_text_date, 152, 28);

	//Write style for Home_text_date, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Home_text_date, lv_color_hex(0xe9e9e9), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Home_text_date, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Home_text_date, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_text_date, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_BUT_wifi
	ui->Home_BUT_wifi = lv_img_create(ui->Home_contTop);
	lv_obj_add_flag(ui->Home_BUT_wifi, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_BUT_wifi, &_wf_alpha_35x35);
	lv_img_set_pivot(ui->Home_BUT_wifi, 50,50);
	lv_img_set_angle(ui->Home_BUT_wifi, 0);
	lv_obj_set_pos(ui->Home_BUT_wifi, 15, 14);
	lv_obj_set_size(ui->Home_BUT_wifi, 35, 35);

	//Write style for Home_BUT_wifi, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_BUT_wifi, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_BUT_contact
	ui->Home_BUT_contact = lv_img_create(ui->Home_contTop);
	lv_obj_add_flag(ui->Home_BUT_contact, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_BUT_contact, &_telephone_alpha_35x35);
	lv_img_set_pivot(ui->Home_BUT_contact, 50,50);
	lv_img_set_angle(ui->Home_BUT_contact, 0);
	lv_obj_set_pos(ui->Home_BUT_contact, 66, 14);
	lv_obj_set_size(ui->Home_BUT_contact, 35, 35);

	//Write style for Home_BUT_contact, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_BUT_contact, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_BUT_QR
	ui->Home_BUT_QR = lv_img_create(ui->Home_contTop);
	lv_obj_add_flag(ui->Home_BUT_QR, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_BUT_QR, &_qr1_alpha_35x35);
	lv_img_set_pivot(ui->Home_BUT_QR, 50,50);
	lv_img_set_angle(ui->Home_BUT_QR, 0);
	lv_obj_set_pos(ui->Home_BUT_QR, 121, 14);
	lv_obj_set_size(ui->Home_BUT_QR, 35, 35);

	//Write style for Home_BUT_QR, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_BUT_QR, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_BUT_video
	ui->Home_BUT_video = lv_img_create(ui->Home_contTop);
	lv_obj_add_flag(ui->Home_BUT_video, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->Home_BUT_video, &_youtube_alpha_35x35);
	lv_img_set_pivot(ui->Home_BUT_video, 50,50);
	lv_img_set_angle(ui->Home_BUT_video, 0);
	lv_obj_set_pos(ui->Home_BUT_video, 179, 14);
	lv_obj_set_size(ui->Home_BUT_video, 35, 35);

	//Write style for Home_BUT_video, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_img_opa(ui->Home_BUT_video, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_text_recent
	ui->Home_text_recent = lv_label_create(ui->Home);
	lv_label_set_text(ui->Home_text_recent, "\nRecent event:");
	lv_label_set_long_mode(ui->Home_text_recent, LV_LABEL_LONG_SCROLL_CIRCULAR);
	lv_obj_set_pos(ui->Home_text_recent, 21, 227);
	lv_obj_set_size(ui->Home_text_recent, 217, 27);

	//Write style for Home_text_recent, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Home_text_recent, 8, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Home_text_recent, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Home_text_recent, &lv_font_montserratMedium_14, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Home_text_recent, LV_TEXT_ALIGN_RIGHT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Home_text_recent, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_text_recent, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_text_recent, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_win_wifi
	ui->Home_win_wifi = lv_win_create(ui->Home, 40);
	lv_win_add_title(ui->Home_win_wifi, "Wi-Fi");
	ui->Home_win_wifi_item0 = lv_win_add_btn(ui->Home_win_wifi, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *Home_win_wifi_label = lv_label_create(lv_win_get_content(ui->Home_win_wifi));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->Home_win_wifi), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(Home_win_wifi_label, "SSID: MediMind_SSID\nPassword : MediMind_password\n\n");
	lv_obj_set_pos(ui->Home_win_wifi, 49, 48);
	lv_obj_set_size(ui->Home_win_wifi, 400, 177);
	lv_obj_add_flag(ui->Home_win_wifi, LV_OBJ_FLAG_HIDDEN);

	//Write style for Home_win_wifi, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Home_win_wifi, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_win_wifi, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->Home_win_wifi, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_win_wifi, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_wifi_extra_content_main_default
	static lv_style_t style_Home_win_wifi_extra_content_main_default;
	ui_init_style(&style_Home_win_wifi_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_Home_win_wifi_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_Home_win_wifi_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_Home_win_wifi_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Home_win_wifi_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_Home_win_wifi_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_Home_win_wifi_extra_content_main_default, 7);
	lv_obj_add_style(lv_win_get_content(ui->Home_win_wifi), &style_Home_win_wifi_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_wifi_extra_header_main_default
	static lv_style_t style_Home_win_wifi_extra_header_main_default;
	ui_init_style(&style_Home_win_wifi_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_Home_win_wifi_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_Home_win_wifi_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_Home_win_wifi_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Home_win_wifi_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_Home_win_wifi_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_Home_win_wifi_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->Home_win_wifi), &style_Home_win_wifi_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_wifi_extra_btns_main_default
	static lv_style_t style_Home_win_wifi_extra_btns_main_default;
	ui_init_style(&style_Home_win_wifi_extra_btns_main_default);
	
	lv_style_set_radius(&style_Home_win_wifi_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_Home_win_wifi_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Home_win_wifi_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_Home_win_wifi_extra_btns_main_default, 0);
	lv_obj_add_style(ui->Home_win_wifi_item0, &style_Home_win_wifi_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_win_contact
	ui->Home_win_contact = lv_win_create(ui->Home, 40);
	lv_win_add_title(ui->Home_win_contact, "Contact");
	ui->Home_win_contact_item0 = lv_win_add_btn(ui->Home_win_contact, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *Home_win_contact_label = lv_label_create(lv_win_get_content(ui->Home_win_contact));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->Home_win_contact), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(Home_win_contact_label, "Emergency call: 119 or 110\nEmergency\n\n");
	lv_obj_set_pos(ui->Home_win_contact, 49, 48);
	lv_obj_set_size(ui->Home_win_contact, 400, 177);
	lv_obj_add_flag(ui->Home_win_contact, LV_OBJ_FLAG_HIDDEN);

	//Write style for Home_win_contact, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Home_win_contact, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_win_contact, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->Home_win_contact, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_win_contact, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_contact_extra_content_main_default
	static lv_style_t style_Home_win_contact_extra_content_main_default;
	ui_init_style(&style_Home_win_contact_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_Home_win_contact_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_Home_win_contact_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_Home_win_contact_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Home_win_contact_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_Home_win_contact_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_Home_win_contact_extra_content_main_default, 2);
	lv_obj_add_style(lv_win_get_content(ui->Home_win_contact), &style_Home_win_contact_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_contact_extra_header_main_default
	static lv_style_t style_Home_win_contact_extra_header_main_default;
	ui_init_style(&style_Home_win_contact_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_Home_win_contact_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_Home_win_contact_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_Home_win_contact_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Home_win_contact_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_Home_win_contact_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_Home_win_contact_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->Home_win_contact), &style_Home_win_contact_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_contact_extra_btns_main_default
	static lv_style_t style_Home_win_contact_extra_btns_main_default;
	ui_init_style(&style_Home_win_contact_extra_btns_main_default);
	
	lv_style_set_radius(&style_Home_win_contact_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_Home_win_contact_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Home_win_contact_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_Home_win_contact_extra_btns_main_default, 0);
	lv_obj_add_style(ui->Home_win_contact_item0, &style_Home_win_contact_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_win_QR
	ui->Home_win_QR = lv_win_create(ui->Home, 40);
	lv_win_add_title(ui->Home_win_QR, "QRcode-Scan for for information");
	ui->Home_win_QR_item0 = lv_win_add_btn(ui->Home_win_QR, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *Home_win_QR_label = lv_label_create(lv_win_get_content(ui->Home_win_QR));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->Home_win_QR), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(Home_win_QR_label, "\n");
	lv_obj_set_pos(ui->Home_win_QR, 45, 48);
	lv_obj_set_size(ui->Home_win_QR, 400, 177);
	lv_obj_add_flag(ui->Home_win_QR, LV_OBJ_FLAG_HIDDEN);

	//Write style for Home_win_QR, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Home_win_QR, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Home_win_QR, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->Home_win_QR, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Home_win_QR, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_QR_extra_content_main_default
	static lv_style_t style_Home_win_QR_extra_content_main_default;
	ui_init_style(&style_Home_win_QR_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_Home_win_QR_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_Home_win_QR_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_Home_win_QR_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Home_win_QR_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_Home_win_QR_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_Home_win_QR_extra_content_main_default, 2);
	lv_obj_add_style(lv_win_get_content(ui->Home_win_QR), &style_Home_win_QR_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_QR_extra_header_main_default
	static lv_style_t style_Home_win_QR_extra_header_main_default;
	ui_init_style(&style_Home_win_QR_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_Home_win_QR_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_Home_win_QR_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_Home_win_QR_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Home_win_QR_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_Home_win_QR_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_Home_win_QR_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->Home_win_QR), &style_Home_win_QR_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Home_win_QR_extra_btns_main_default
	static lv_style_t style_Home_win_QR_extra_btns_main_default;
	ui_init_style(&style_Home_win_QR_extra_btns_main_default);
	
	lv_style_set_radius(&style_Home_win_QR_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_Home_win_QR_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Home_win_QR_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_Home_win_QR_extra_btns_main_default, 0);
	lv_obj_add_style(ui->Home_win_QR_item0, &style_Home_win_QR_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Home_QRcode
	ui->Home_QRcode = lv_qrcode_create(ui->Home, 115, lv_color_hex(0x2C3224), lv_color_hex(0xffffff));
	const char * Home_QRcode_data = "https://www.nxp.com/";
	lv_qrcode_update(ui->Home_QRcode, Home_QRcode_data, strlen(Home_QRcode_data));
	lv_obj_set_pos(ui->Home_QRcode, 183, 101);
	lv_obj_set_size(ui->Home_QRcode, 115, 115);
	lv_obj_add_flag(ui->Home_QRcode, LV_OBJ_FLAG_HIDDEN);

	//Update current screen layout.
	lv_obj_update_layout(ui->Home);

	
	//Init events for screen.
	events_init_Home(ui);
}
