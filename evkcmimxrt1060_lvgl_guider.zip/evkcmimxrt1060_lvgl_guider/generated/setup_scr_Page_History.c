/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Page_History(lv_ui *ui)
{
	//Write codes Page_History
	ui->Page_History = lv_obj_create(NULL);
	lv_obj_set_size(ui->Page_History, 480, 272);

	//Write style for Page_History, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_History, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_History, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_History_contBG
	ui->Page_History_contBG = lv_obj_create(ui->Page_History);
	lv_obj_set_pos(ui->Page_History_contBG, 0, 0);
	lv_obj_set_size(ui->Page_History_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Page_History_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Page_History_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_History_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_History_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_History_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_History_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_History_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_History_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_History_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_History_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_History_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_History_text_title
	ui->Page_History_text_title = lv_label_create(ui->Page_History_contBG);
	lv_label_set_text(ui->Page_History_text_title, "History");
	lv_label_set_long_mode(ui->Page_History_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_History_text_title, 105, 23);
	lv_obj_set_size(ui->Page_History_text_title, 276, 32);

	//Write style for Page_History_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_History_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_History_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_History_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_History_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_History_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_History_BUT_back
	ui->Page_History_BUT_back = lv_btn_create(ui->Page_History);
	ui->Page_History_BUT_back_label = lv_label_create(ui->Page_History_BUT_back);
	lv_label_set_text(ui->Page_History_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Page_History_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_History_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_History_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_History_BUT_back, 25, 17);
	lv_obj_set_size(ui->Page_History_BUT_back, 35, 32);

	//Write style for Page_History_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_History_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_History_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_History_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_History_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_History_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_History_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_History_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_History_BUT_take
	ui->Page_History_BUT_take = lv_btn_create(ui->Page_History);
	ui->Page_History_BUT_take_label = lv_label_create(ui->Page_History_BUT_take);
	lv_label_set_text(ui->Page_History_BUT_take_label, "Finish");
	lv_label_set_long_mode(ui->Page_History_BUT_take_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Page_History_BUT_take_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Page_History_BUT_take, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Page_History_BUT_take, 366, 224);
	lv_obj_set_size(ui->Page_History_BUT_take, 100, 37);

	//Write style for Page_History_BUT_take, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Page_History_BUT_take, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_History_BUT_take, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_History_BUT_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_History_BUT_take, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_History_BUT_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_History_BUT_take, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_History_BUT_take, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_History_BUT_take, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_History_text_Take
	ui->Page_History_text_Take = lv_label_create(ui->Page_History);
	lv_label_set_text(ui->Page_History_text_Take, "Search by Member:");
	lv_label_set_long_mode(ui->Page_History_text_Take, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Page_History_text_Take, 268, 75);
	lv_obj_set_size(ui->Page_History_text_Take, 176, 23);

	//Write style for Page_History_text_Take, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Page_History_text_Take, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_History_text_Take, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Page_History_text_Take, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_History_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Page_History_INPUT_sugmedlist
	ui->Page_History_INPUT_sugmedlist = lv_dropdown_create(ui->Page_History);
	lv_dropdown_set_options(ui->Page_History_INPUT_sugmedlist, "ALL");
	lv_obj_set_pos(ui->Page_History_INPUT_sugmedlist, 313, 98);
	lv_obj_set_size(ui->Page_History_INPUT_sugmedlist, 125, 34);

	//Write style for Page_History_INPUT_sugmedlist, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Page_History_INPUT_sugmedlist, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Page_History_INPUT_sugmedlist, &lv_font_montserratMedium_15, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Page_History_INPUT_sugmedlist, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Page_History_INPUT_sugmedlist, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Page_History_INPUT_sugmedlist, lv_color_hex(0xe1e6ee), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Page_History_INPUT_sugmedlist, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Page_History_INPUT_sugmedlist, 8, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Page_History_INPUT_sugmedlist, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Page_History_INPUT_sugmedlist, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Page_History_INPUT_sugmedlist, 3, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Page_History_INPUT_sugmedlist, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Page_History_INPUT_sugmedlist, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Page_History_INPUT_sugmedlist, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_CHECKED for &style_Page_History_INPUT_sugmedlist_extra_list_selected_checked
	static lv_style_t style_Page_History_INPUT_sugmedlist_extra_list_selected_checked;
	ui_init_style(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked);
	
	lv_style_set_text_color(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, lv_color_hex(0xffffff));
	lv_style_set_text_font(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, 1);
	lv_style_set_border_opa(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, 255);
	lv_style_set_border_color(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, 3);
	lv_style_set_bg_opa(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, 255);
	lv_style_set_bg_color(&style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, lv_color_hex(0x00a1b5));
	lv_obj_add_style(lv_dropdown_get_list(ui->Page_History_INPUT_sugmedlist), &style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, LV_PART_SELECTED|LV_STATE_CHECKED);

	//Write style state: LV_STATE_DEFAULT for &style_Page_History_INPUT_sugmedlist_extra_list_main_default
	static lv_style_t style_Page_History_INPUT_sugmedlist_extra_list_main_default;
	ui_init_style(&style_Page_History_INPUT_sugmedlist_extra_list_main_default);
	
	lv_style_set_max_height(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, 90);
	lv_style_set_text_color(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, 1);
	lv_style_set_border_opa(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, 255);
	lv_style_set_border_color(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, 3);
	lv_style_set_bg_opa(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, 255);
	lv_style_set_bg_color(&style_Page_History_INPUT_sugmedlist_extra_list_main_default, lv_color_hex(0xffffff));
	lv_obj_add_style(lv_dropdown_get_list(ui->Page_History_INPUT_sugmedlist), &style_Page_History_INPUT_sugmedlist_extra_list_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default
	static lv_style_t style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default;
	ui_init_style(&style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default);
	
	lv_style_set_radius(&style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default, 0);
	lv_obj_add_style(lv_dropdown_get_list(ui->Page_History_INPUT_sugmedlist), &style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Page_History_LIST_suggestedlist
	ui->Page_History_LIST_suggestedlist = lv_list_create(ui->Page_History);
	lv_obj_set_pos(ui->Page_History_LIST_suggestedlist, 29, 75);
	lv_obj_set_size(ui->Page_History_LIST_suggestedlist, 225, 181);
	lv_obj_set_scrollbar_mode(ui->Page_History_LIST_suggestedlist, LV_SCROLLBAR_MODE_ACTIVE);

	//Write style state: LV_STATE_DEFAULT for &style_Page_History_LIST_suggestedlist_main_main_default
	static lv_style_t style_Page_History_LIST_suggestedlist_main_main_default;
	ui_init_style(&style_Page_History_LIST_suggestedlist_main_main_default);
	
	lv_style_set_pad_top(&style_Page_History_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_pad_left(&style_Page_History_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_pad_right(&style_Page_History_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_pad_bottom(&style_Page_History_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_bg_opa(&style_Page_History_LIST_suggestedlist_main_main_default, 255);
	lv_style_set_bg_color(&style_Page_History_LIST_suggestedlist_main_main_default, lv_color_hex(0xffffff));
	lv_style_set_border_width(&style_Page_History_LIST_suggestedlist_main_main_default, 1);
	lv_style_set_border_opa(&style_Page_History_LIST_suggestedlist_main_main_default, 255);
	lv_style_set_border_color(&style_Page_History_LIST_suggestedlist_main_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Page_History_LIST_suggestedlist_main_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Page_History_LIST_suggestedlist_main_main_default, 3);
	lv_style_set_shadow_width(&style_Page_History_LIST_suggestedlist_main_main_default, 0);
	lv_obj_add_style(ui->Page_History_LIST_suggestedlist, &style_Page_History_LIST_suggestedlist_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Page_History_LIST_suggestedlist_main_scrollbar_default
	static lv_style_t style_Page_History_LIST_suggestedlist_main_scrollbar_default;
	ui_init_style(&style_Page_History_LIST_suggestedlist_main_scrollbar_default);
	
	lv_style_set_radius(&style_Page_History_LIST_suggestedlist_main_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Page_History_LIST_suggestedlist_main_scrollbar_default, 255);
	lv_style_set_bg_color(&style_Page_History_LIST_suggestedlist_main_scrollbar_default, lv_color_hex(0xffffff));
	lv_obj_add_style(ui->Page_History_LIST_suggestedlist, &style_Page_History_LIST_suggestedlist_main_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Page_History_LIST_suggestedlist_extra_btns_main_default
	static lv_style_t style_Page_History_LIST_suggestedlist_extra_btns_main_default;
	ui_init_style(&style_Page_History_LIST_suggestedlist_extra_btns_main_default);
	
	lv_style_set_pad_top(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_pad_left(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_pad_right(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_pad_bottom(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_border_width(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, 0);
	lv_style_set_text_color(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, &lv_font_montserratMedium_12);
	lv_style_set_radius(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, 3);
	lv_style_set_bg_opa(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Page_History_LIST_suggestedlist_extra_btns_main_default, lv_color_hex(0xffffff));

	//Write style state: LV_STATE_DEFAULT for &style_Page_History_LIST_suggestedlist_extra_texts_main_default
	static lv_style_t style_Page_History_LIST_suggestedlist_extra_texts_main_default;
	ui_init_style(&style_Page_History_LIST_suggestedlist_extra_texts_main_default);
	
	lv_style_set_pad_top(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_pad_left(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_pad_right(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_pad_bottom(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_border_width(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, 0);
	lv_style_set_text_color(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, &lv_font_montserratMedium_12);
	lv_style_set_radius(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, 3);
	lv_style_set_bg_opa(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, 255);
	lv_style_set_bg_color(&style_Page_History_LIST_suggestedlist_extra_texts_main_default, lv_color_hex(0xffffff));

	//Update current screen layout.
	lv_obj_update_layout(ui->Page_History);

	
	//Init events for screen.
	events_init_Page_History(ui);
}
