# Copyright 2023 NXP
# NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
# accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
# activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
# comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
# terms, then you may not retain, install, activate or otherwise use the software.

import SDL
import utime as time
import usys as sys
import lvgl as lv
import lodepng as png
import ustruct
import fs_driver

lv.init()
SDL.init(w=480,h=272)

# Register SDL display driver.
disp_buf1 = lv.disp_draw_buf_t()
buf1_1 = bytearray(480*10)
disp_buf1.init(buf1_1, None, len(buf1_1)//4)
disp_drv = lv.disp_drv_t()
disp_drv.init()
disp_drv.draw_buf = disp_buf1
disp_drv.flush_cb = SDL.monitor_flush
disp_drv.hor_res = 480
disp_drv.ver_res = 272
disp_drv.register()

# Regsiter SDL mouse driver
indev_drv = lv.indev_drv_t()
indev_drv.init()
indev_drv.type = lv.INDEV_TYPE.POINTER
indev_drv.read_cb = SDL.mouse_read
indev_drv.register()

fs_drv = lv.fs_drv_t()
fs_driver.fs_register(fs_drv, 'Z')

# Below: Taken from https://github.com/lvgl/lv_binding_micropython/blob/master/driver/js/imagetools.py#L22-L94

COLOR_SIZE = lv.color_t.__SIZE__
COLOR_IS_SWAPPED = hasattr(lv.color_t().ch,'green_h')

class lodepng_error(RuntimeError):
    def __init__(self, err):
        if type(err) is int:
            super().__init__(png.error_text(err))
        else:
            super().__init__(err)

# Parse PNG file header
# Taken from https://github.com/shibukawa/imagesize_py/blob/ffef30c1a4715c5acf90e8945ceb77f4a2ed2d45/imagesize.py#L63-L85

def get_png_info(decoder, src, header):
    # Only handle variable image types

    if lv.img.src_get_type(src) != lv.img.SRC.VARIABLE:
        return lv.RES.INV

    data = lv.img_dsc_t.__cast__(src).data
    if data == None:
        return lv.RES.INV

    png_header = bytes(data.__dereference__(24))

    if png_header.startswith(b'\211PNG\r\n\032\n'):
        if png_header[12:16] == b'IHDR':
            start = 16
        # Maybe this is for an older PNG version.
        else:
            start = 8
        try:
            width, height = ustruct.unpack(">LL", png_header[start:start+8])
        except ustruct.error:
            return lv.RES.INV
    else:
        return lv.RES.INV

    header.always_zero = 0
    header.w = width
    header.h = height
    header.cf = lv.img.CF.TRUE_COLOR_ALPHA

    return lv.RES.OK

def convert_rgba8888_to_bgra8888(img_view):
    for i in range(0, len(img_view), lv.color_t.__SIZE__):
        ch = lv.color_t.__cast__(img_view[i:i]).ch
        ch.red, ch.blue = ch.blue, ch.red

# Read and parse PNG file

def open_png(decoder, dsc):
    img_dsc = lv.img_dsc_t.__cast__(dsc.src)
    png_data = img_dsc.data
    png_size = img_dsc.data_size
    png_decoded = png.C_Pointer()
    png_width = png.C_Pointer()
    png_height = png.C_Pointer()
    error = png.decode32(png_decoded, png_width, png_height, png_data, png_size)
    if error:
        raise lodepng_error(error)
    img_size = png_width.int_val * png_height.int_val * 4
    img_data = png_decoded.ptr_val
    img_view = img_data.__dereference__(img_size)

    if COLOR_SIZE == 4:
        convert_rgba8888_to_bgra8888(img_view)
    else:
        raise lodepng_error("Error: Color mode not supported yet!")

    dsc.img_data = img_data
    return lv.RES.OK

# Above: Taken from https://github.com/lvgl/lv_binding_micropython/blob/master/driver/js/imagetools.py#L22-L94

decoder = lv.img.decoder_create()
decoder.info_cb = get_png_info
decoder.open_cb = open_png

def anim_x_cb(obj, v):
    obj.set_x(v)

def anim_y_cb(obj, v):
    obj.set_y(v)

def anim_width_cb(obj, v):
    obj.set_width(v)

def anim_height_cb(obj, v):
    obj.set_height(v)

def anim_img_zoom_cb(obj, v):
    obj.set_zoom(v)

def anim_img_rotate_cb(obj, v):
    obj.set_angle(v)

global_font_cache = {}
def test_font(font_family, font_size):
    global global_font_cache
    if font_family + str(font_size) in global_font_cache:
        return global_font_cache[font_family + str(font_size)]
    if font_size % 2:
        candidates = [
            (font_family, font_size),
            (font_family, font_size-font_size%2),
            (font_family, font_size+font_size%2),
            ("montserrat", font_size-font_size%2),
            ("montserrat", font_size+font_size%2),
            ("montserrat", 16)
        ]
    else:
        candidates = [
            (font_family, font_size),
            ("montserrat", font_size),
            ("montserrat", 16)
        ]
    for (family, size) in candidates:
        try:
            if eval(f'lv.font_{family}_{size}'):
                global_font_cache[font_family + str(font_size)] = eval(f'lv.font_{family}_{size}')
                if family != font_family or size != font_size:
                    print(f'WARNING: lv.font_{family}_{size} is used!')
                return eval(f'lv.font_{family}_{size}')
        except AttributeError:
            try:
                load_font = lv.font_load(f"Z:MicroPython/lv_font_{family}_{size}.fnt")
                global_font_cache[font_family + str(font_size)] = load_font
                return load_font
            except:
                if family == font_family and size == font_size:
                    print(f'WARNING: lv.font_{family}_{size} is NOT supported!')

global_image_cache = {}
def load_image(file):
    global global_image_cache
    if file in global_image_cache:
        return global_image_cache[file]
    try:
        with open(file,'rb') as f:
            data = f.read()
    except:
        print(f'Could not open {file}')
        sys.exit()

    img = lv.img_dsc_t({
        'data_size': len(data),
        'data': data
    })
    global_image_cache[file] = img
    return img

def calendar_event_handler(e,obj):
    code = e.get_code()

    if code == lv.EVENT.VALUE_CHANGED:
        source = e.get_current_target()
        date = lv.calendar_date_t()
        if source.get_pressed_date(date) == lv.RES.OK:
            source.set_highlighted_dates([date], 1)

def spinbox_increment_event_cb(e, obj):
    code = e.get_code()
    if code == lv.EVENT.SHORT_CLICKED or code == lv.EVENT.LONG_PRESSED_REPEAT:
        obj.increment()
def spinbox_decrement_event_cb(e, obj):
    code = e.get_code()
    if code == lv.EVENT.SHORT_CLICKED or code == lv.EVENT.LONG_PRESSED_REPEAT:
        obj.decrement()

def digital_clock_cb(timer, obj, current_time, show_second, use_ampm):
    hour = int(current_time[0])
    minute = int(current_time[1])
    second = int(current_time[2])
    ampm = current_time[3]
    second = second + 1
    if second == 60:
        second = 0
        minute = minute + 1
        if minute == 60:
            minute = 0
            hour = hour + 1
            if use_ampm:
                if hour == 12:
                    if ampm == 'AM':
                        ampm = 'PM'
                    elif ampm == 'PM':
                        ampm = 'AM'
                if hour > 12:
                    hour = hour % 12
    hour = hour % 24
    if use_ampm:
        if show_second:
            obj.set_text("%d:%02d:%02d %s" %(hour, minute, second, ampm))
        else:
            obj.set_text("%d:%02d %s" %(hour, minute, ampm))
    else:
        if show_second:
            obj.set_text("%d:%02d:%02d" %(hour, minute, second))
        else:
            obj.set_text("%d:%02d" %(hour, minute))
    current_time[0] = hour
    current_time[1] = minute
    current_time[2] = second
    current_time[3] = ampm

def analog_clock_cb(timer, obj):
    datetime = time.localtime()
    hour = datetime[3]
    if hour >= 12: hour = hour - 12
    obj.set_time(hour, datetime[4], datetime[5])

def datetext_event_handler(e, obj):
    code = e.get_code()
    target = e.get_target()
    if code == lv.EVENT.FOCUSED:
        if obj is None:
            bg = lv.layer_top()
            bg.add_flag(lv.obj.FLAG.CLICKABLE)
            obj = lv.calendar(bg)
            scr = target.get_screen()
            scr_height = scr.get_height()
            scr_width = scr.get_width()
            obj.set_size(int(scr_width * 0.8), int(scr_height * 0.8))
            datestring = target.get_text()
            year = int(datestring.split('/')[0])
            month = int(datestring.split('/')[1])
            day = int(datestring.split('/')[2])
            obj.set_showed_date(year, month)
            highlighted_days=[lv.calendar_date_t({'year':year, 'month':month, 'day':day})]
            obj.set_highlighted_dates(highlighted_days, 1)
            obj.align(lv.ALIGN.CENTER, 0, 0)
            lv.calendar_header_arrow(obj)
            obj.add_event_cb(lambda e: datetext_calendar_event_handler(e, target), lv.EVENT.ALL, None)
            scr.update_layout()

def datetext_calendar_event_handler(e, obj):
    code = e.get_code()
    target = e.get_current_target()
    if code == lv.EVENT.VALUE_CHANGED:
        date = lv.calendar_date_t()
        if target.get_pressed_date(date) == lv.RES.OK:
            obj.set_text(f"{date.year}/{date.month}/{date.day}")
            bg = lv.layer_top()
            bg.clear_flag(lv.obj.FLAG.CLICKABLE)
            bg.set_style_bg_opa(lv.OPA.TRANSP, 0)
            target.delete()

def Reserve_Manual_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def Search_reccomend_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def Networksetting_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

def AddMember_ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.move_foreground()
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.move_background()
        kb.add_flag(lv.obj.FLAG.HIDDEN)

# Create Home
Home = lv.obj()
Home.set_size(480, 272)
# Set style for Home, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_upimage
Home_upimage = lv.obj(Home)
Home_upimage.set_pos(0, 0)
Home_upimage.set_size(480, 60)
Home_upimage.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Home_upimage, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_upimage.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_upimage.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Home_img_setting
Home_img_setting = lv.img(Home_upimage)
Home_img_setting.set_src("B:MicroPython/_setup_alpha_35x35.bin")
Home_img_setting.add_flag(lv.obj.FLAG.CLICKABLE)
Home_img_setting.set_pivot(50,50)
Home_img_setting.set_angle(0)
Home_img_setting.set_pos(428, 14)
Home_img_setting.set_size(35, 35)
# Set style for Home_img_setting, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_img_setting.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_contMain
Home_contMain = lv.obj(Home)
Home_contMain.set_pos(35, 63)
Home_contMain.set_size(410, 140)
Home_contMain.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Home_contMain, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_contMain.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_radius(7, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contMain.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Home_contSetup
Home_contSetup = lv.obj(Home_contMain)
Home_contSetup.set_pos(306, 10)
Home_contSetup.set_size(100, 120)
Home_contSetup.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Home_contSetup, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_contSetup.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_bg_img_src("B:MicroPython/_btn_bg_4_100x120.bin", lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contSetup.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Home_img_remind
Home_img_remind = lv.img(Home_contSetup)
Home_img_remind.set_src("B:MicroPython/_reminder_alpha_37x36.bin")
Home_img_remind.add_flag(lv.obj.FLAG.CLICKABLE)
Home_img_remind.set_pivot(50,50)
Home_img_remind.set_angle(0)
Home_img_remind.set_pos(52, 12)
Home_img_remind.set_size(37, 36)
# Set style for Home_img_remind, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_img_remind.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_text_remind
Home_text_remind = lv.label(Home_contSetup)
Home_text_remind.set_text("Remind")
Home_text_remind.set_long_mode(lv.label.LONG.WRAP)
Home_text_remind.set_pos(11, 89)
Home_text_remind.set_size(77, 19)
Home_text_remind.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Home_text_remind, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_text_remind.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_remind.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_BUT_History
Home_BUT_History = lv.obj(Home_contMain)
Home_BUT_History.set_pos(206, 10)
Home_BUT_History.set_size(100, 120)
Home_BUT_History.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Home_BUT_History, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_BUT_History.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_bg_img_src("B:MicroPython/_btn_bg_3_100x120.bin", lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_History.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Home_img_history
Home_img_history = lv.img(Home_BUT_History)
Home_img_history.set_src("B:MicroPython/_clock_alpha_39x38.bin")
Home_img_history.add_flag(lv.obj.FLAG.CLICKABLE)
Home_img_history.set_pivot(50,50)
Home_img_history.set_angle(0)
Home_img_history.set_pos(48, 15)
Home_img_history.set_size(39, 38)
Home_img_history.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Home_img_history, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_img_history.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_text_history
Home_text_history = lv.label(Home_BUT_History)
Home_text_history.set_text("History")
Home_text_history.set_long_mode(lv.label.LONG.WRAP)
Home_text_history.set_pos(9, 89)
Home_text_history.set_size(77, 19)
Home_text_history.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Home_text_history, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_text_history.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_history.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_BUT_Reserve
Home_BUT_Reserve = lv.obj(Home_contMain)
Home_BUT_Reserve.set_pos(7, 10)
Home_BUT_Reserve.set_size(100, 120)
Home_BUT_Reserve.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Home_BUT_Reserve, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_BUT_Reserve.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_bg_img_src("B:MicroPython/_btn_bg_1_100x120.bin", lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_Reserve.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Home_img_medicine
Home_img_medicine = lv.img(Home_BUT_Reserve)
Home_img_medicine.set_src("B:MicroPython/_pills_alpha_44x40.bin")
Home_img_medicine.add_flag(lv.obj.FLAG.CLICKABLE)
Home_img_medicine.set_pivot(50,50)
Home_img_medicine.set_angle(0)
Home_img_medicine.set_pos(44, 13)
Home_img_medicine.set_size(44, 40)
# Set style for Home_img_medicine, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_img_medicine.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_text_reserve
Home_text_reserve = lv.label(Home_BUT_Reserve)
Home_text_reserve.set_text("Reserve")
Home_text_reserve.set_long_mode(lv.label.LONG.WRAP)
Home_text_reserve.set_pos(5, 87)
Home_text_reserve.set_size(91, 41)
Home_text_reserve.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Home_text_reserve, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_text_reserve.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_reserve.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_BUT_search
Home_BUT_search = lv.obj(Home_contMain)
Home_BUT_search.set_pos(106, 10)
Home_BUT_search.set_size(100, 120)
Home_BUT_search.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Home_BUT_search, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_BUT_search.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_bg_img_src("B:MicroPython/_btn_bg_2_100x120.bin", lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_bg_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_BUT_search.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Home_img_search
Home_img_search = lv.img(Home_BUT_search)
Home_img_search.set_src("B:MicroPython/_search_alpha_37x40.bin")
Home_img_search.add_flag(lv.obj.FLAG.CLICKABLE)
Home_img_search.set_pivot(50,50)
Home_img_search.set_angle(0)
Home_img_search.set_pos(49, 14)
Home_img_search.set_size(37, 40)
Home_img_search.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Home_img_search, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_img_search.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_text_search
Home_text_search = lv.label(Home_BUT_search)
Home_text_search.set_text("Search")
Home_text_search.set_long_mode(lv.label.LONG.WRAP)
Home_text_search.set_pos(8, 89)
Home_text_search.set_size(77, 15)
Home_text_search.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Home_text_search, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_text_search.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_search.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_contTop
Home_contTop = lv.obj(Home)
Home_contTop.set_pos(11, 2)
Home_contTop.set_size(406, 61)
Home_contTop.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Home_contTop, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_contTop.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contTop.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contTop.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contTop.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contTop.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contTop.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contTop.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_contTop.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Home_text_date
Home_text_date = lv.label(Home_contTop)
Home_text_date.set_text("22 Oct 2023  14:30")
Home_text_date.set_long_mode(lv.label.LONG.WRAP)
Home_text_date.set_pos(242, 21)
Home_text_date.set_size(152, 28)
# Set style for Home_text_date, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_text_date.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_text_color(lv.color_hex(0xe9e9e9), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_date.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_BUT_wifi
Home_BUT_wifi = lv.img(Home_contTop)
Home_BUT_wifi.set_src("B:MicroPython/_wf_alpha_35x35.bin")
Home_BUT_wifi.add_flag(lv.obj.FLAG.CLICKABLE)
Home_BUT_wifi.set_pivot(50,50)
Home_BUT_wifi.set_angle(0)
Home_BUT_wifi.set_pos(15, 14)
Home_BUT_wifi.set_size(35, 35)
# Set style for Home_BUT_wifi, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_BUT_wifi.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_BUT_contact
Home_BUT_contact = lv.img(Home_contTop)
Home_BUT_contact.set_src("B:MicroPython/_telephone_alpha_35x35.bin")
Home_BUT_contact.add_flag(lv.obj.FLAG.CLICKABLE)
Home_BUT_contact.set_pivot(50,50)
Home_BUT_contact.set_angle(0)
Home_BUT_contact.set_pos(66, 14)
Home_BUT_contact.set_size(35, 35)
# Set style for Home_BUT_contact, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_BUT_contact.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_BUT_QR
Home_BUT_QR = lv.img(Home_contTop)
Home_BUT_QR.set_src("B:MicroPython/_qr1_alpha_35x35.bin")
Home_BUT_QR.add_flag(lv.obj.FLAG.CLICKABLE)
Home_BUT_QR.set_pivot(50,50)
Home_BUT_QR.set_angle(0)
Home_BUT_QR.set_pos(121, 14)
Home_BUT_QR.set_size(35, 35)
# Set style for Home_BUT_QR, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_BUT_QR.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_BUT_video
Home_BUT_video = lv.img(Home_contTop)
Home_BUT_video.set_src("B:MicroPython/_youtube_alpha_35x35.bin")
Home_BUT_video.add_flag(lv.obj.FLAG.CLICKABLE)
Home_BUT_video.set_pivot(50,50)
Home_BUT_video.set_angle(0)
Home_BUT_video.set_pos(179, 14)
Home_BUT_video.set_size(35, 35)
# Set style for Home_BUT_video, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_BUT_video.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_text_recent
Home_text_recent = lv.label(Home)
Home_text_recent.set_text("\nRecent event:")
Home_text_recent.set_long_mode(lv.label.LONG.SCROLL_CIRCULAR)
Home_text_recent.set_pos(21, 227)
Home_text_recent.set_size(439, 27)
# Set style for Home_text_recent, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_text_recent.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_radius(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_text_font(test_font("montserratMedium", 14), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_text_align(lv.TEXT_ALIGN.RIGHT, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_text_recent.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_win_wifi
Home_win_wifi = lv.win(Home, 40)
Home_win_wifi.add_title("Wi-Fi")
Home_win_wifi_item0 = Home_win_wifi.add_btn(lv.SYMBOL.CLOSE, 40)
Home_win_wifi_label = lv.label(Home_win_wifi.get_content())
Home_win_wifi.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Home_win_wifi_label.set_text("SSID: MediMind_SSID\nPassword : MediMind_password\n\n")
Home_win_wifi.set_pos(49, 48)
Home_win_wifi.set_size(400, 177)
Home_win_wifi.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Home_win_wifi, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_win_wifi.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_wifi.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_wifi.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_wifi.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_wifi, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_wifi_extra_content_main_default = lv.style_t()
style_Home_win_wifi_extra_content_main_default.init()
style_Home_win_wifi_extra_content_main_default.set_bg_opa(255)
style_Home_win_wifi_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Home_win_wifi_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Home_win_wifi_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Home_win_wifi_extra_content_main_default.set_text_letter_space(0)
style_Home_win_wifi_extra_content_main_default.set_text_line_space(7)
Home_win_wifi.get_content().add_style(style_Home_win_wifi_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_wifi, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_wifi_extra_header_main_default = lv.style_t()
style_Home_win_wifi_extra_header_main_default.init()
style_Home_win_wifi_extra_header_main_default.set_bg_opa(236)
style_Home_win_wifi_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Home_win_wifi_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Home_win_wifi_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Home_win_wifi_extra_header_main_default.set_text_letter_space(0)
style_Home_win_wifi_extra_header_main_default.set_text_line_space(2)
Home_win_wifi.get_header().add_style(style_Home_win_wifi_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_wifi, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_wifi_extra_btns_main_default = lv.style_t()
style_Home_win_wifi_extra_btns_main_default.init()
style_Home_win_wifi_extra_btns_main_default.set_radius(8)
style_Home_win_wifi_extra_btns_main_default.set_bg_opa(255)
style_Home_win_wifi_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Home_win_wifi_extra_btns_main_default.set_shadow_width(0)
Home_win_wifi_item0.add_style(style_Home_win_wifi_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_win_contact
Home_win_contact = lv.win(Home, 40)
Home_win_contact.add_title("Contact")
Home_win_contact_item0 = Home_win_contact.add_btn(lv.SYMBOL.CLOSE, 40)
Home_win_contact_label = lv.label(Home_win_contact.get_content())
Home_win_contact.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Home_win_contact_label.set_text("Emergency call: 119 or 110\nEmergency\n\n")
Home_win_contact.set_pos(49, 48)
Home_win_contact.set_size(400, 177)
Home_win_contact.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Home_win_contact, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_win_contact.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_contact.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_contact.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_contact.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_contact, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_contact_extra_content_main_default = lv.style_t()
style_Home_win_contact_extra_content_main_default.init()
style_Home_win_contact_extra_content_main_default.set_bg_opa(255)
style_Home_win_contact_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Home_win_contact_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Home_win_contact_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Home_win_contact_extra_content_main_default.set_text_letter_space(0)
style_Home_win_contact_extra_content_main_default.set_text_line_space(2)
Home_win_contact.get_content().add_style(style_Home_win_contact_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_contact, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_contact_extra_header_main_default = lv.style_t()
style_Home_win_contact_extra_header_main_default.init()
style_Home_win_contact_extra_header_main_default.set_bg_opa(236)
style_Home_win_contact_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Home_win_contact_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Home_win_contact_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Home_win_contact_extra_header_main_default.set_text_letter_space(0)
style_Home_win_contact_extra_header_main_default.set_text_line_space(2)
Home_win_contact.get_header().add_style(style_Home_win_contact_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_contact, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_contact_extra_btns_main_default = lv.style_t()
style_Home_win_contact_extra_btns_main_default.init()
style_Home_win_contact_extra_btns_main_default.set_radius(8)
style_Home_win_contact_extra_btns_main_default.set_bg_opa(255)
style_Home_win_contact_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Home_win_contact_extra_btns_main_default.set_shadow_width(0)
Home_win_contact_item0.add_style(style_Home_win_contact_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_win_QR
Home_win_QR = lv.win(Home, 40)
Home_win_QR.add_title("QRcode-Scan for for information")
Home_win_QR_item0 = Home_win_QR.add_btn(lv.SYMBOL.CLOSE, 40)
Home_win_QR_label = lv.label(Home_win_QR.get_content())
Home_win_QR.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Home_win_QR_label.set_text("\n")
Home_win_QR.set_pos(45, 48)
Home_win_QR.set_size(400, 177)
Home_win_QR.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Home_win_QR, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Home_win_QR.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_QR.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_QR.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Home_win_QR.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_QR, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_QR_extra_content_main_default = lv.style_t()
style_Home_win_QR_extra_content_main_default.init()
style_Home_win_QR_extra_content_main_default.set_bg_opa(255)
style_Home_win_QR_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Home_win_QR_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Home_win_QR_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Home_win_QR_extra_content_main_default.set_text_letter_space(0)
style_Home_win_QR_extra_content_main_default.set_text_line_space(2)
Home_win_QR.get_content().add_style(style_Home_win_QR_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_QR, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_QR_extra_header_main_default = lv.style_t()
style_Home_win_QR_extra_header_main_default.init()
style_Home_win_QR_extra_header_main_default.set_bg_opa(236)
style_Home_win_QR_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Home_win_QR_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Home_win_QR_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Home_win_QR_extra_header_main_default.set_text_letter_space(0)
style_Home_win_QR_extra_header_main_default.set_text_line_space(2)
Home_win_QR.get_header().add_style(style_Home_win_QR_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Home_win_QR, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Home_win_QR_extra_btns_main_default = lv.style_t()
style_Home_win_QR_extra_btns_main_default.init()
style_Home_win_QR_extra_btns_main_default.set_radius(8)
style_Home_win_QR_extra_btns_main_default.set_bg_opa(255)
style_Home_win_QR_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Home_win_QR_extra_btns_main_default.set_shadow_width(0)
Home_win_QR_item0.add_style(style_Home_win_QR_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Home_QRcode
Home_QRcode = lv.qrcode(Home, 115, lv.color_hex(0x2C3224), lv.color_hex(0xffffff))
Home_QRcode_data = "https://www.nxp.com/"
Home_QRcode.update(Home_QRcode_data, len(Home_QRcode_data))
Home_QRcode.set_pos(183, 101)
Home_QRcode.set_size(115, 115)
Home_QRcode.add_flag(lv.obj.FLAG.HIDDEN)

Home.update_layout()
# Create Video
Video = lv.obj()
Video.set_size(480, 272)
# Set style for Video, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Video.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Video.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Video_contBG
Video_contBG = lv.obj(Video)
Video_contBG.set_pos(0, 0)
Video_contBG.set_size(480, 60)
Video_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Video_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Video_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Video_text_title
Video_text_title = lv.label(Video)
Video_text_title.set_text("Video")
Video_text_title.set_long_mode(lv.label.LONG.WRAP)
Video_text_title.set_pos(135, 23)
Video_text_title.set_size(210, 32)
# Set style for Video_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Video_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Video_BUT_back
Video_BUT_back = lv.btn(Video)
Video_BUT_back_label = lv.label(Video_BUT_back)
Video_BUT_back_label.set_text("<")
Video_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Video_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Video_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Video_BUT_back.set_pos(25, 17)
Video_BUT_back.set_size(35, 32)
# Set style for Video_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Video_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Video_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Video_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Video_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

Video.update_layout()
# Create Page_Reserve
Page_Reserve = lv.obj()
Page_Reserve.set_size(480, 272)
# Set style for Page_Reserve, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Reserve_contBG
Page_Reserve_contBG = lv.obj(Page_Reserve)
Page_Reserve_contBG.set_pos(0, 0)
Page_Reserve_contBG.set_size(480, 60)
Page_Reserve_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Page_Reserve_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Reserve_text_title
Page_Reserve_text_title = lv.label(Page_Reserve)
Page_Reserve_text_title.set_text("Choose Mode")
Page_Reserve_text_title.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_text_title.set_pos(135, 23)
Page_Reserve_text_title.set_size(210, 32)
# Set style for Page_Reserve_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Reserve_BUT_back
Page_Reserve_BUT_back = lv.btn(Page_Reserve)
Page_Reserve_BUT_back_label = lv.label(Page_Reserve_BUT_back)
Page_Reserve_BUT_back_label.set_text("<")
Page_Reserve_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Reserve_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Reserve_BUT_back.set_pos(25, 17)
Page_Reserve_BUT_back.set_size(35, 32)
# Set style for Page_Reserve_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Reserve_BUT_store
Page_Reserve_BUT_store = lv.imgbtn(Page_Reserve)
Page_Reserve_BUT_store.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Reserve_BUT_store.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_package_alpha_102x89.bin", None)
Page_Reserve_BUT_store.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Reserve_BUT_store_label = lv.label(Page_Reserve_BUT_store)
Page_Reserve_BUT_store_label.set_text("")
Page_Reserve_BUT_store_label.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_BUT_store_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Reserve_BUT_store.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Reserve_BUT_store.set_pos(33, 111)
Page_Reserve_BUT_store.set_size(102, 89)
# Set style for Page_Reserve_BUT_store, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_BUT_store.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_store.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_store.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_store.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Reserve_BUT_store, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Page_Reserve_BUT_store.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_store.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_store.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_store.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Page_Reserve_BUT_store, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Page_Reserve_BUT_store.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_store.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_store.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_store.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Page_Reserve_BUT_store, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Page_Reserve_BUT_store.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Page_Reserve_text_store
Page_Reserve_text_store = lv.label(Page_Reserve)
Page_Reserve_text_store.set_text("store\n")
Page_Reserve_text_store.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_text_store.set_pos(27, 211)
Page_Reserve_text_store.set_size(108, 14)
# Set style for Page_Reserve_text_store, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_text_store.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_store.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Reserve_BUT_take
Page_Reserve_BUT_take = lv.imgbtn(Page_Reserve)
Page_Reserve_BUT_take.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Reserve_BUT_take.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_takeaway_alpha_105x110.bin", None)
Page_Reserve_BUT_take.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Reserve_BUT_take_label = lv.label(Page_Reserve_BUT_take)
Page_Reserve_BUT_take_label.set_text("")
Page_Reserve_BUT_take_label.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_BUT_take_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Reserve_BUT_take.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Reserve_BUT_take.set_pos(188, 90)
Page_Reserve_BUT_take.set_size(105, 110)
# Set style for Page_Reserve_BUT_take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_BUT_take.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_take.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Reserve_BUT_take, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Page_Reserve_BUT_take.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_take.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_take.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Page_Reserve_BUT_take, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Page_Reserve_BUT_take.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_take.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_take.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Page_Reserve_BUT_take, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Page_Reserve_BUT_take.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Page_Reserve_text_take
Page_Reserve_text_take = lv.label(Page_Reserve)
Page_Reserve_text_take.set_text("Take\n")
Page_Reserve_text_take.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_text_take.set_pos(217, 209)
Page_Reserve_text_take.set_size(47, 16)
# Set style for Page_Reserve_text_take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_text_take.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Reserve_BUT_storage
Page_Reserve_BUT_storage = lv.imgbtn(Page_Reserve)
Page_Reserve_BUT_storage.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Reserve_BUT_storage.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_warehouse_alpha_105x90.bin", None)
Page_Reserve_BUT_storage.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Reserve_BUT_storage_label = lv.label(Page_Reserve_BUT_storage)
Page_Reserve_BUT_storage_label.set_text("")
Page_Reserve_BUT_storage_label.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_BUT_storage_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Reserve_BUT_storage.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Reserve_BUT_storage.set_pos(345, 110)
Page_Reserve_BUT_storage.set_size(105, 90)
# Set style for Page_Reserve_BUT_storage, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_BUT_storage.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_storage.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_storage.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_BUT_storage.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Reserve_BUT_storage, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Page_Reserve_BUT_storage.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_storage.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_storage.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Reserve_BUT_storage.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Page_Reserve_BUT_storage, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Page_Reserve_BUT_storage.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_storage.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_storage.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Reserve_BUT_storage.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Page_Reserve_BUT_storage, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Page_Reserve_BUT_storage.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Page_Reserve_text_storage
Page_Reserve_text_storage = lv.label(Page_Reserve)
Page_Reserve_text_storage.set_text("Storage")
Page_Reserve_text_storage.set_long_mode(lv.label.LONG.WRAP)
Page_Reserve_text_storage.set_pos(350, 209)
Page_Reserve_text_storage.set_size(100, 32)
# Set style for Page_Reserve_text_storage, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Reserve_text_storage.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Reserve_text_storage.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

Page_Reserve.update_layout()
# Create Reserve_Storeby
Reserve_Storeby = lv.obj()
Reserve_Storeby.set_size(480, 272)
# Set style for Reserve_Storeby, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storeby_contBG
Reserve_Storeby_contBG = lv.obj(Reserve_Storeby)
Reserve_Storeby_contBG.set_pos(0, 0)
Reserve_Storeby_contBG.set_size(480, 60)
Reserve_Storeby_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Reserve_Storeby_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storeby_text_title
Reserve_Storeby_text_title = lv.label(Reserve_Storeby)
Reserve_Storeby_text_title.set_text("Storing by...")
Reserve_Storeby_text_title.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storeby_text_title.set_pos(135, 23)
Reserve_Storeby_text_title.set_size(210, 32)
# Set style for Reserve_Storeby_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storeby_BUT_back
Reserve_Storeby_BUT_back = lv.btn(Reserve_Storeby)
Reserve_Storeby_BUT_back_label = lv.label(Reserve_Storeby_BUT_back)
Reserve_Storeby_BUT_back_label.set_text("<")
Reserve_Storeby_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storeby_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Storeby_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Storeby_BUT_back.set_pos(25, 17)
Reserve_Storeby_BUT_back.set_size(35, 32)
# Set style for Reserve_Storeby_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storeby_BUT_Camera
Reserve_Storeby_BUT_Camera = lv.imgbtn(Reserve_Storeby)
Reserve_Storeby_BUT_Camera.add_flag(lv.obj.FLAG.CHECKABLE)
Reserve_Storeby_BUT_Camera.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_camera_alpha_102x89.bin", None)
Reserve_Storeby_BUT_Camera.add_flag(lv.obj.FLAG.CHECKABLE)
Reserve_Storeby_BUT_Camera_label = lv.label(Reserve_Storeby_BUT_Camera)
Reserve_Storeby_BUT_Camera_label.set_text("")
Reserve_Storeby_BUT_Camera_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storeby_BUT_Camera_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Storeby_BUT_Camera.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Camera.set_pos(105, 111)
Reserve_Storeby_BUT_Camera.set_size(102, 89)
# Set style for Reserve_Storeby_BUT_Camera, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby_BUT_Camera.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Camera.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Camera.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Camera.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Storeby_BUT_Camera, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Reserve_Storeby_BUT_Camera.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Reserve_Storeby_BUT_Camera.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Reserve_Storeby_BUT_Camera.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Reserve_Storeby_BUT_Camera.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Reserve_Storeby_BUT_Camera, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Reserve_Storeby_BUT_Camera.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Reserve_Storeby_BUT_Camera.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Reserve_Storeby_BUT_Camera.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Reserve_Storeby_BUT_Camera.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Reserve_Storeby_BUT_Camera, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Reserve_Storeby_BUT_Camera.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Reserve_Storeby_text_camera
Reserve_Storeby_text_camera = lv.label(Reserve_Storeby)
Reserve_Storeby_text_camera.set_text("Camera\n")
Reserve_Storeby_text_camera.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storeby_text_camera.set_pos(99, 211)
Reserve_Storeby_text_camera.set_size(108, 14)
# Set style for Reserve_Storeby_text_camera, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby_text_camera.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_camera.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storeby_BUT_Manual
Reserve_Storeby_BUT_Manual = lv.imgbtn(Reserve_Storeby)
Reserve_Storeby_BUT_Manual.add_flag(lv.obj.FLAG.CHECKABLE)
Reserve_Storeby_BUT_Manual.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_hand_alpha_105x110.bin", None)
Reserve_Storeby_BUT_Manual.add_flag(lv.obj.FLAG.CHECKABLE)
Reserve_Storeby_BUT_Manual_label = lv.label(Reserve_Storeby_BUT_Manual)
Reserve_Storeby_BUT_Manual_label.set_text("")
Reserve_Storeby_BUT_Manual_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storeby_BUT_Manual_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Storeby_BUT_Manual.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Manual.set_pos(291, 90)
Reserve_Storeby_BUT_Manual.set_size(105, 110)
# Set style for Reserve_Storeby_BUT_Manual, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby_BUT_Manual.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Manual.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Manual.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_BUT_Manual.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Storeby_BUT_Manual, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Reserve_Storeby_BUT_Manual.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Reserve_Storeby_BUT_Manual.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Reserve_Storeby_BUT_Manual.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Reserve_Storeby_BUT_Manual.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Reserve_Storeby_BUT_Manual, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Reserve_Storeby_BUT_Manual.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Reserve_Storeby_BUT_Manual.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Reserve_Storeby_BUT_Manual.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Reserve_Storeby_BUT_Manual.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Reserve_Storeby_BUT_Manual, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Reserve_Storeby_BUT_Manual.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Reserve_Storeby_text_take
Reserve_Storeby_text_take = lv.label(Reserve_Storeby)
Reserve_Storeby_text_take.set_text("Manual")
Reserve_Storeby_text_take.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storeby_text_take.set_pos(306, 209)
Reserve_Storeby_text_take.set_size(74, 16)
# Set style for Reserve_Storeby_text_take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storeby_text_take.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storeby_text_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

Reserve_Storeby.update_layout()
# Create Reverse_Camera
Reverse_Camera = lv.obj()
Reverse_Camera.set_size(480, 272)
# Set style for Reverse_Camera, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_contBG
Reverse_Camera_contBG = lv.obj(Reverse_Camera)
Reverse_Camera_contBG.set_pos(0, 0)
Reverse_Camera_contBG.set_size(480, 60)
Reverse_Camera_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Reverse_Camera_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_text_title
Reverse_Camera_text_title = lv.label(Reverse_Camera)
Reverse_Camera_text_title.set_text("Storing Medicine")
Reverse_Camera_text_title.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_text_title.set_pos(135, 23)
Reverse_Camera_text_title.set_size(210, 32)
# Set style for Reverse_Camera_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_text_put
Reverse_Camera_text_put = lv.label(Reverse_Camera)
Reverse_Camera_text_put.set_text("Put your medicine under camera...")
Reverse_Camera_text_put.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_text_put.set_pos(25, 108)
Reverse_Camera_text_put.set_size(289, 21)
# Set style for Reverse_Camera_text_put, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_text_put.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_put.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_text_user
Reverse_Camera_text_user = lv.label(Reverse_Camera)
Reverse_Camera_text_user.set_text("User :")
Reverse_Camera_text_user.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_text_user.set_pos(18, 77)
Reverse_Camera_text_user.set_size(72, 17)
# Set style for Reverse_Camera_text_user, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_text_user.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_user.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_text_num
Reverse_Camera_text_num = lv.label(Reverse_Camera)
Reverse_Camera_text_num.set_text("Numbers")
Reverse_Camera_text_num.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_text_num.set_pos(210, 137)
Reverse_Camera_text_num.set_size(100, 32)
# Set style for Reverse_Camera_text_num, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_text_num.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_num.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_text_med
Reverse_Camera_text_med = lv.label(Reverse_Camera)
Reverse_Camera_text_med.set_text("Medicine")
Reverse_Camera_text_med.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_text_med.set_pos(71, 137)
Reverse_Camera_text_med.set_size(100, 32)
# Set style for Reverse_Camera_text_med, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_text_med.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_text_med.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_BUT_back
Reverse_Camera_BUT_back = lv.btn(Reverse_Camera)
Reverse_Camera_BUT_back_label = lv.label(Reverse_Camera_BUT_back)
Reverse_Camera_BUT_back_label.set_text("<")
Reverse_Camera_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Reverse_Camera_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Reverse_Camera_BUT_back.set_pos(25, 17)
Reverse_Camera_BUT_back.set_size(35, 32)
# Set style for Reverse_Camera_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_BUT_add
Reverse_Camera_BUT_add = lv.btn(Reverse_Camera)
Reverse_Camera_BUT_add_label = lv.label(Reverse_Camera_BUT_add)
Reverse_Camera_BUT_add_label.set_text("Add")
Reverse_Camera_BUT_add_label.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_BUT_add_label.align(lv.ALIGN.CENTER, 0, 0)
Reverse_Camera_BUT_add.set_style_pad_all(0, lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_pos(98, 205)
Reverse_Camera_BUT_add.set_size(91, 29)
# Set style for Reverse_Camera_BUT_add, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_BUT_add.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_add.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_BUT_rescan
Reverse_Camera_BUT_rescan = lv.btn(Reverse_Camera)
Reverse_Camera_BUT_rescan_label = lv.label(Reverse_Camera_BUT_rescan)
Reverse_Camera_BUT_rescan_label.set_text("Re-Scan")
Reverse_Camera_BUT_rescan_label.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_BUT_rescan_label.align(lv.ALIGN.CENTER, 0, 0)
Reverse_Camera_BUT_rescan.set_style_pad_all(0, lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_pos(196, 205)
Reverse_Camera_BUT_rescan.set_size(91, 29)
# Set style for Reverse_Camera_BUT_rescan, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_BUT_rescan.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_rescan.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_BUT_home
Reverse_Camera_BUT_home = lv.btn(Reverse_Camera)
Reverse_Camera_BUT_home_label = lv.label(Reverse_Camera_BUT_home)
Reverse_Camera_BUT_home_label.set_text("Finish")
Reverse_Camera_BUT_home_label.set_long_mode(lv.label.LONG.WRAP)
Reverse_Camera_BUT_home_label.align(lv.ALIGN.CENTER, 0, 0)
Reverse_Camera_BUT_home.set_style_pad_all(0, lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_pos(366, 224)
Reverse_Camera_BUT_home.set_size(100, 37)
# Set style for Reverse_Camera_BUT_home, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_BUT_home.set_style_bg_opa(204, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_BUT_home.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reverse_Camera_SCAN_med
Reverse_Camera_SCAN_med = lv.textarea(Reverse_Camera)
Reverse_Camera_SCAN_med.set_text("")
Reverse_Camera_SCAN_med.set_password_bullet("*")
Reverse_Camera_SCAN_med.set_password_mode(False)
Reverse_Camera_SCAN_med.set_one_line(True)
Reverse_Camera_SCAN_med.set_pos(54, 161)
Reverse_Camera_SCAN_med.set_size(135, 29)
# Set style for Reverse_Camera_SCAN_med, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_SCAN_med.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reverse_Camera_SCAN_med, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Reverse_Camera_SCAN_med.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_med.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reverse_Camera_SCAN_num
Reverse_Camera_SCAN_num = lv.textarea(Reverse_Camera)
Reverse_Camera_SCAN_num.set_text("")
Reverse_Camera_SCAN_num.set_password_bullet("*")
Reverse_Camera_SCAN_num.set_password_mode(False)
Reverse_Camera_SCAN_num.set_one_line(False)
Reverse_Camera_SCAN_num.set_pos(196, 161)
Reverse_Camera_SCAN_num.set_size(135, 29)
# Set style for Reverse_Camera_SCAN_num, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_SCAN_num.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reverse_Camera_SCAN_num, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Reverse_Camera_SCAN_num.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Reverse_Camera_SCAN_num.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reverse_Camera_INPUT_User
Reverse_Camera_INPUT_User = lv.dropdown(Reverse_Camera)
Reverse_Camera_INPUT_User.set_options("Brian\nJohnson\nMax")
Reverse_Camera_INPUT_User.set_pos(90, 70)
Reverse_Camera_INPUT_User.set_size(130, 30)
# Set style for Reverse_Camera_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_INPUT_User.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_text_font(test_font("montserratMedium", 15), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_INPUT_User.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reverse_Camera_INPUT_User, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Reverse_Camera_INPUT_User_extra_list_selected_checked = lv.style_t()
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.init()
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 15))
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_border_width(1)
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_border_opa(255)
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_radius(3)
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_bg_opa(255)
style_Reverse_Camera_INPUT_User_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Reverse_Camera_INPUT_User.get_list().add_style(style_Reverse_Camera_INPUT_User_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Reverse_Camera_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reverse_Camera_INPUT_User_extra_list_main_default = lv.style_t()
style_Reverse_Camera_INPUT_User_extra_list_main_default.init()
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_max_height(90)
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_border_width(1)
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_border_opa(255)
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_radius(3)
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_bg_opa(255)
style_Reverse_Camera_INPUT_User_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Reverse_Camera_INPUT_User.get_list().add_style(style_Reverse_Camera_INPUT_User_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reverse_Camera_INPUT_User, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default = lv.style_t()
style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default.init()
style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default.set_radius(3)
style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default.set_bg_opa(0)
Reverse_Camera_INPUT_User.get_list().add_style(style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reverse_Camera_win_success
Reverse_Camera_win_success = lv.win(Reverse_Camera, 40)
Reverse_Camera_win_success.add_title("System")
Reverse_Camera_win_success_item0 = Reverse_Camera_win_success.add_btn(lv.SYMBOL.CLOSE, 40)
Reverse_Camera_win_success_label = lv.label(Reverse_Camera_win_success.get_content())
Reverse_Camera_win_success.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Reverse_Camera_win_success_label.set_text("Storing successfully!!\n")
Reverse_Camera_win_success.set_pos(49, 48)
Reverse_Camera_win_success.set_size(400, 177)
Reverse_Camera_win_success.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Reverse_Camera_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reverse_Camera_win_success.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_win_success.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_win_success.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reverse_Camera_win_success.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reverse_Camera_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reverse_Camera_win_success_extra_content_main_default = lv.style_t()
style_Reverse_Camera_win_success_extra_content_main_default.init()
style_Reverse_Camera_win_success_extra_content_main_default.set_bg_opa(255)
style_Reverse_Camera_win_success_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reverse_Camera_win_success_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reverse_Camera_win_success_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Reverse_Camera_win_success_extra_content_main_default.set_text_letter_space(0)
style_Reverse_Camera_win_success_extra_content_main_default.set_text_line_space(2)
Reverse_Camera_win_success.get_content().add_style(style_Reverse_Camera_win_success_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reverse_Camera_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reverse_Camera_win_success_extra_header_main_default = lv.style_t()
style_Reverse_Camera_win_success_extra_header_main_default.init()
style_Reverse_Camera_win_success_extra_header_main_default.set_bg_opa(236)
style_Reverse_Camera_win_success_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Reverse_Camera_win_success_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reverse_Camera_win_success_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reverse_Camera_win_success_extra_header_main_default.set_text_letter_space(0)
style_Reverse_Camera_win_success_extra_header_main_default.set_text_line_space(2)
Reverse_Camera_win_success.get_header().add_style(style_Reverse_Camera_win_success_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reverse_Camera_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reverse_Camera_win_success_extra_btns_main_default = lv.style_t()
style_Reverse_Camera_win_success_extra_btns_main_default.init()
style_Reverse_Camera_win_success_extra_btns_main_default.set_radius(8)
style_Reverse_Camera_win_success_extra_btns_main_default.set_bg_opa(255)
style_Reverse_Camera_win_success_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reverse_Camera_win_success_extra_btns_main_default.set_shadow_width(0)
Reverse_Camera_win_success_item0.add_style(style_Reverse_Camera_win_success_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

Reverse_Camera.update_layout()
# Create Reserve_Manual
Reserve_Manual = lv.obj()
g_kb_Reserve_Manual = lv.keyboard(Reserve_Manual)
g_kb_Reserve_Manual.add_event_cb(lambda e: Reserve_Manual_ta_event_cb(e, g_kb_Reserve_Manual), lv.EVENT.ALL, None)
g_kb_Reserve_Manual.add_flag(lv.obj.FLAG.HIDDEN)
g_kb_Reserve_Manual.set_style_text_font(test_font("simsun", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual.set_size(480, 272)
# Set style for Reserve_Manual, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_contBG
Reserve_Manual_contBG = lv.obj(Reserve_Manual)
Reserve_Manual_contBG.set_pos(0, 0)
Reserve_Manual_contBG.set_size(480, 60)
Reserve_Manual_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Reserve_Manual_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Reserve_Manual_BUT_back
Reserve_Manual_BUT_back = lv.btn(Reserve_Manual_contBG)
Reserve_Manual_BUT_back_label = lv.label(Reserve_Manual_BUT_back)
Reserve_Manual_BUT_back_label.set_text("<")
Reserve_Manual_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Manual_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Manual_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Manual_BUT_back.set_pos(25, 17)
Reserve_Manual_BUT_back.set_size(35, 32)
# Set style for Reserve_Manual_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_text_title
Reserve_Manual_text_title = lv.label(Reserve_Manual)
Reserve_Manual_text_title.set_text("Storing Medicine")
Reserve_Manual_text_title.set_long_mode(lv.label.LONG.WRAP)
Reserve_Manual_text_title.set_pos(135, 23)
Reserve_Manual_text_title.set_size(210, 32)
# Set style for Reserve_Manual_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_text_user
Reserve_Manual_text_user = lv.label(Reserve_Manual)
Reserve_Manual_text_user.set_text("User")
Reserve_Manual_text_user.set_long_mode(lv.label.LONG.WRAP)
Reserve_Manual_text_user.set_pos(49, 97)
Reserve_Manual_text_user.set_size(100, 32)
# Set style for Reserve_Manual_text_user, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_text_user.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_user.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_text_medicine
Reserve_Manual_text_medicine = lv.label(Reserve_Manual)
Reserve_Manual_text_medicine.set_text("Medicine")
Reserve_Manual_text_medicine.set_long_mode(lv.label.LONG.WRAP)
Reserve_Manual_text_medicine.set_pos(190, 97)
Reserve_Manual_text_medicine.set_size(100, 32)
# Set style for Reserve_Manual_text_medicine, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_text_medicine.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_medicine.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_text_num
Reserve_Manual_text_num = lv.label(Reserve_Manual)
Reserve_Manual_text_num.set_text("Numbers")
Reserve_Manual_text_num.set_long_mode(lv.label.LONG.WRAP)
Reserve_Manual_text_num.set_pos(329, 97)
Reserve_Manual_text_num.set_size(100, 32)
# Set style for Reserve_Manual_text_num, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_text_num.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_text_num.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_BUT_home
Reserve_Manual_BUT_home = lv.btn(Reserve_Manual)
Reserve_Manual_BUT_home_label = lv.label(Reserve_Manual_BUT_home)
Reserve_Manual_BUT_home_label.set_text("Finish")
Reserve_Manual_BUT_home_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Manual_BUT_home_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Manual_BUT_home.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_pos(366, 224)
Reserve_Manual_BUT_home.set_size(100, 37)
# Set style for Reserve_Manual_BUT_home, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_BUT_home.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_home.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_BUT_store
Reserve_Manual_BUT_store = lv.btn(Reserve_Manual)
Reserve_Manual_BUT_store_label = lv.label(Reserve_Manual_BUT_store)
Reserve_Manual_BUT_store_label.set_text("store")
Reserve_Manual_BUT_store_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Manual_BUT_store_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Manual_BUT_store.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_pos(259, 224)
Reserve_Manual_BUT_store.set_size(100, 37)
# Set style for Reserve_Manual_BUT_store, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_BUT_store.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_BUT_store.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Manual_INPUT_User
Reserve_Manual_INPUT_User = lv.dropdown(Reserve_Manual)
Reserve_Manual_INPUT_User.set_options("Brian\nJohnson\nMax")
Reserve_Manual_INPUT_User.set_pos(34, 121)
Reserve_Manual_INPUT_User.set_size(130, 30)
# Set style for Reserve_Manual_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_INPUT_User.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_User.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Manual_INPUT_User, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Reserve_Manual_INPUT_User_extra_list_selected_checked = lv.style_t()
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.init()
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_border_width(1)
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_border_opa(255)
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_radius(3)
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_bg_opa(255)
style_Reserve_Manual_INPUT_User_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Reserve_Manual_INPUT_User.get_list().add_style(style_Reserve_Manual_INPUT_User_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Reserve_Manual_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Manual_INPUT_User_extra_list_main_default = lv.style_t()
style_Reserve_Manual_INPUT_User_extra_list_main_default.init()
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_max_height(90)
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_border_width(1)
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_border_opa(255)
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_radius(3)
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_bg_opa(255)
style_Reserve_Manual_INPUT_User_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Reserve_Manual_INPUT_User.get_list().add_style(style_Reserve_Manual_INPUT_User_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Manual_INPUT_User, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default = lv.style_t()
style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default.init()
style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default.set_radius(3)
style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default.set_bg_opa(0)
Reserve_Manual_INPUT_User.get_list().add_style(style_Reserve_Manual_INPUT_User_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reserve_Manual_INPUT_num
Reserve_Manual_INPUT_num = lv.textarea(Reserve_Manual)
Reserve_Manual_INPUT_num.set_text("")
Reserve_Manual_INPUT_num.set_password_bullet("*")
Reserve_Manual_INPUT_num.set_password_mode(False)
Reserve_Manual_INPUT_num.set_one_line(True)
Reserve_Manual_INPUT_num.add_event_cb(lambda e: Reserve_Manual_ta_event_cb(e, g_kb_Reserve_Manual), lv.EVENT.ALL, None)
Reserve_Manual_INPUT_num.set_pos(318, 121)
Reserve_Manual_INPUT_num.set_size(135, 29)
# Set style for Reserve_Manual_INPUT_num, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_INPUT_num.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Manual_INPUT_num, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Reserve_Manual_INPUT_num.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_num.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reserve_Manual_INPUT_medicine
Reserve_Manual_INPUT_medicine = lv.textarea(Reserve_Manual)
Reserve_Manual_INPUT_medicine.set_text("")
Reserve_Manual_INPUT_medicine.set_password_bullet("*")
Reserve_Manual_INPUT_medicine.set_password_mode(False)
Reserve_Manual_INPUT_medicine.set_one_line(True)
Reserve_Manual_INPUT_medicine.add_event_cb(lambda e: Reserve_Manual_ta_event_cb(e, g_kb_Reserve_Manual), lv.EVENT.ALL, None)
Reserve_Manual_INPUT_medicine.set_pos(173, 121)
Reserve_Manual_INPUT_medicine.set_size(135, 29)
# Set style for Reserve_Manual_INPUT_medicine, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_INPUT_medicine.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Manual_INPUT_medicine, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Reserve_Manual_INPUT_medicine.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Reserve_Manual_INPUT_medicine.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reserve_Manual_win_success
Reserve_Manual_win_success = lv.win(Reserve_Manual, 40)
Reserve_Manual_win_success.add_title("System")
Reserve_Manual_win_success_item0 = Reserve_Manual_win_success.add_btn(lv.SYMBOL.CLOSE, 40)
Reserve_Manual_win_success_label = lv.label(Reserve_Manual_win_success.get_content())
Reserve_Manual_win_success.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Reserve_Manual_win_success_label.set_text("Storing successfully!!\n")
Reserve_Manual_win_success.set_pos(49, 48)
Reserve_Manual_win_success.set_size(400, 177)
Reserve_Manual_win_success.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Reserve_Manual_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Manual_win_success.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_win_success.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_win_success.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Manual_win_success.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Manual_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Manual_win_success_extra_content_main_default = lv.style_t()
style_Reserve_Manual_win_success_extra_content_main_default.init()
style_Reserve_Manual_win_success_extra_content_main_default.set_bg_opa(255)
style_Reserve_Manual_win_success_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reserve_Manual_win_success_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reserve_Manual_win_success_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Reserve_Manual_win_success_extra_content_main_default.set_text_letter_space(0)
style_Reserve_Manual_win_success_extra_content_main_default.set_text_line_space(2)
Reserve_Manual_win_success.get_content().add_style(style_Reserve_Manual_win_success_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Manual_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Manual_win_success_extra_header_main_default = lv.style_t()
style_Reserve_Manual_win_success_extra_header_main_default.init()
style_Reserve_Manual_win_success_extra_header_main_default.set_bg_opa(236)
style_Reserve_Manual_win_success_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Reserve_Manual_win_success_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reserve_Manual_win_success_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Manual_win_success_extra_header_main_default.set_text_letter_space(0)
style_Reserve_Manual_win_success_extra_header_main_default.set_text_line_space(2)
Reserve_Manual_win_success.get_header().add_style(style_Reserve_Manual_win_success_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Manual_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Manual_win_success_extra_btns_main_default = lv.style_t()
style_Reserve_Manual_win_success_extra_btns_main_default.init()
style_Reserve_Manual_win_success_extra_btns_main_default.set_radius(8)
style_Reserve_Manual_win_success_extra_btns_main_default.set_bg_opa(255)
style_Reserve_Manual_win_success_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reserve_Manual_win_success_extra_btns_main_default.set_shadow_width(0)
Reserve_Manual_win_success_item0.add_style(style_Reserve_Manual_win_success_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

Reserve_Manual.update_layout()
# Create Reserve_Take
Reserve_Take = lv.obj()
Reserve_Take.set_size(480, 272)
# Set style for Reserve_Take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_contBG
Reserve_Take_contBG = lv.obj(Reserve_Take)
Reserve_Take_contBG.set_pos(0, 0)
Reserve_Take_contBG.set_size(480, 60)
Reserve_Take_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Reserve_Take_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Reserve_Take_btn_2
Reserve_Take_btn_2 = lv.btn(Reserve_Take_contBG)
Reserve_Take_btn_2_label = lv.label(Reserve_Take_btn_2)
Reserve_Take_btn_2_label.set_text("<")
Reserve_Take_btn_2_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Take_btn_2_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Take_btn_2.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Take_btn_2.set_pos(25, 17)
Reserve_Take_btn_2.set_size(35, 32)
# Set style for Reserve_Take_btn_2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_btn_2.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_btn_2.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_btn_2.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_btn_2.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_btn_2.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_btn_2.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_btn_2.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_BUT_back
Reserve_Take_BUT_back = lv.label(Reserve_Take_contBG)
Reserve_Take_BUT_back.set_text("Taking out Medicine")
Reserve_Take_BUT_back.set_long_mode(lv.label.LONG.WRAP)
Reserve_Take_BUT_back.set_pos(117, 22)
Reserve_Take_BUT_back.set_size(246, 32)
# Set style for Reserve_Take_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_text_User
Reserve_Take_text_User = lv.label(Reserve_Take)
Reserve_Take_text_User.set_text("User")
Reserve_Take_text_User.set_long_mode(lv.label.LONG.WRAP)
Reserve_Take_text_User.set_pos(49, 97)
Reserve_Take_text_User.set_size(100, 32)
# Set style for Reserve_Take_text_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_text_User.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_User.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_text_medicine
Reserve_Take_text_medicine = lv.label(Reserve_Take)
Reserve_Take_text_medicine.set_text("Medicine")
Reserve_Take_text_medicine.set_long_mode(lv.label.LONG.WRAP)
Reserve_Take_text_medicine.set_pos(190, 97)
Reserve_Take_text_medicine.set_size(100, 32)
# Set style for Reserve_Take_text_medicine, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_text_medicine.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_medicine.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_text_number
Reserve_Take_text_number = lv.label(Reserve_Take)
Reserve_Take_text_number.set_text("Numbers")
Reserve_Take_text_number.set_long_mode(lv.label.LONG.WRAP)
Reserve_Take_text_number.set_pos(329, 97)
Reserve_Take_text_number.set_size(100, 32)
# Set style for Reserve_Take_text_number, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_text_number.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_text_number.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_BUT_home
Reserve_Take_BUT_home = lv.btn(Reserve_Take)
Reserve_Take_BUT_home_label = lv.label(Reserve_Take_BUT_home)
Reserve_Take_BUT_home_label.set_text("Finish")
Reserve_Take_BUT_home_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Take_BUT_home_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Take_BUT_home.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_pos(366, 224)
Reserve_Take_BUT_home.set_size(100, 37)
# Set style for Reserve_Take_BUT_home, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_BUT_home.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_home.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_BUT_take
Reserve_Take_BUT_take = lv.btn(Reserve_Take)
Reserve_Take_BUT_take_label = lv.label(Reserve_Take_BUT_take)
Reserve_Take_BUT_take_label.set_text("Take")
Reserve_Take_BUT_take_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Take_BUT_take_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Take_BUT_take.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_pos(256, 225)
Reserve_Take_BUT_take.set_size(100, 37)
# Set style for Reserve_Take_BUT_take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_BUT_take.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_BUT_take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_INPUT_User
Reserve_Take_INPUT_User = lv.dropdown(Reserve_Take)
Reserve_Take_INPUT_User.set_options("Brian\nJohnson\nMax")
Reserve_Take_INPUT_User.set_pos(34, 121)
Reserve_Take_INPUT_User.set_size(130, 30)
# Set style for Reserve_Take_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_INPUT_User.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_User.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Take_INPUT_User, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Reserve_Take_INPUT_User_extra_list_selected_checked = lv.style_t()
style_Reserve_Take_INPUT_User_extra_list_selected_checked.init()
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_border_width(1)
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_border_opa(255)
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_radius(3)
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_bg_opa(255)
style_Reserve_Take_INPUT_User_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Reserve_Take_INPUT_User.get_list().add_style(style_Reserve_Take_INPUT_User_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Reserve_Take_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_INPUT_User_extra_list_main_default = lv.style_t()
style_Reserve_Take_INPUT_User_extra_list_main_default.init()
style_Reserve_Take_INPUT_User_extra_list_main_default.set_max_height(90)
style_Reserve_Take_INPUT_User_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Reserve_Take_INPUT_User_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_INPUT_User_extra_list_main_default.set_border_width(1)
style_Reserve_Take_INPUT_User_extra_list_main_default.set_border_opa(255)
style_Reserve_Take_INPUT_User_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Take_INPUT_User_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Take_INPUT_User_extra_list_main_default.set_radius(3)
style_Reserve_Take_INPUT_User_extra_list_main_default.set_bg_opa(255)
style_Reserve_Take_INPUT_User_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Reserve_Take_INPUT_User.get_list().add_style(style_Reserve_Take_INPUT_User_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_INPUT_User, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Reserve_Take_INPUT_User_extra_list_scrollbar_default = lv.style_t()
style_Reserve_Take_INPUT_User_extra_list_scrollbar_default.init()
style_Reserve_Take_INPUT_User_extra_list_scrollbar_default.set_radius(3)
style_Reserve_Take_INPUT_User_extra_list_scrollbar_default.set_bg_opa(0)
Reserve_Take_INPUT_User.get_list().add_style(style_Reserve_Take_INPUT_User_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reserve_Take_INPUT_numbers
Reserve_Take_INPUT_numbers = lv.dropdown(Reserve_Take)
Reserve_Take_INPUT_numbers.set_options("1\n2\n3\n4\n5\n6\n7\n8\n9")
Reserve_Take_INPUT_numbers.set_pos(314, 121)
Reserve_Take_INPUT_numbers.set_size(130, 30)
# Set style for Reserve_Take_INPUT_numbers, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_INPUT_numbers.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_numbers.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Take_INPUT_numbers, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked = lv.style_t()
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.init()
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_border_width(1)
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_border_opa(255)
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_radius(3)
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_bg_opa(255)
style_Reserve_Take_INPUT_numbers_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Reserve_Take_INPUT_numbers.get_list().add_style(style_Reserve_Take_INPUT_numbers_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Reserve_Take_INPUT_numbers, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_INPUT_numbers_extra_list_main_default = lv.style_t()
style_Reserve_Take_INPUT_numbers_extra_list_main_default.init()
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_max_height(90)
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_border_width(1)
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_border_opa(255)
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_radius(3)
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_bg_opa(255)
style_Reserve_Take_INPUT_numbers_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Reserve_Take_INPUT_numbers.get_list().add_style(style_Reserve_Take_INPUT_numbers_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_INPUT_numbers, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Reserve_Take_INPUT_numbers_extra_list_scrollbar_default = lv.style_t()
style_Reserve_Take_INPUT_numbers_extra_list_scrollbar_default.init()
style_Reserve_Take_INPUT_numbers_extra_list_scrollbar_default.set_radius(3)
style_Reserve_Take_INPUT_numbers_extra_list_scrollbar_default.set_bg_opa(0)
Reserve_Take_INPUT_numbers.get_list().add_style(style_Reserve_Take_INPUT_numbers_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reserve_Take_INPUT_medlist
Reserve_Take_INPUT_medlist = lv.dropdown(Reserve_Take)
Reserve_Take_INPUT_medlist.set_options("Aspirin\nAcetaminophen\nantibiotic")
Reserve_Take_INPUT_medlist.set_pos(175, 121)
Reserve_Take_INPUT_medlist.set_size(130, 30)
# Set style for Reserve_Take_INPUT_medlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_INPUT_medlist.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_INPUT_medlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Take_INPUT_medlist, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked = lv.style_t()
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.init()
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_border_width(1)
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_border_opa(255)
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_radius(3)
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_bg_opa(255)
style_Reserve_Take_INPUT_medlist_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Reserve_Take_INPUT_medlist.get_list().add_style(style_Reserve_Take_INPUT_medlist_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Reserve_Take_INPUT_medlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_INPUT_medlist_extra_list_main_default = lv.style_t()
style_Reserve_Take_INPUT_medlist_extra_list_main_default.init()
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_max_height(90)
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_border_width(1)
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_border_opa(255)
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_radius(3)
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_bg_opa(255)
style_Reserve_Take_INPUT_medlist_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Reserve_Take_INPUT_medlist.get_list().add_style(style_Reserve_Take_INPUT_medlist_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_INPUT_medlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Reserve_Take_INPUT_medlist_extra_list_scrollbar_default = lv.style_t()
style_Reserve_Take_INPUT_medlist_extra_list_scrollbar_default.init()
style_Reserve_Take_INPUT_medlist_extra_list_scrollbar_default.set_radius(3)
style_Reserve_Take_INPUT_medlist_extra_list_scrollbar_default.set_bg_opa(0)
Reserve_Take_INPUT_medlist.get_list().add_style(style_Reserve_Take_INPUT_medlist_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Reserve_Take_win_success
Reserve_Take_win_success = lv.win(Reserve_Take, 40)
Reserve_Take_win_success.add_title("System")
Reserve_Take_win_success_item0 = Reserve_Take_win_success.add_btn(lv.SYMBOL.CLOSE, 40)
Reserve_Take_win_success_label = lv.label(Reserve_Take_win_success.get_content())
Reserve_Take_win_success.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Reserve_Take_win_success_label.set_text("Taking successfully!!\n")
Reserve_Take_win_success.set_pos(44, 48)
Reserve_Take_win_success.set_size(400, 177)
Reserve_Take_win_success.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Reserve_Take_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_win_success.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_win_success.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_win_success.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_win_success.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_win_success_extra_content_main_default = lv.style_t()
style_Reserve_Take_win_success_extra_content_main_default.init()
style_Reserve_Take_win_success_extra_content_main_default.set_bg_opa(255)
style_Reserve_Take_win_success_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reserve_Take_win_success_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reserve_Take_win_success_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Reserve_Take_win_success_extra_content_main_default.set_text_letter_space(0)
style_Reserve_Take_win_success_extra_content_main_default.set_text_line_space(2)
Reserve_Take_win_success.get_content().add_style(style_Reserve_Take_win_success_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_win_success_extra_header_main_default = lv.style_t()
style_Reserve_Take_win_success_extra_header_main_default.init()
style_Reserve_Take_win_success_extra_header_main_default.set_bg_opa(236)
style_Reserve_Take_win_success_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Reserve_Take_win_success_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reserve_Take_win_success_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_win_success_extra_header_main_default.set_text_letter_space(0)
style_Reserve_Take_win_success_extra_header_main_default.set_text_line_space(2)
Reserve_Take_win_success.get_header().add_style(style_Reserve_Take_win_success_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_win_success_extra_btns_main_default = lv.style_t()
style_Reserve_Take_win_success_extra_btns_main_default.init()
style_Reserve_Take_win_success_extra_btns_main_default.set_radius(8)
style_Reserve_Take_win_success_extra_btns_main_default.set_bg_opa(255)
style_Reserve_Take_win_success_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reserve_Take_win_success_extra_btns_main_default.set_shadow_width(0)
Reserve_Take_win_success_item0.add_style(style_Reserve_Take_win_success_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Take_win_error
Reserve_Take_win_error = lv.win(Reserve_Take, 40)
Reserve_Take_win_error.add_title("System")
Reserve_Take_win_error_item0 = Reserve_Take_win_error.add_btn(lv.SYMBOL.CLOSE, 40)
Reserve_Take_win_error_label = lv.label(Reserve_Take_win_error.get_content())
Reserve_Take_win_error.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Reserve_Take_win_error_label.set_text("Storage is not enough!!\nPlease enter number of pills again.\nTaking medicine failed.\n")
Reserve_Take_win_error.set_pos(44, 48)
Reserve_Take_win_error.set_size(400, 177)
Reserve_Take_win_error.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Reserve_Take_win_error, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Take_win_error.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_win_error.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_win_error.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Take_win_error.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_win_error, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_win_error_extra_content_main_default = lv.style_t()
style_Reserve_Take_win_error_extra_content_main_default.init()
style_Reserve_Take_win_error_extra_content_main_default.set_bg_opa(255)
style_Reserve_Take_win_error_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reserve_Take_win_error_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reserve_Take_win_error_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Reserve_Take_win_error_extra_content_main_default.set_text_letter_space(0)
style_Reserve_Take_win_error_extra_content_main_default.set_text_line_space(6)
Reserve_Take_win_error.get_content().add_style(style_Reserve_Take_win_error_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_win_error, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_win_error_extra_header_main_default = lv.style_t()
style_Reserve_Take_win_error_extra_header_main_default.init()
style_Reserve_Take_win_error_extra_header_main_default.set_bg_opa(236)
style_Reserve_Take_win_error_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Reserve_Take_win_error_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Reserve_Take_win_error_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Take_win_error_extra_header_main_default.set_text_letter_space(0)
style_Reserve_Take_win_error_extra_header_main_default.set_text_line_space(2)
Reserve_Take_win_error.get_header().add_style(style_Reserve_Take_win_error_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Reserve_Take_win_error, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Take_win_error_extra_btns_main_default = lv.style_t()
style_Reserve_Take_win_error_extra_btns_main_default.init()
style_Reserve_Take_win_error_extra_btns_main_default.set_radius(8)
style_Reserve_Take_win_error_extra_btns_main_default.set_bg_opa(255)
style_Reserve_Take_win_error_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Reserve_Take_win_error_extra_btns_main_default.set_shadow_width(0)
Reserve_Take_win_error_item0.add_style(style_Reserve_Take_win_error_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

Reserve_Take.update_layout()
# Create Reserve_Storage
Reserve_Storage = lv.obj()
Reserve_Storage.set_size(480, 272)
# Set style for Reserve_Storage, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storage.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storage_contBG
Reserve_Storage_contBG = lv.obj(Reserve_Storage)
Reserve_Storage_contBG.set_pos(0, 0)
Reserve_Storage_contBG.set_size(480, 60)
Reserve_Storage_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Reserve_Storage_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storage_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Reserve_Storage_BUT_back
Reserve_Storage_BUT_back = lv.btn(Reserve_Storage_contBG)
Reserve_Storage_BUT_back_label = lv.label(Reserve_Storage_BUT_back)
Reserve_Storage_BUT_back_label.set_text("<")
Reserve_Storage_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storage_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Storage_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Storage_BUT_back.set_pos(25, 17)
Reserve_Storage_BUT_back.set_size(35, 32)
# Set style for Reserve_Storage_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storage_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storage_text_title
Reserve_Storage_text_title = lv.label(Reserve_Storage_contBG)
Reserve_Storage_text_title.set_text("Storage")
Reserve_Storage_text_title.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storage_text_title.set_pos(135, 21)
Reserve_Storage_text_title.set_size(210, 32)
# Set style for Reserve_Storage_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storage_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storage_BUT_home
Reserve_Storage_BUT_home = lv.btn(Reserve_Storage)
Reserve_Storage_BUT_home_label = lv.label(Reserve_Storage_BUT_home)
Reserve_Storage_BUT_home_label.set_text("Finish")
Reserve_Storage_BUT_home_label.set_long_mode(lv.label.LONG.WRAP)
Reserve_Storage_BUT_home_label.align(lv.ALIGN.CENTER, 0, 0)
Reserve_Storage_BUT_home.set_style_pad_all(0, lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_pos(366, 224)
Reserve_Storage_BUT_home.set_size(100, 37)
# Set style for Reserve_Storage_BUT_home, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storage_BUT_home.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_BUT_home.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Reserve_Storage_LIST_storagelist
Reserve_Storage_LIST_storagelist = lv.list(Reserve_Storage)
Reserve_Storage_LIST_storagelist_item0 = Reserve_Storage_LIST_storagelist.add_btn(lv.SYMBOL.SAVE, "Aspirin")
Reserve_Storage_LIST_storagelist_item1 = Reserve_Storage_LIST_storagelist.add_btn(lv.SYMBOL.SAVE, "Acetaminophen")
Reserve_Storage_LIST_storagelist_item2 = Reserve_Storage_LIST_storagelist.add_btn(lv.SYMBOL.SAVE, "antibiotic")
Reserve_Storage_LIST_storagelist.set_pos(34, 78)
Reserve_Storage_LIST_storagelist.set_size(412, 130)
Reserve_Storage_LIST_storagelist.set_scrollbar_mode(lv.SCROLLBAR_MODE.AUTO)
# Set style for Reserve_Storage_LIST_storagelist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Reserve_Storage_LIST_storagelist.set_style_pad_top(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_pad_left(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_pad_right(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_pad_bottom(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Storage_LIST_storagelist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Reserve_Storage_LIST_storagelist.set_style_radius(3, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_bg_opa(255, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
# Set style for Reserve_Storage_LIST_storagelist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default = lv.style_t()
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.init()
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_pad_top(5)
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_pad_left(5)
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_pad_right(5)
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_pad_bottom(5)
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_border_width(0)
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_radius(3)
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_bg_opa(255)
style_Reserve_Storage_LIST_storagelist_extra_btns_main_default.set_bg_color(lv.color_hex(0xffffff))
Reserve_Storage_LIST_storagelist_item2.add_style(style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist_item1.add_style(style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
Reserve_Storage_LIST_storagelist_item0.add_style(style_Reserve_Storage_LIST_storagelist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Reserve_Storage_LIST_storagelist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default = lv.style_t()
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.init()
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_pad_top(5)
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_pad_left(5)
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_pad_right(5)
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_pad_bottom(5)
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_border_width(0)
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_text_font(test_font("montserratMedium", 12))
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_radius(3)
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_bg_opa(255)
style_Reserve_Storage_LIST_storagelist_extra_texts_main_default.set_bg_color(lv.color_hex(0xffffff))

Reserve_Storage.update_layout()
# Create Page_Search
Page_Search = lv.obj()
Page_Search.set_size(480, 272)
# Set style for Page_Search, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Search_contBG
Page_Search_contBG = lv.obj(Page_Search)
Page_Search_contBG.set_pos(0, 0)
Page_Search_contBG.set_size(480, 60)
Page_Search_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Page_Search_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Search_text_title
Page_Search_text_title = lv.label(Page_Search)
Page_Search_text_title.set_text("Search Medicine")
Page_Search_text_title.set_long_mode(lv.label.LONG.WRAP)
Page_Search_text_title.set_pos(135, 23)
Page_Search_text_title.set_size(210, 32)
# Set style for Page_Search_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Search_text_syptoms
Page_Search_text_syptoms = lv.label(Page_Search)
Page_Search_text_syptoms.set_text("Syptoms:")
Page_Search_text_syptoms.set_long_mode(lv.label.LONG.WRAP)
Page_Search_text_syptoms.set_pos(10, 67)
Page_Search_text_syptoms.set_size(113, 26)
# Set style for Page_Search_text_syptoms, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_text_syptoms.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_text_syptoms.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Search_cb_runningnose
Page_Search_cb_runningnose = lv.checkbox(Page_Search)
Page_Search_cb_runningnose.set_text("running nose")
Page_Search_cb_runningnose.set_pos(39, 126)
# Set style for Page_Search_cb_runningnose, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_runningnose.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_runningnose, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_runningnose.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_runningnose.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_headache
Page_Search_cb_headache = lv.checkbox(Page_Search)
Page_Search_cb_headache.set_text("headache")
Page_Search_cb_headache.set_pos(39, 93)
# Set style for Page_Search_cb_headache, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_headache.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_headache, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_headache.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_headache.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_sorethroat
Page_Search_cb_sorethroat = lv.checkbox(Page_Search)
Page_Search_cb_sorethroat.set_text("sore throat")
Page_Search_cb_sorethroat.set_pos(39, 157)
# Set style for Page_Search_cb_sorethroat, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_sorethroat.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_sorethroat, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_sorethroat.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_sorethroat.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_muscleaches
Page_Search_cb_muscleaches = lv.checkbox(Page_Search)
Page_Search_cb_muscleaches.set_text("muscle aches")
Page_Search_cb_muscleaches.set_pos(39, 187)
# Set style for Page_Search_cb_muscleaches, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_muscleaches.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_muscleaches, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_muscleaches.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_muscleaches.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_cough
Page_Search_cb_cough = lv.checkbox(Page_Search)
Page_Search_cb_cough.set_text("cough")
Page_Search_cb_cough.set_pos(178, 93)
# Set style for Page_Search_cb_cough, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_cough.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_cough, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_cough.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_cough.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_fever
Page_Search_cb_fever = lv.checkbox(Page_Search)
Page_Search_cb_fever.set_text("fever")
Page_Search_cb_fever.set_pos(178, 126)
# Set style for Page_Search_cb_fever, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_fever.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_fever, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_fever.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_fever.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_losstaste
Page_Search_cb_losstaste = lv.checkbox(Page_Search)
Page_Search_cb_losstaste.set_text("loss of taste")
Page_Search_cb_losstaste.set_pos(178, 157)
# Set style for Page_Search_cb_losstaste, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_losstaste.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_losstaste, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_losstaste.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_losstaste.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_diarrhea
Page_Search_cb_diarrhea = lv.checkbox(Page_Search)
Page_Search_cb_diarrhea.set_text("diarrhea")
Page_Search_cb_diarrhea.set_pos(178, 187)
# Set style for Page_Search_cb_diarrhea, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_diarrhea.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_diarrhea, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_diarrhea.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_diarrhea.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_stomachache
Page_Search_cb_stomachache = lv.checkbox(Page_Search)
Page_Search_cb_stomachache.set_text("stomachache")
Page_Search_cb_stomachache.set_pos(317, 93)
# Set style for Page_Search_cb_stomachache, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_stomachache.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_stomachache, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_stomachache.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_stomachache.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_drowsiness
Page_Search_cb_drowsiness = lv.checkbox(Page_Search)
Page_Search_cb_drowsiness.set_text("drowsiness")
Page_Search_cb_drowsiness.set_pos(317, 126)
# Set style for Page_Search_cb_drowsiness, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_drowsiness.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_drowsiness, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_drowsiness.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_drowsiness.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_chestpain
Page_Search_cb_chestpain = lv.checkbox(Page_Search)
Page_Search_cb_chestpain.set_text("chest pain")
Page_Search_cb_chestpain.set_pos(317, 157)
# Set style for Page_Search_cb_chestpain, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_chestpain.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_chestpain, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_chestpain.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_chestpain.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_cb_Nausea
Page_Search_cb_Nausea = lv.checkbox(Page_Search)
Page_Search_cb_Nausea.set_text("Nausea")
Page_Search_cb_Nausea.set_pos(317, 187)
# Set style for Page_Search_cb_Nausea, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_cb_Nausea.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_radius(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_bg_color(lv.color_hex(0xC2D9FF), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Search_cb_Nausea, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
Page_Search_cb_Nausea.set_style_border_width(2, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_border_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_border_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_radius(6, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
Page_Search_cb_Nausea.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Create Page_Search_BUT_Next
Page_Search_BUT_Next = lv.btn(Page_Search)
Page_Search_BUT_Next_label = lv.label(Page_Search_BUT_Next)
Page_Search_BUT_Next_label.set_text("NEXT")
Page_Search_BUT_Next_label.set_long_mode(lv.label.LONG.WRAP)
Page_Search_BUT_Next_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Search_BUT_Next.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_pos(366, 224)
Page_Search_BUT_Next.set_size(100, 37)
# Set style for Page_Search_BUT_Next, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_BUT_Next.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_style_bg_color(lv.color_hex(0x0506a0), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_Next.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Search_BUT_back
Page_Search_BUT_back = lv.btn(Page_Search)
Page_Search_BUT_back_label = lv.label(Page_Search_BUT_back)
Page_Search_BUT_back_label.set_text("<")
Page_Search_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Page_Search_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Search_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Search_BUT_back.set_pos(25, 17)
Page_Search_BUT_back.set_size(35, 32)
# Set style for Page_Search_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Search_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Search_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

Page_Search.update_layout()
# Create Search_reccomend
Search_reccomend = lv.obj()
g_kb_Search_reccomend = lv.keyboard(Search_reccomend)
g_kb_Search_reccomend.add_event_cb(lambda e: Search_reccomend_ta_event_cb(e, g_kb_Search_reccomend), lv.EVENT.ALL, None)
g_kb_Search_reccomend.add_flag(lv.obj.FLAG.HIDDEN)
g_kb_Search_reccomend.set_style_text_font(test_font("simsun", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend.set_size(480, 272)
# Set style for Search_reccomend, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Search_reccomend_contBG
Search_reccomend_contBG = lv.obj(Search_reccomend)
Search_reccomend_contBG.set_pos(0, 0)
Search_reccomend_contBG.set_size(480, 60)
Search_reccomend_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Search_reccomend_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Search_reccomend_text_title
Search_reccomend_text_title = lv.label(Search_reccomend_contBG)
Search_reccomend_text_title.set_text("Maybe you should take...")
Search_reccomend_text_title.set_long_mode(lv.label.LONG.WRAP)
Search_reccomend_text_title.set_pos(105, 23)
Search_reccomend_text_title.set_size(276, 32)
# Set style for Search_reccomend_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Search_reccomend_BUT_back
Search_reccomend_BUT_back = lv.btn(Search_reccomend)
Search_reccomend_BUT_back_label = lv.label(Search_reccomend_BUT_back)
Search_reccomend_BUT_back_label.set_text("<")
Search_reccomend_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Search_reccomend_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Search_reccomend_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Search_reccomend_BUT_back.set_pos(25, 17)
Search_reccomend_BUT_back.set_size(35, 32)
# Set style for Search_reccomend_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Search_reccomend_BUT_take
Search_reccomend_BUT_take = lv.btn(Search_reccomend)
Search_reccomend_BUT_take_label = lv.label(Search_reccomend_BUT_take)
Search_reccomend_BUT_take_label.set_text("Take")
Search_reccomend_BUT_take_label.set_long_mode(lv.label.LONG.WRAP)
Search_reccomend_BUT_take_label.align(lv.ALIGN.CENTER, 0, 0)
Search_reccomend_BUT_take.set_style_pad_all(0, lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_pos(366, 224)
Search_reccomend_BUT_take.set_size(100, 37)
# Set style for Search_reccomend_BUT_take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_BUT_take.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_BUT_take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Search_reccomend_text_suggested
Search_reccomend_text_suggested = lv.label(Search_reccomend)
Search_reccomend_text_suggested.set_text("Suggested medicine:")
Search_reccomend_text_suggested.set_long_mode(lv.label.LONG.WRAP)
Search_reccomend_text_suggested.set_pos(17, 69)
Search_reccomend_text_suggested.set_size(176, 32)
# Set style for Search_reccomend_text_suggested, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_text_suggested.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_suggested.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Search_reccomend_text_Take
Search_reccomend_text_Take = lv.label(Search_reccomend)
Search_reccomend_text_Take.set_text("Take:")
Search_reccomend_text_Take.set_long_mode(lv.label.LONG.WRAP)
Search_reccomend_text_Take.set_pos(190, 120)
Search_reccomend_text_Take.set_size(100, 32)
# Set style for Search_reccomend_text_Take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_text_Take.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_Take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Search_reccomend_text_number
Search_reccomend_text_number = lv.label(Search_reccomend)
Search_reccomend_text_number.set_text("Numbers:")
Search_reccomend_text_number.set_long_mode(lv.label.LONG.WRAP)
Search_reccomend_text_number.set_pos(199, 173)
Search_reccomend_text_number.set_size(82, 17)
# Set style for Search_reccomend_text_number, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_text_number.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_text_number.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Search_reccomend_INPUT_numbers
Search_reccomend_INPUT_numbers = lv.textarea(Search_reccomend)
Search_reccomend_INPUT_numbers.set_text("")
Search_reccomend_INPUT_numbers.set_password_bullet("*")
Search_reccomend_INPUT_numbers.set_password_mode(False)
Search_reccomend_INPUT_numbers.set_one_line(True)
Search_reccomend_INPUT_numbers.add_event_cb(lambda e: Search_reccomend_ta_event_cb(e, g_kb_Search_reccomend), lv.EVENT.ALL, None)
Search_reccomend_INPUT_numbers.set_pos(291, 166)
Search_reccomend_INPUT_numbers.set_size(128, 29)
# Set style for Search_reccomend_INPUT_numbers, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_INPUT_numbers.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_text_font(test_font("montserratMedium", 15), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Search_reccomend_INPUT_numbers, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Search_reccomend_INPUT_numbers.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Search_reccomend_INPUT_numbers.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Search_reccomend_INPUT_sugmedlist
Search_reccomend_INPUT_sugmedlist = lv.dropdown(Search_reccomend)
Search_reccomend_INPUT_sugmedlist.set_options("antibiotic")
Search_reccomend_INPUT_sugmedlist.set_pos(290, 113)
Search_reccomend_INPUT_sugmedlist.set_size(130, 30)
# Set style for Search_reccomend_INPUT_sugmedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_INPUT_sugmedlist.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_INPUT_sugmedlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Search_reccomend_INPUT_sugmedlist, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked = lv.style_t()
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.init()
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_border_width(1)
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_border_opa(255)
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_radius(3)
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_bg_opa(255)
style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Search_reccomend_INPUT_sugmedlist.get_list().add_style(style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Search_reccomend_INPUT_sugmedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default = lv.style_t()
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.init()
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_max_height(90)
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_border_width(1)
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_border_opa(255)
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_radius(3)
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_bg_opa(255)
style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Search_reccomend_INPUT_sugmedlist.get_list().add_style(style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Search_reccomend_INPUT_sugmedlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default = lv.style_t()
style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default.init()
style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default.set_radius(3)
style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default.set_bg_opa(0)
Search_reccomend_INPUT_sugmedlist.get_list().add_style(style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Search_reccomend_LIST_suggestedlist
Search_reccomend_LIST_suggestedlist = lv.list(Search_reccomend)
Search_reccomend_LIST_suggestedlist_item0 = Search_reccomend_LIST_suggestedlist.add_btn(lv.SYMBOL.SAVE, "antibiotic")
Search_reccomend_LIST_suggestedlist.set_pos(25, 93)
Search_reccomend_LIST_suggestedlist.set_size(161, 159)
Search_reccomend_LIST_suggestedlist.set_scrollbar_mode(lv.SCROLLBAR_MODE.ACTIVE)
# Set style for Search_reccomend_LIST_suggestedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_LIST_suggestedlist.set_style_pad_top(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_pad_left(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_pad_right(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_pad_bottom(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Search_reccomend_LIST_suggestedlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Search_reccomend_LIST_suggestedlist.set_style_radius(3, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_bg_opa(255, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Search_reccomend_LIST_suggestedlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
# Set style for Search_reccomend_LIST_suggestedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default = lv.style_t()
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.init()
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_pad_top(5)
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_pad_left(5)
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_pad_right(5)
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_pad_bottom(5)
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_border_width(0)
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_text_font(test_font("montserratMedium", 12))
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_radius(3)
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_bg_opa(255)
style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default.set_bg_color(lv.color_hex(0xffffff))
Search_reccomend_LIST_suggestedlist_item0.add_style(style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Search_reccomend_LIST_suggestedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default = lv.style_t()
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.init()
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_pad_top(5)
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_pad_left(5)
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_pad_right(5)
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_pad_bottom(5)
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_border_width(0)
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_text_font(test_font("montserratMedium", 12))
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_radius(3)
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_bg_opa(255)
style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default.set_bg_color(lv.color_hex(0xffffff))

# Create Search_reccomend_window_notice
Search_reccomend_window_notice = lv.win(Search_reccomend, 40)
Search_reccomend_window_notice.add_title("NOTICE")
Search_reccomend_window_notice_item0 = Search_reccomend_window_notice.add_btn(lv.SYMBOL.CLOSE, 40)
Search_reccomend_window_notice_label = lv.label(Search_reccomend_window_notice.get_content())
Search_reccomend_window_notice.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Search_reccomend_window_notice_label.set_text("Taking successfully!!\nDon't forget to see a doctor!!\nTaking Medicine only ease your pain\nin a SHORT time.\n")
Search_reccomend_window_notice.set_pos(51, 69)
Search_reccomend_window_notice.set_size(400, 177)
Search_reccomend_window_notice.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Search_reccomend_window_notice, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Search_reccomend_window_notice.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_window_notice.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_window_notice.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Search_reccomend_window_notice.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Search_reccomend_window_notice, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Search_reccomend_window_notice_extra_content_main_default = lv.style_t()
style_Search_reccomend_window_notice_extra_content_main_default.init()
style_Search_reccomend_window_notice_extra_content_main_default.set_bg_opa(255)
style_Search_reccomend_window_notice_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Search_reccomend_window_notice_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Search_reccomend_window_notice_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Search_reccomend_window_notice_extra_content_main_default.set_text_letter_space(0)
style_Search_reccomend_window_notice_extra_content_main_default.set_text_line_space(7)
Search_reccomend_window_notice.get_content().add_style(style_Search_reccomend_window_notice_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Search_reccomend_window_notice, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Search_reccomend_window_notice_extra_header_main_default = lv.style_t()
style_Search_reccomend_window_notice_extra_header_main_default.init()
style_Search_reccomend_window_notice_extra_header_main_default.set_bg_opa(236)
style_Search_reccomend_window_notice_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Search_reccomend_window_notice_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Search_reccomend_window_notice_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Search_reccomend_window_notice_extra_header_main_default.set_text_letter_space(0)
style_Search_reccomend_window_notice_extra_header_main_default.set_text_line_space(2)
Search_reccomend_window_notice.get_header().add_style(style_Search_reccomend_window_notice_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Search_reccomend_window_notice, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Search_reccomend_window_notice_extra_btns_main_default = lv.style_t()
style_Search_reccomend_window_notice_extra_btns_main_default.init()
style_Search_reccomend_window_notice_extra_btns_main_default.set_radius(8)
style_Search_reccomend_window_notice_extra_btns_main_default.set_bg_opa(255)
style_Search_reccomend_window_notice_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Search_reccomend_window_notice_extra_btns_main_default.set_shadow_width(0)
Search_reccomend_window_notice_item0.add_style(style_Search_reccomend_window_notice_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

Search_reccomend.update_layout()
# Create Page_History
Page_History = lv.obj()
Page_History.set_size(480, 272)
# Set style for Page_History, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_History_contBG
Page_History_contBG = lv.obj(Page_History)
Page_History_contBG.set_pos(0, 0)
Page_History_contBG.set_size(480, 60)
Page_History_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Page_History_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Page_History_text_title
Page_History_text_title = lv.label(Page_History_contBG)
Page_History_text_title.set_text("History")
Page_History_text_title.set_long_mode(lv.label.LONG.WRAP)
Page_History_text_title.set_pos(105, 23)
Page_History_text_title.set_size(276, 32)
# Set style for Page_History_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_History_BUT_back
Page_History_BUT_back = lv.btn(Page_History)
Page_History_BUT_back_label = lv.label(Page_History_BUT_back)
Page_History_BUT_back_label.set_text("<")
Page_History_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Page_History_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Page_History_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_History_BUT_back.set_pos(25, 17)
Page_History_BUT_back.set_size(35, 32)
# Set style for Page_History_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_History_BUT_take
Page_History_BUT_take = lv.btn(Page_History)
Page_History_BUT_take_label = lv.label(Page_History_BUT_take)
Page_History_BUT_take_label.set_text("Finish")
Page_History_BUT_take_label.set_long_mode(lv.label.LONG.WRAP)
Page_History_BUT_take_label.align(lv.ALIGN.CENTER, 0, 0)
Page_History_BUT_take.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_History_BUT_take.set_pos(366, 224)
Page_History_BUT_take.set_size(100, 37)
# Set style for Page_History_BUT_take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History_BUT_take.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_take.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_take.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_take.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_take.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_take.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_BUT_take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_History_text_Take
Page_History_text_Take = lv.label(Page_History)
Page_History_text_Take.set_text("Search by Member:")
Page_History_text_Take.set_long_mode(lv.label.LONG.WRAP)
Page_History_text_Take.set_pos(268, 75)
Page_History_text_Take.set_size(176, 23)
# Set style for Page_History_text_Take, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History_text_Take.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_text_Take.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_History_INPUT_sugmedlist
Page_History_INPUT_sugmedlist = lv.dropdown(Page_History)
Page_History_INPUT_sugmedlist.set_options("Brian\nJohnson\nMax")
Page_History_INPUT_sugmedlist.set_pos(313, 98)
Page_History_INPUT_sugmedlist.set_size(125, 34)
# Set style for Page_History_INPUT_sugmedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History_INPUT_sugmedlist.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_INPUT_sugmedlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_History_INPUT_sugmedlist, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked = lv.style_t()
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.init()
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_border_width(1)
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_border_opa(255)
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_radius(3)
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_bg_opa(255)
style_Page_History_INPUT_sugmedlist_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Page_History_INPUT_sugmedlist.get_list().add_style(style_Page_History_INPUT_sugmedlist_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Page_History_INPUT_sugmedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_History_INPUT_sugmedlist_extra_list_main_default = lv.style_t()
style_Page_History_INPUT_sugmedlist_extra_list_main_default.init()
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_max_height(90)
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_border_width(1)
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_border_opa(255)
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_radius(3)
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_bg_opa(255)
style_Page_History_INPUT_sugmedlist_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Page_History_INPUT_sugmedlist.get_list().add_style(style_Page_History_INPUT_sugmedlist_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_History_INPUT_sugmedlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default = lv.style_t()
style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default.init()
style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default.set_radius(3)
style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default.set_bg_opa(0)
Page_History_INPUT_sugmedlist.get_list().add_style(style_Page_History_INPUT_sugmedlist_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Page_History_LIST_suggestedlist
Page_History_LIST_suggestedlist = lv.list(Page_History)
Page_History_LIST_suggestedlist_item0 = Page_History_LIST_suggestedlist.add_btn(lv.SYMBOL.SAVE, "Brian_antibiotic_2_16:00")
Page_History_LIST_suggestedlist.set_pos(29, 75)
Page_History_LIST_suggestedlist.set_size(225, 181)
Page_History_LIST_suggestedlist.set_scrollbar_mode(lv.SCROLLBAR_MODE.ACTIVE)
# Set style for Page_History_LIST_suggestedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_History_LIST_suggestedlist.set_style_pad_top(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_pad_left(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_pad_right(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_pad_bottom(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_History_LIST_suggestedlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Page_History_LIST_suggestedlist.set_style_radius(3, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_bg_opa(255, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Page_History_LIST_suggestedlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
# Set style for Page_History_LIST_suggestedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_History_LIST_suggestedlist_extra_btns_main_default = lv.style_t()
style_Page_History_LIST_suggestedlist_extra_btns_main_default.init()
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_pad_top(5)
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_pad_left(5)
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_pad_right(5)
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_pad_bottom(5)
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_border_width(0)
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_radius(3)
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_bg_opa(255)
style_Page_History_LIST_suggestedlist_extra_btns_main_default.set_bg_color(lv.color_hex(0xffffff))
Page_History_LIST_suggestedlist_item0.add_style(style_Page_History_LIST_suggestedlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_History_LIST_suggestedlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_History_LIST_suggestedlist_extra_texts_main_default = lv.style_t()
style_Page_History_LIST_suggestedlist_extra_texts_main_default.init()
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_pad_top(5)
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_pad_left(5)
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_pad_right(5)
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_pad_bottom(5)
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_border_width(0)
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_radius(3)
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_bg_opa(255)
style_Page_History_LIST_suggestedlist_extra_texts_main_default.set_bg_color(lv.color_hex(0xffffff))

Page_History.update_layout()
# Create Page_Remind
Page_Remind = lv.obj()
Page_Remind.set_size(480, 272)
# Set style for Page_Remind, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_contBG
Page_Remind_contBG = lv.obj(Page_Remind)
Page_Remind_contBG.set_pos(0, 0)
Page_Remind_contBG.set_size(480, 60)
Page_Remind_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Page_Remind_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Page_Remind_BUT_back
Page_Remind_BUT_back = lv.btn(Page_Remind_contBG)
Page_Remind_BUT_back_label = lv.label(Page_Remind_BUT_back)
Page_Remind_BUT_back_label.set_text("<")
Page_Remind_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Remind_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Remind_BUT_back.set_pos(24, 17)
Page_Remind_BUT_back.set_size(35, 32)
# Set style for Page_Remind_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_text_title
Page_Remind_text_title = lv.label(Page_Remind_contBG)
Page_Remind_text_title.set_text("Reminder")
Page_Remind_text_title.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_text_title.set_pos(79, 22)
Page_Remind_text_title.set_size(323, 32)
# Set style for Page_Remind_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_imgbtn_1
Page_Remind_imgbtn_1 = lv.imgbtn(Page_Remind_contBG)
Page_Remind_imgbtn_1.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Remind_imgbtn_1.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_LOGIN_alpha_35x35.bin", None)
Page_Remind_imgbtn_1.add_flag(lv.obj.FLAG.CHECKABLE)
Page_Remind_imgbtn_1_label = lv.label(Page_Remind_imgbtn_1)
Page_Remind_imgbtn_1_label.set_text("")
Page_Remind_imgbtn_1_label.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_imgbtn_1_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Remind_imgbtn_1.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Remind_imgbtn_1.set_pos(430, 13)
Page_Remind_imgbtn_1.set_size(35, 35)
# Set style for Page_Remind_imgbtn_1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_imgbtn_1.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_imgbtn_1.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_imgbtn_1.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_imgbtn_1.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_imgbtn_1, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Page_Remind_imgbtn_1.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Page_Remind_imgbtn_1.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Remind_imgbtn_1.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Page_Remind_imgbtn_1.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Page_Remind_imgbtn_1, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Page_Remind_imgbtn_1.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Page_Remind_imgbtn_1.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Remind_imgbtn_1.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Page_Remind_imgbtn_1.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Page_Remind_imgbtn_1, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Page_Remind_imgbtn_1.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Page_Remind_text_addreminder
Page_Remind_text_addreminder = lv.label(Page_Remind)
Page_Remind_text_addreminder.set_text("Add Reminder:")
Page_Remind_text_addreminder.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_text_addreminder.set_pos(213, 81)
Page_Remind_text_addreminder.set_size(153, 17)
# Set style for Page_Remind_text_addreminder, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_text_addreminder.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_addreminder.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_text_Dose
Page_Remind_text_Dose = lv.label(Page_Remind)
Page_Remind_text_Dose.set_text("Dose:")
Page_Remind_text_Dose.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_text_Dose.set_pos(340, 164)
Page_Remind_text_Dose.set_size(46, 18)
# Set style for Page_Remind_text_Dose, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_text_Dose.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_Dose.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_text_sym
Page_Remind_text_sym = lv.label(Page_Remind)
Page_Remind_text_sym.set_text(":")
Page_Remind_text_sym.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_text_sym.set_pos(379, 114)
Page_Remind_text_sym.set_size(15, 27)
# Set style for Page_Remind_text_sym, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_text_sym.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_text_sym.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_BUT_home
Page_Remind_BUT_home = lv.btn(Page_Remind)
Page_Remind_BUT_home_label = lv.label(Page_Remind_BUT_home)
Page_Remind_BUT_home_label.set_text("Apply")
Page_Remind_BUT_home_label.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_BUT_home_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Remind_BUT_home.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_pos(391, 224)
Page_Remind_BUT_home.set_size(81, 37)
# Set style for Page_Remind_BUT_home, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_BUT_home.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_home.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_BUT_Delete
Page_Remind_BUT_Delete = lv.btn(Page_Remind)
Page_Remind_BUT_Delete_label = lv.label(Page_Remind_BUT_Delete)
Page_Remind_BUT_Delete_label.set_text("Delete")
Page_Remind_BUT_Delete_label.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_BUT_Delete_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Remind_BUT_Delete.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_pos(201, 224)
Page_Remind_BUT_Delete.set_size(100, 37)
# Set style for Page_Remind_BUT_Delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_BUT_Delete.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Delete.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_BUT_Add
Page_Remind_BUT_Add = lv.btn(Page_Remind)
Page_Remind_BUT_Add_label = lv.label(Page_Remind_BUT_Add)
Page_Remind_BUT_Add_label.set_text("Add")
Page_Remind_BUT_Add_label.set_long_mode(lv.label.LONG.WRAP)
Page_Remind_BUT_Add_label.align(lv.ALIGN.CENTER, 0, 0)
Page_Remind_BUT_Add.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_pos(308, 224)
Page_Remind_BUT_Add.set_size(73, 37)
# Set style for Page_Remind_BUT_Add, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_BUT_Add.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_BUT_Add.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_INPUT_medlist
Page_Remind_INPUT_medlist = lv.dropdown(Page_Remind)
Page_Remind_INPUT_medlist.set_options("Aspirin\nAcetaminophen\nantibiotic")
Page_Remind_INPUT_medlist.set_pos(213, 156)
Page_Remind_INPUT_medlist.set_size(118, 34)
# Set style for Page_Remind_INPUT_medlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_INPUT_medlist.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_medlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Remind_INPUT_medlist, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Page_Remind_INPUT_medlist_extra_list_selected_checked = lv.style_t()
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.init()
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_border_width(1)
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_border_opa(255)
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_radius(3)
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_bg_opa(255)
style_Page_Remind_INPUT_medlist_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Page_Remind_INPUT_medlist.get_list().add_style(style_Page_Remind_INPUT_medlist_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Page_Remind_INPUT_medlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_medlist_extra_list_main_default = lv.style_t()
style_Page_Remind_INPUT_medlist_extra_list_main_default.init()
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_max_height(90)
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_border_width(1)
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_border_opa(255)
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_radius(3)
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_bg_opa(255)
style_Page_Remind_INPUT_medlist_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Page_Remind_INPUT_medlist.get_list().add_style(style_Page_Remind_INPUT_medlist_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_INPUT_medlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_medlist_extra_list_scrollbar_default = lv.style_t()
style_Page_Remind_INPUT_medlist_extra_list_scrollbar_default.init()
style_Page_Remind_INPUT_medlist_extra_list_scrollbar_default.set_radius(3)
style_Page_Remind_INPUT_medlist_extra_list_scrollbar_default.set_bg_opa(0)
Page_Remind_INPUT_medlist.get_list().add_style(style_Page_Remind_INPUT_medlist_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Page_Remind_INPUT_dose
Page_Remind_INPUT_dose = lv.textarea(Page_Remind)
Page_Remind_INPUT_dose.set_text("")
Page_Remind_INPUT_dose.set_password_bullet("*")
Page_Remind_INPUT_dose.set_password_mode(False)
Page_Remind_INPUT_dose.set_one_line(True)
Page_Remind_INPUT_dose.set_pos(404, 155)
Page_Remind_INPUT_dose.set_size(55, 35)
# Set style for Page_Remind_INPUT_dose, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_INPUT_dose.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Remind_INPUT_dose, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Page_Remind_INPUT_dose.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Page_Remind_INPUT_dose.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Page_Remind_INPUT_min
Page_Remind_INPUT_min = lv.dropdown(Page_Remind)
Page_Remind_INPUT_min.set_options("00\n05\n10\n15\n20\n25\n30\n35\n40\n45\n50\n55")
Page_Remind_INPUT_min.set_pos(391, 107)
Page_Remind_INPUT_min.set_size(68, 35)
# Set style for Page_Remind_INPUT_min, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_INPUT_min.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_min.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Remind_INPUT_min, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Page_Remind_INPUT_min_extra_list_selected_checked = lv.style_t()
style_Page_Remind_INPUT_min_extra_list_selected_checked.init()
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_border_width(1)
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_border_opa(255)
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_radius(3)
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_bg_opa(255)
style_Page_Remind_INPUT_min_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Page_Remind_INPUT_min.get_list().add_style(style_Page_Remind_INPUT_min_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Page_Remind_INPUT_min, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_min_extra_list_main_default = lv.style_t()
style_Page_Remind_INPUT_min_extra_list_main_default.init()
style_Page_Remind_INPUT_min_extra_list_main_default.set_max_height(90)
style_Page_Remind_INPUT_min_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_Remind_INPUT_min_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_min_extra_list_main_default.set_border_width(1)
style_Page_Remind_INPUT_min_extra_list_main_default.set_border_opa(255)
style_Page_Remind_INPUT_min_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_min_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_min_extra_list_main_default.set_radius(3)
style_Page_Remind_INPUT_min_extra_list_main_default.set_bg_opa(255)
style_Page_Remind_INPUT_min_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Page_Remind_INPUT_min.get_list().add_style(style_Page_Remind_INPUT_min_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_INPUT_min, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_min_extra_list_scrollbar_default = lv.style_t()
style_Page_Remind_INPUT_min_extra_list_scrollbar_default.init()
style_Page_Remind_INPUT_min_extra_list_scrollbar_default.set_radius(3)
style_Page_Remind_INPUT_min_extra_list_scrollbar_default.set_bg_opa(255)
style_Page_Remind_INPUT_min_extra_list_scrollbar_default.set_bg_color(lv.color_hex(0x190482))
Page_Remind_INPUT_min.get_list().add_style(style_Page_Remind_INPUT_min_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Page_Remind_INPUT_hour
Page_Remind_INPUT_hour = lv.dropdown(Page_Remind)
Page_Remind_INPUT_hour.set_options("00\n01\n02\n03\n04\n05\n06\n07\n08\n09\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20\n21\n22\n23")
Page_Remind_INPUT_hour.set_pos(308, 107)
Page_Remind_INPUT_hour.set_size(68, 35)
# Set style for Page_Remind_INPUT_hour, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_INPUT_hour.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_hour.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Remind_INPUT_hour, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Page_Remind_INPUT_hour_extra_list_selected_checked = lv.style_t()
style_Page_Remind_INPUT_hour_extra_list_selected_checked.init()
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_border_width(1)
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_border_opa(255)
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_radius(3)
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_bg_opa(255)
style_Page_Remind_INPUT_hour_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Page_Remind_INPUT_hour.get_list().add_style(style_Page_Remind_INPUT_hour_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Page_Remind_INPUT_hour, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_hour_extra_list_main_default = lv.style_t()
style_Page_Remind_INPUT_hour_extra_list_main_default.init()
style_Page_Remind_INPUT_hour_extra_list_main_default.set_max_height(90)
style_Page_Remind_INPUT_hour_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_Remind_INPUT_hour_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_hour_extra_list_main_default.set_border_width(1)
style_Page_Remind_INPUT_hour_extra_list_main_default.set_border_opa(255)
style_Page_Remind_INPUT_hour_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_hour_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_hour_extra_list_main_default.set_radius(3)
style_Page_Remind_INPUT_hour_extra_list_main_default.set_bg_opa(255)
style_Page_Remind_INPUT_hour_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Page_Remind_INPUT_hour.get_list().add_style(style_Page_Remind_INPUT_hour_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_INPUT_hour, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_hour_extra_list_scrollbar_default = lv.style_t()
style_Page_Remind_INPUT_hour_extra_list_scrollbar_default.init()
style_Page_Remind_INPUT_hour_extra_list_scrollbar_default.set_radius(3)
style_Page_Remind_INPUT_hour_extra_list_scrollbar_default.set_bg_opa(0)
Page_Remind_INPUT_hour.get_list().add_style(style_Page_Remind_INPUT_hour_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Page_Remind_INPUT_User
Page_Remind_INPUT_User = lv.dropdown(Page_Remind)
Page_Remind_INPUT_User.set_options("Brian\nJohnson\nMax")
Page_Remind_INPUT_User.set_pos(211, 108)
Page_Remind_INPUT_User.set_size(90, 34)
# Set style for Page_Remind_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_INPUT_User.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_INPUT_User.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Remind_INPUT_User, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Page_Remind_INPUT_User_extra_list_selected_checked = lv.style_t()
style_Page_Remind_INPUT_User_extra_list_selected_checked.init()
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_border_width(1)
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_border_opa(255)
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_radius(3)
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_bg_opa(255)
style_Page_Remind_INPUT_User_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Page_Remind_INPUT_User.get_list().add_style(style_Page_Remind_INPUT_User_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Page_Remind_INPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_User_extra_list_main_default = lv.style_t()
style_Page_Remind_INPUT_User_extra_list_main_default.init()
style_Page_Remind_INPUT_User_extra_list_main_default.set_max_height(90)
style_Page_Remind_INPUT_User_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_Remind_INPUT_User_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_INPUT_User_extra_list_main_default.set_border_width(1)
style_Page_Remind_INPUT_User_extra_list_main_default.set_border_opa(255)
style_Page_Remind_INPUT_User_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Page_Remind_INPUT_User_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Page_Remind_INPUT_User_extra_list_main_default.set_radius(3)
style_Page_Remind_INPUT_User_extra_list_main_default.set_bg_opa(255)
style_Page_Remind_INPUT_User_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Page_Remind_INPUT_User.get_list().add_style(style_Page_Remind_INPUT_User_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_INPUT_User, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Page_Remind_INPUT_User_extra_list_scrollbar_default = lv.style_t()
style_Page_Remind_INPUT_User_extra_list_scrollbar_default.init()
style_Page_Remind_INPUT_User_extra_list_scrollbar_default.set_radius(3)
style_Page_Remind_INPUT_User_extra_list_scrollbar_default.set_bg_opa(0)
Page_Remind_INPUT_User.get_list().add_style(style_Page_Remind_INPUT_User_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Page_Remind_LIST_remindlist
Page_Remind_LIST_remindlist = lv.list(Page_Remind)
Page_Remind_LIST_remindlist_item0 = Page_Remind_LIST_remindlist.add_btn(lv.SYMBOL.VOLUME_MAX, "12:00")
Page_Remind_LIST_remindlist_item1 = Page_Remind_LIST_remindlist.add_btn(lv.SYMBOL.VOLUME_MAX, "18:00")
Page_Remind_LIST_remindlist_item2 = Page_Remind_LIST_remindlist.add_btn(lv.SYMBOL.VOLUME_MAX, "21:00")
Page_Remind_LIST_remindlist.set_pos(21, 68)
Page_Remind_LIST_remindlist.set_size(170, 187)
Page_Remind_LIST_remindlist.set_scrollbar_mode(lv.SCROLLBAR_MODE.AUTO)
# Set style for Page_Remind_LIST_remindlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_LIST_remindlist.set_style_pad_top(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_pad_left(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_pad_right(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_pad_bottom(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Remind_LIST_remindlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Page_Remind_LIST_remindlist.set_style_radius(3, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_bg_opa(255, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
# Set style for Page_Remind_LIST_remindlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_LIST_remindlist_extra_btns_main_default = lv.style_t()
style_Page_Remind_LIST_remindlist_extra_btns_main_default.init()
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_pad_top(5)
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_pad_left(5)
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_pad_right(5)
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_pad_bottom(5)
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_border_width(0)
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_text_color(lv.color_hex(0x2f3243))
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_text_font(test_font("montserratMedium", 16))
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_radius(3)
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_bg_opa(255)
style_Page_Remind_LIST_remindlist_extra_btns_main_default.set_bg_color(lv.color_hex(0xffffff))
Page_Remind_LIST_remindlist_item2.add_style(style_Page_Remind_LIST_remindlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist_item1.add_style(style_Page_Remind_LIST_remindlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_LIST_remindlist_item0.add_style(style_Page_Remind_LIST_remindlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Page_Remind_LIST_remindlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_LIST_remindlist_extra_texts_main_default = lv.style_t()
style_Page_Remind_LIST_remindlist_extra_texts_main_default.init()
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_pad_top(5)
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_pad_left(5)
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_pad_right(5)
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_pad_bottom(5)
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_border_width(0)
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_radius(3)
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_bg_opa(255)
style_Page_Remind_LIST_remindlist_extra_texts_main_default.set_bg_color(lv.color_hex(0xffffff))

# Create Page_Remind_win_success
Page_Remind_win_success = lv.win(Page_Remind, 40)
Page_Remind_win_success.add_title("System")
Page_Remind_win_success_item0 = Page_Remind_win_success.add_btn(lv.SYMBOL.CLOSE, 40)
Page_Remind_win_success_label = lv.label(Page_Remind_win_success.get_content())
Page_Remind_win_success.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Page_Remind_win_success_label.set_text("Adding successfully!!\n")
Page_Remind_win_success.set_pos(44, 48)
Page_Remind_win_success.set_size(400, 177)
Page_Remind_win_success.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Page_Remind_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_win_success.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_win_success.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_win_success.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_win_success.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_win_success_extra_content_main_default = lv.style_t()
style_Page_Remind_win_success_extra_content_main_default.init()
style_Page_Remind_win_success_extra_content_main_default.set_bg_opa(255)
style_Page_Remind_win_success_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Page_Remind_win_success_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Page_Remind_win_success_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Page_Remind_win_success_extra_content_main_default.set_text_letter_space(0)
style_Page_Remind_win_success_extra_content_main_default.set_text_line_space(2)
Page_Remind_win_success.get_content().add_style(style_Page_Remind_win_success_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_win_success_extra_header_main_default = lv.style_t()
style_Page_Remind_win_success_extra_header_main_default.init()
style_Page_Remind_win_success_extra_header_main_default.set_bg_opa(236)
style_Page_Remind_win_success_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Page_Remind_win_success_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Page_Remind_win_success_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_win_success_extra_header_main_default.set_text_letter_space(0)
style_Page_Remind_win_success_extra_header_main_default.set_text_line_space(2)
Page_Remind_win_success.get_header().add_style(style_Page_Remind_win_success_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_win_success_extra_btns_main_default = lv.style_t()
style_Page_Remind_win_success_extra_btns_main_default.init()
style_Page_Remind_win_success_extra_btns_main_default.set_radius(8)
style_Page_Remind_win_success_extra_btns_main_default.set_bg_opa(255)
style_Page_Remind_win_success_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Page_Remind_win_success_extra_btns_main_default.set_shadow_width(0)
Page_Remind_win_success_item0.add_style(style_Page_Remind_win_success_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_Remind_win_importsuccess
Page_Remind_win_importsuccess = lv.win(Page_Remind, 40)
Page_Remind_win_importsuccess.add_title("System")
Page_Remind_win_importsuccess_item0 = Page_Remind_win_importsuccess.add_btn(lv.SYMBOL.CLOSE, 40)
Page_Remind_win_importsuccess_label = lv.label(Page_Remind_win_importsuccess.get_content())
Page_Remind_win_importsuccess.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Page_Remind_win_importsuccess_label.set_text("importing successfully!!\n")
Page_Remind_win_importsuccess.set_pos(40, 48)
Page_Remind_win_importsuccess.set_size(400, 177)
Page_Remind_win_importsuccess.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Page_Remind_win_importsuccess, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_Remind_win_importsuccess.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_win_importsuccess.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_win_importsuccess.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_Remind_win_importsuccess.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_win_importsuccess, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_win_importsuccess_extra_content_main_default = lv.style_t()
style_Page_Remind_win_importsuccess_extra_content_main_default.init()
style_Page_Remind_win_importsuccess_extra_content_main_default.set_bg_opa(255)
style_Page_Remind_win_importsuccess_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Page_Remind_win_importsuccess_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Page_Remind_win_importsuccess_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Page_Remind_win_importsuccess_extra_content_main_default.set_text_letter_space(0)
style_Page_Remind_win_importsuccess_extra_content_main_default.set_text_line_space(2)
Page_Remind_win_importsuccess.get_content().add_style(style_Page_Remind_win_importsuccess_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_win_importsuccess, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_win_importsuccess_extra_header_main_default = lv.style_t()
style_Page_Remind_win_importsuccess_extra_header_main_default.init()
style_Page_Remind_win_importsuccess_extra_header_main_default.set_bg_opa(236)
style_Page_Remind_win_importsuccess_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Page_Remind_win_importsuccess_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Page_Remind_win_importsuccess_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Page_Remind_win_importsuccess_extra_header_main_default.set_text_letter_space(0)
style_Page_Remind_win_importsuccess_extra_header_main_default.set_text_line_space(2)
Page_Remind_win_importsuccess.get_header().add_style(style_Page_Remind_win_importsuccess_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_Remind_win_importsuccess, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Page_Remind_win_importsuccess_extra_btns_main_default = lv.style_t()
style_Page_Remind_win_importsuccess_extra_btns_main_default.init()
style_Page_Remind_win_importsuccess_extra_btns_main_default.set_radius(8)
style_Page_Remind_win_importsuccess_extra_btns_main_default.set_bg_opa(255)
style_Page_Remind_win_importsuccess_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Page_Remind_win_importsuccess_extra_btns_main_default.set_shadow_width(0)
Page_Remind_win_importsuccess_item0.add_style(style_Page_Remind_win_importsuccess_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

Page_Remind.update_layout()
# Create Remind_delete
Remind_delete = lv.obj()
Remind_delete.set_size(480, 272)
# Set style for Remind_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Remind_delete_contBG
Remind_delete_contBG = lv.obj(Remind_delete)
Remind_delete_contBG.set_pos(0, 0)
Remind_delete_contBG.set_size(480, 60)
Remind_delete_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Remind_delete_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Remind_delete_BUT_back2
Remind_delete_BUT_back2 = lv.btn(Remind_delete_contBG)
Remind_delete_BUT_back2_label = lv.label(Remind_delete_BUT_back2)
Remind_delete_BUT_back2_label.set_text("<")
Remind_delete_BUT_back2_label.set_long_mode(lv.label.LONG.WRAP)
Remind_delete_BUT_back2_label.align(lv.ALIGN.CENTER, 0, 0)
Remind_delete_BUT_back2.set_style_pad_all(0, lv.STATE.DEFAULT)
Remind_delete_BUT_back2.set_pos(24, 17)
Remind_delete_BUT_back2.set_size(35, 32)
# Set style for Remind_delete_BUT_back2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete_BUT_back2.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back2.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back2.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back2.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back2.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back2.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back2.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Remind_delete_label_1
Remind_delete_label_1 = lv.label(Remind_delete_contBG)
Remind_delete_label_1.set_text("Delete Reminder")
Remind_delete_label_1.set_long_mode(lv.label.LONG.WRAP)
Remind_delete_label_1.set_pos(79, 22)
Remind_delete_label_1.set_size(323, 32)
# Set style for Remind_delete_label_1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete_label_1.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_label_1.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Remind_delete_ddlist_1
Remind_delete_ddlist_1 = lv.dropdown(Remind_delete)
Remind_delete_ddlist_1.set_options("12:00\n18:00\n21:00")
Remind_delete_ddlist_1.set_pos(74, 115)
Remind_delete_ddlist_1.set_size(216, 42)
# Set style for Remind_delete_ddlist_1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete_ddlist_1.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_text_font(test_font("montserratMedium", 24), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_ddlist_1.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Remind_delete_ddlist_1, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Remind_delete_ddlist_1_extra_list_selected_checked = lv.style_t()
style_Remind_delete_ddlist_1_extra_list_selected_checked.init()
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 15))
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_border_width(1)
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_border_opa(255)
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_radius(3)
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_bg_opa(255)
style_Remind_delete_ddlist_1_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Remind_delete_ddlist_1.get_list().add_style(style_Remind_delete_ddlist_1_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Remind_delete_ddlist_1, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Remind_delete_ddlist_1_extra_list_main_default = lv.style_t()
style_Remind_delete_ddlist_1_extra_list_main_default.init()
style_Remind_delete_ddlist_1_extra_list_main_default.set_max_height(90)
style_Remind_delete_ddlist_1_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Remind_delete_ddlist_1_extra_list_main_default.set_text_font(test_font("montserratMedium", 15))
style_Remind_delete_ddlist_1_extra_list_main_default.set_border_width(1)
style_Remind_delete_ddlist_1_extra_list_main_default.set_border_opa(255)
style_Remind_delete_ddlist_1_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Remind_delete_ddlist_1_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Remind_delete_ddlist_1_extra_list_main_default.set_radius(3)
style_Remind_delete_ddlist_1_extra_list_main_default.set_bg_opa(255)
style_Remind_delete_ddlist_1_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Remind_delete_ddlist_1.get_list().add_style(style_Remind_delete_ddlist_1_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Remind_delete_ddlist_1, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Remind_delete_ddlist_1_extra_list_scrollbar_default = lv.style_t()
style_Remind_delete_ddlist_1_extra_list_scrollbar_default.init()
style_Remind_delete_ddlist_1_extra_list_scrollbar_default.set_radius(3)
style_Remind_delete_ddlist_1_extra_list_scrollbar_default.set_bg_opa(255)
style_Remind_delete_ddlist_1_extra_list_scrollbar_default.set_bg_color(lv.color_hex(0x190482))
Remind_delete_ddlist_1.get_list().add_style(style_Remind_delete_ddlist_1_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Remind_delete_BUT_back
Remind_delete_BUT_back = lv.btn(Remind_delete)
Remind_delete_BUT_back_label = lv.label(Remind_delete_BUT_back)
Remind_delete_BUT_back_label.set_text("OK")
Remind_delete_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Remind_delete_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Remind_delete_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_pos(392, 216)
Remind_delete_BUT_back.set_size(71, 37)
# Set style for Remind_delete_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete_BUT_back.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Remind_delete_BUT_Delete
Remind_delete_BUT_Delete = lv.btn(Remind_delete)
Remind_delete_BUT_Delete_label = lv.label(Remind_delete_BUT_Delete)
Remind_delete_BUT_Delete_label.set_text("Delete")
Remind_delete_BUT_Delete_label.set_long_mode(lv.label.LONG.WRAP)
Remind_delete_BUT_Delete_label.align(lv.ALIGN.CENTER, 0, 0)
Remind_delete_BUT_Delete.set_style_pad_all(0, lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_pos(316, 118)
Remind_delete_BUT_Delete.set_size(100, 37)
# Set style for Remind_delete_BUT_Delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete_BUT_Delete.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_BUT_Delete.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Remind_delete_win_delete
Remind_delete_win_delete = lv.win(Remind_delete, 40)
Remind_delete_win_delete.add_title("System")
Remind_delete_win_delete_item0 = Remind_delete_win_delete.add_btn(lv.SYMBOL.CLOSE, 40)
Remind_delete_win_delete_label = lv.label(Remind_delete_win_delete.get_content())
Remind_delete_win_delete.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Remind_delete_win_delete_label.set_text("Reminder deleted!\n")
Remind_delete_win_delete.set_pos(44, 48)
Remind_delete_win_delete.set_size(400, 177)
Remind_delete_win_delete.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Remind_delete_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Remind_delete_win_delete.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_win_delete.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_win_delete.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Remind_delete_win_delete.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Remind_delete_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Remind_delete_win_delete_extra_content_main_default = lv.style_t()
style_Remind_delete_win_delete_extra_content_main_default.init()
style_Remind_delete_win_delete_extra_content_main_default.set_bg_opa(255)
style_Remind_delete_win_delete_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Remind_delete_win_delete_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Remind_delete_win_delete_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Remind_delete_win_delete_extra_content_main_default.set_text_letter_space(0)
style_Remind_delete_win_delete_extra_content_main_default.set_text_line_space(2)
Remind_delete_win_delete.get_content().add_style(style_Remind_delete_win_delete_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Remind_delete_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Remind_delete_win_delete_extra_header_main_default = lv.style_t()
style_Remind_delete_win_delete_extra_header_main_default.init()
style_Remind_delete_win_delete_extra_header_main_default.set_bg_opa(236)
style_Remind_delete_win_delete_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Remind_delete_win_delete_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Remind_delete_win_delete_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Remind_delete_win_delete_extra_header_main_default.set_text_letter_space(0)
style_Remind_delete_win_delete_extra_header_main_default.set_text_line_space(2)
Remind_delete_win_delete.get_header().add_style(style_Remind_delete_win_delete_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Remind_delete_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Remind_delete_win_delete_extra_btns_main_default = lv.style_t()
style_Remind_delete_win_delete_extra_btns_main_default.init()
style_Remind_delete_win_delete_extra_btns_main_default.set_radius(8)
style_Remind_delete_win_delete_extra_btns_main_default.set_bg_opa(255)
style_Remind_delete_win_delete_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Remind_delete_win_delete_extra_btns_main_default.set_shadow_width(0)
Remind_delete_win_delete_item0.add_style(style_Remind_delete_win_delete_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

Remind_delete.update_layout()
# Create Page_settings
Page_settings = lv.obj()
Page_settings.set_size(480, 272)
# Set style for Page_settings, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_settings_contBG
Page_settings_contBG = lv.obj(Page_settings)
Page_settings_contBG.set_pos(0, 0)
Page_settings_contBG.set_size(480, 60)
Page_settings_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Page_settings_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Page_settings_BUT_back
Page_settings_BUT_back = lv.btn(Page_settings_contBG)
Page_settings_BUT_back_label = lv.label(Page_settings_BUT_back)
Page_settings_BUT_back_label.set_text("<")
Page_settings_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Page_settings_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Page_settings_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_settings_BUT_back.set_pos(24, 17)
Page_settings_BUT_back.set_size(35, 32)
# Set style for Page_settings_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_settings_text_title
Page_settings_text_title = lv.label(Page_settings_contBG)
Page_settings_text_title.set_text("Settings")
Page_settings_text_title.set_long_mode(lv.label.LONG.WRAP)
Page_settings_text_title.set_pos(79, 22)
Page_settings_text_title.set_size(323, 32)
# Set style for Page_settings_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_settings_BUT_RC
Page_settings_BUT_RC = lv.imgbtn(Page_settings)
Page_settings_BUT_RC.add_flag(lv.obj.FLAG.CHECKABLE)
Page_settings_BUT_RC.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_btn2_alpha_145x173.bin", None)
Page_settings_BUT_RC.add_flag(lv.obj.FLAG.CHECKABLE)
Page_settings_BUT_RC_label = lv.label(Page_settings_BUT_RC)
Page_settings_BUT_RC_label.set_text("")
Page_settings_BUT_RC_label.set_long_mode(lv.label.LONG.WRAP)
Page_settings_BUT_RC_label.align(lv.ALIGN.CENTER, 0, 0)
Page_settings_BUT_RC.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_settings_BUT_RC.set_pos(172, 76)
Page_settings_BUT_RC.set_size(145, 173)
# Set style for Page_settings_BUT_RC, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_BUT_RC.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_RC.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_RC.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_RC.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_settings_BUT_RC, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Page_settings_BUT_RC.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_RC.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_RC.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_RC.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Page_settings_BUT_RC, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Page_settings_BUT_RC.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_RC.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_RC.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_RC.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Page_settings_BUT_RC, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Page_settings_BUT_RC.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Page_settings_BUT_FMM
Page_settings_BUT_FMM = lv.imgbtn(Page_settings)
Page_settings_BUT_FMM.add_flag(lv.obj.FLAG.CHECKABLE)
Page_settings_BUT_FMM.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_btn_bg_1_alpha_145x173.bin", None)
Page_settings_BUT_FMM.add_flag(lv.obj.FLAG.CHECKABLE)
Page_settings_BUT_FMM_label = lv.label(Page_settings_BUT_FMM)
Page_settings_BUT_FMM_label.set_text("")
Page_settings_BUT_FMM_label.set_long_mode(lv.label.LONG.WRAP)
Page_settings_BUT_FMM_label.align(lv.ALIGN.CENTER, 0, 0)
Page_settings_BUT_FMM.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_settings_BUT_FMM.set_pos(21, 76)
Page_settings_BUT_FMM.set_size(145, 173)
# Set style for Page_settings_BUT_FMM, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_BUT_FMM.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_FMM.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_FMM.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_FMM.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_settings_BUT_FMM, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Page_settings_BUT_FMM.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_FMM.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_FMM.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_FMM.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Page_settings_BUT_FMM, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Page_settings_BUT_FMM.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_FMM.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_FMM.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_FMM.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Page_settings_BUT_FMM, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Page_settings_BUT_FMM.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Page_settings_BUT_Net
Page_settings_BUT_Net = lv.imgbtn(Page_settings)
Page_settings_BUT_Net.add_flag(lv.obj.FLAG.CHECKABLE)
Page_settings_BUT_Net.set_src(lv.imgbtn.STATE.RELEASED, None, "B:MicroPython/_btn_bg_3_alpha_145x173.bin", None)
Page_settings_BUT_Net.add_flag(lv.obj.FLAG.CHECKABLE)
Page_settings_BUT_Net_label = lv.label(Page_settings_BUT_Net)
Page_settings_BUT_Net_label.set_text("")
Page_settings_BUT_Net_label.set_long_mode(lv.label.LONG.WRAP)
Page_settings_BUT_Net_label.align(lv.ALIGN.CENTER, 0, 0)
Page_settings_BUT_Net.set_style_pad_all(0, lv.STATE.DEFAULT)
Page_settings_BUT_Net.set_pos(323, 76)
Page_settings_BUT_Net.set_size(145, 173)
# Set style for Page_settings_BUT_Net, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_BUT_Net.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_Net.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_Net.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_BUT_Net.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Page_settings_BUT_Net, Part: lv.PART.MAIN, State: lv.STATE.PRESSED.
Page_settings_BUT_Net.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_Net.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_Net.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.PRESSED)
Page_settings_BUT_Net.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.PRESSED)
# Set style for Page_settings_BUT_Net, Part: lv.PART.MAIN, State: lv.STATE.CHECKED.
Page_settings_BUT_Net.set_style_img_opa(255, lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_Net.set_style_text_color(lv.color_hex(0xFF33FF), lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_Net.set_style_text_font(test_font("montserratMedium", 12), lv.PART.MAIN|lv.STATE.CHECKED)
Page_settings_BUT_Net.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.CHECKED)
# Set style for Page_settings_BUT_Net, Part: lv.PART.MAIN, State: LV_IMGBTN_STATE_RELEASED.
Page_settings_BUT_Net.set_style_img_opa(255, lv.PART.MAIN|lv.imgbtn.STATE.RELEASED)

# Create Page_settings_text_fmm
Page_settings_text_fmm = lv.label(Page_settings)
Page_settings_text_fmm.set_text("Family\nMember\nManage")
Page_settings_text_fmm.set_long_mode(lv.label.LONG.WRAP)
Page_settings_text_fmm.set_pos(39, 130)
Page_settings_text_fmm.set_size(109, 65)
Page_settings_text_fmm.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Page_settings_text_fmm, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_text_fmm.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_fmm.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_settings_text_reminder
Page_settings_text_reminder = lv.label(Page_settings)
Page_settings_text_reminder.set_text("Reminder\nControl")
Page_settings_text_reminder.set_long_mode(lv.label.LONG.WRAP)
Page_settings_text_reminder.set_pos(190, 143)
Page_settings_text_reminder.set_size(112, 46)
Page_settings_text_reminder.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Page_settings_text_reminder, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_text_reminder.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_reminder.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Page_settings_text_net
Page_settings_text_net = lv.label(Page_settings)
Page_settings_text_net.set_text("Network\nSettings")
Page_settings_text_net.set_long_mode(lv.label.LONG.WRAP)
Page_settings_text_net.set_pos(342, 143)
Page_settings_text_net.set_size(110, 46)
Page_settings_text_net.add_flag(lv.obj.FLAG.EVENT_BUBBLE)
# Set style for Page_settings_text_net, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Page_settings_text_net.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_text_letter_space(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Page_settings_text_net.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

Page_settings.update_layout()
# Create Networksetting
Networksetting = lv.obj()
g_kb_Networksetting = lv.keyboard(Networksetting)
g_kb_Networksetting.add_event_cb(lambda e: Networksetting_ta_event_cb(e, g_kb_Networksetting), lv.EVENT.ALL, None)
g_kb_Networksetting.add_flag(lv.obj.FLAG.HIDDEN)
g_kb_Networksetting.set_style_text_font(test_font("simsun", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting.set_size(480, 272)
# Set style for Networksetting, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Networksetting_contBG
Networksetting_contBG = lv.obj(Networksetting)
Networksetting_contBG.set_pos(0, 0)
Networksetting_contBG.set_size(480, 60)
Networksetting_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Networksetting_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Networksetting_BUT_back2
Networksetting_BUT_back2 = lv.btn(Networksetting_contBG)
Networksetting_BUT_back2_label = lv.label(Networksetting_BUT_back2)
Networksetting_BUT_back2_label.set_text("<")
Networksetting_BUT_back2_label.set_long_mode(lv.label.LONG.WRAP)
Networksetting_BUT_back2_label.align(lv.ALIGN.CENTER, 0, 0)
Networksetting_BUT_back2.set_style_pad_all(0, lv.STATE.DEFAULT)
Networksetting_BUT_back2.set_pos(24, 17)
Networksetting_BUT_back2.set_size(35, 32)
# Set style for Networksetting_BUT_back2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_BUT_back2.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back2.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back2.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back2.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back2.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back2.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back2.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Networksetting_text_title
Networksetting_text_title = lv.label(Networksetting_contBG)
Networksetting_text_title.set_text("Network Settings")
Networksetting_text_title.set_long_mode(lv.label.LONG.WRAP)
Networksetting_text_title.set_pos(79, 22)
Networksetting_text_title.set_size(323, 32)
# Set style for Networksetting_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Networksetting_BUT_back
Networksetting_BUT_back = lv.btn(Networksetting)
Networksetting_BUT_back_label = lv.label(Networksetting_BUT_back)
Networksetting_BUT_back_label.set_text("Save")
Networksetting_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Networksetting_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Networksetting_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Networksetting_BUT_back.set_pos(366, 224)
Networksetting_BUT_back.set_size(100, 37)
# Set style for Networksetting_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_BUT_back.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Networksetting_text_ps
Networksetting_text_ps = lv.label(Networksetting)
Networksetting_text_ps.set_text("Password")
Networksetting_text_ps.set_long_mode(lv.label.LONG.WRAP)
Networksetting_text_ps.set_pos(67, 138)
Networksetting_text_ps.set_size(86, 20)
# Set style for Networksetting_text_ps, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_text_ps.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ps.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Networksetting_text_ssid
Networksetting_text_ssid = lv.label(Networksetting)
Networksetting_text_ssid.set_text("SSID")
Networksetting_text_ssid.set_long_mode(lv.label.LONG.WRAP)
Networksetting_text_ssid.set_pos(72, 102)
Networksetting_text_ssid.set_size(87, 20)
# Set style for Networksetting_text_ssid, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_text_ssid.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_ssid.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Networksetting_text_cps
Networksetting_text_cps = lv.label(Networksetting)
Networksetting_text_cps.set_text("Comfirmed Password")
Networksetting_text_cps.set_long_mode(lv.label.LONG.WRAP)
Networksetting_text_cps.set_pos(67, 174)
Networksetting_text_cps.set_size(184, 35)
# Set style for Networksetting_text_cps, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_text_cps.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_text_cps.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Networksetting_INPUT_cps
Networksetting_INPUT_cps = lv.textarea(Networksetting)
Networksetting_INPUT_cps.set_text("")
Networksetting_INPUT_cps.set_password_bullet("*")
Networksetting_INPUT_cps.set_password_mode(True)
Networksetting_INPUT_cps.set_one_line(True)
Networksetting_INPUT_cps.add_event_cb(lambda e: Networksetting_ta_event_cb(e, g_kb_Networksetting), lv.EVENT.ALL, None)
Networksetting_INPUT_cps.set_pos(262, 167)
Networksetting_INPUT_cps.set_size(168, 28)
# Set style for Networksetting_INPUT_cps, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_INPUT_cps.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_text_font(test_font("montserratMedium", 14), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Networksetting_INPUT_cps, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Networksetting_INPUT_cps.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Networksetting_INPUT_cps.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Networksetting_INPUT_ps
Networksetting_INPUT_ps = lv.textarea(Networksetting)
Networksetting_INPUT_ps.set_text("")
Networksetting_INPUT_ps.set_password_bullet("*")
Networksetting_INPUT_ps.set_password_mode(True)
Networksetting_INPUT_ps.set_one_line(True)
Networksetting_INPUT_ps.add_event_cb(lambda e: Networksetting_ta_event_cb(e, g_kb_Networksetting), lv.EVENT.ALL, None)
Networksetting_INPUT_ps.set_pos(262, 130)
Networksetting_INPUT_ps.set_size(168, 28)
# Set style for Networksetting_INPUT_ps, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_INPUT_ps.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_text_font(test_font("montserratMedium", 14), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Networksetting_INPUT_ps, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Networksetting_INPUT_ps.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Networksetting_INPUT_ps.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Networksetting_INPUT_SSID
Networksetting_INPUT_SSID = lv.textarea(Networksetting)
Networksetting_INPUT_SSID.set_text("")
Networksetting_INPUT_SSID.set_password_bullet("*")
Networksetting_INPUT_SSID.set_password_mode(True)
Networksetting_INPUT_SSID.set_one_line(True)
Networksetting_INPUT_SSID.add_event_cb(lambda e: Networksetting_ta_event_cb(e, g_kb_Networksetting), lv.EVENT.ALL, None)
Networksetting_INPUT_SSID.set_pos(262, 94)
Networksetting_INPUT_SSID.set_size(168, 28)
# Set style for Networksetting_INPUT_SSID, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Networksetting_INPUT_SSID.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_text_font(test_font("montserratMedium", 14), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Networksetting_INPUT_SSID, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Networksetting_INPUT_SSID.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Networksetting_INPUT_SSID.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

Networksetting.update_layout()
# Create ReminderSettings
ReminderSettings = lv.obj()
ReminderSettings.set_size(480, 272)
# Set style for ReminderSettings, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create ReminderSettings_contBG
ReminderSettings_contBG = lv.obj(ReminderSettings)
ReminderSettings_contBG.set_pos(0, 0)
ReminderSettings_contBG.set_size(480, 60)
ReminderSettings_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for ReminderSettings_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create ReminderSettings_BUT_back2
ReminderSettings_BUT_back2 = lv.btn(ReminderSettings_contBG)
ReminderSettings_BUT_back2_label = lv.label(ReminderSettings_BUT_back2)
ReminderSettings_BUT_back2_label.set_text("<")
ReminderSettings_BUT_back2_label.set_long_mode(lv.label.LONG.WRAP)
ReminderSettings_BUT_back2_label.align(lv.ALIGN.CENTER, 0, 0)
ReminderSettings_BUT_back2.set_style_pad_all(0, lv.STATE.DEFAULT)
ReminderSettings_BUT_back2.set_pos(24, 17)
ReminderSettings_BUT_back2.set_size(35, 32)
# Set style for ReminderSettings_BUT_back2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_BUT_back2.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back2.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back2.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back2.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back2.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back2.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back2.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create ReminderSettings_text_title
ReminderSettings_text_title = lv.label(ReminderSettings_contBG)
ReminderSettings_text_title.set_text("Reminder Settings")
ReminderSettings_text_title.set_long_mode(lv.label.LONG.WRAP)
ReminderSettings_text_title.set_pos(79, 22)
ReminderSettings_text_title.set_size(323, 32)
# Set style for ReminderSettings_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create ReminderSettings_BUT_back
ReminderSettings_BUT_back = lv.btn(ReminderSettings)
ReminderSettings_BUT_back_label = lv.label(ReminderSettings_BUT_back)
ReminderSettings_BUT_back_label.set_text("Save")
ReminderSettings_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
ReminderSettings_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
ReminderSettings_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_pos(366, 224)
ReminderSettings_BUT_back.set_size(100, 37)
# Set style for ReminderSettings_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_BUT_back.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create ReminderSettings_text_frequency
ReminderSettings_text_frequency = lv.label(ReminderSettings)
ReminderSettings_text_frequency.set_text("Frequency")
ReminderSettings_text_frequency.set_long_mode(lv.label.LONG.WRAP)
ReminderSettings_text_frequency.set_pos(62, 184)
ReminderSettings_text_frequency.set_size(112, 20)
# Set style for ReminderSettings_text_frequency, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_text_frequency.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_frequency.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create ReminderSettings_text_volume
ReminderSettings_text_volume = lv.label(ReminderSettings)
ReminderSettings_text_volume.set_text("Volume")
ReminderSettings_text_volume.set_long_mode(lv.label.LONG.WRAP)
ReminderSettings_text_volume.set_pos(74, 146)
ReminderSettings_text_volume.set_size(100, 32)
# Set style for ReminderSettings_text_volume, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_text_volume.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_volume.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create ReminderSettings_text_offon
ReminderSettings_text_offon = lv.label(ReminderSettings)
ReminderSettings_text_offon.set_text("Off / On")
ReminderSettings_text_offon.set_long_mode(lv.label.LONG.WRAP)
ReminderSettings_text_offon.set_pos(74, 106)
ReminderSettings_text_offon.set_size(100, 32)
# Set style for ReminderSettings_text_offon, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_text_offon.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_text_offon.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create ReminderSettings_INPUT_Slider_freq
ReminderSettings_INPUT_Slider_freq = lv.slider(ReminderSettings)
ReminderSettings_INPUT_Slider_freq.set_range(0, 100)
ReminderSettings_INPUT_Slider_freq.set_mode(lv.slider.MODE.NORMAL)
ReminderSettings_INPUT_Slider_freq.set_value(50, lv.ANIM.OFF)
ReminderSettings_INPUT_Slider_freq.set_pos(196, 190)
ReminderSettings_INPUT_Slider_freq.set_size(160, 8)
# Set style for ReminderSettings_INPUT_Slider_freq, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_Slider_freq.set_style_bg_opa(60, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_radius(50, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for ReminderSettings_INPUT_Slider_freq, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_Slider_freq.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_radius(50, lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Set style for ReminderSettings_INPUT_Slider_freq, Part: lv.PART.KNOB, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_Slider_freq.set_style_bg_opa(255, lv.PART.KNOB|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.KNOB|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_freq.set_style_radius(50, lv.PART.KNOB|lv.STATE.DEFAULT)

# Create ReminderSettings_INPUT_Slider_Vol
ReminderSettings_INPUT_Slider_Vol = lv.slider(ReminderSettings)
ReminderSettings_INPUT_Slider_Vol.set_range(0, 100)
ReminderSettings_INPUT_Slider_Vol.set_mode(lv.slider.MODE.NORMAL)
ReminderSettings_INPUT_Slider_Vol.set_value(50, lv.ANIM.OFF)
ReminderSettings_INPUT_Slider_Vol.set_pos(196, 152)
ReminderSettings_INPUT_Slider_Vol.set_size(160, 8)
# Set style for ReminderSettings_INPUT_Slider_Vol, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_Slider_Vol.set_style_bg_opa(60, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_radius(50, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for ReminderSettings_INPUT_Slider_Vol, Part: lv.PART.INDICATOR, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_Slider_Vol.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_radius(50, lv.PART.INDICATOR|lv.STATE.DEFAULT)

# Set style for ReminderSettings_INPUT_Slider_Vol, Part: lv.PART.KNOB, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_Slider_Vol.set_style_bg_opa(255, lv.PART.KNOB|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.KNOB|lv.STATE.DEFAULT)
ReminderSettings_INPUT_Slider_Vol.set_style_radius(50, lv.PART.KNOB|lv.STATE.DEFAULT)

# Create ReminderSettings_INPUT_SW_offon
ReminderSettings_INPUT_SW_offon = lv.switch(ReminderSettings)
ReminderSettings_INPUT_SW_offon.set_pos(256, 106)
ReminderSettings_INPUT_SW_offon.set_size(40, 20)
# Set style for ReminderSettings_INPUT_SW_offon, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_SW_offon.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_SW_offon.set_style_bg_color(lv.color_hex(0xe6e2e6), lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_SW_offon.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_SW_offon.set_style_radius(10, lv.PART.MAIN|lv.STATE.DEFAULT)
ReminderSettings_INPUT_SW_offon.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for ReminderSettings_INPUT_SW_offon, Part: lv.PART.INDICATOR, State: lv.STATE.CHECKED.
ReminderSettings_INPUT_SW_offon.set_style_bg_opa(255, lv.PART.INDICATOR|lv.STATE.CHECKED)
ReminderSettings_INPUT_SW_offon.set_style_bg_color(lv.color_hex(0x2195f6), lv.PART.INDICATOR|lv.STATE.CHECKED)
ReminderSettings_INPUT_SW_offon.set_style_border_width(0, lv.PART.INDICATOR|lv.STATE.CHECKED)

# Set style for ReminderSettings_INPUT_SW_offon, Part: lv.PART.KNOB, State: lv.STATE.DEFAULT.
ReminderSettings_INPUT_SW_offon.set_style_bg_opa(255, lv.PART.KNOB|lv.STATE.DEFAULT)
ReminderSettings_INPUT_SW_offon.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.KNOB|lv.STATE.DEFAULT)
ReminderSettings_INPUT_SW_offon.set_style_border_width(0, lv.PART.KNOB|lv.STATE.DEFAULT)
ReminderSettings_INPUT_SW_offon.set_style_radius(10, lv.PART.KNOB|lv.STATE.DEFAULT)

ReminderSettings.update_layout()
# Create MemberManagement
MemberManagement = lv.obj()
MemberManagement.set_size(480, 272)
# Set style for MemberManagement, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
MemberManagement.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create MemberManagement_contBG
MemberManagement_contBG = lv.obj(MemberManagement)
MemberManagement_contBG.set_pos(0, 0)
MemberManagement_contBG.set_size(480, 60)
MemberManagement_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for MemberManagement_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
MemberManagement_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create MemberManagement_BUT_back2
MemberManagement_BUT_back2 = lv.btn(MemberManagement_contBG)
MemberManagement_BUT_back2_label = lv.label(MemberManagement_BUT_back2)
MemberManagement_BUT_back2_label.set_text("<")
MemberManagement_BUT_back2_label.set_long_mode(lv.label.LONG.WRAP)
MemberManagement_BUT_back2_label.align(lv.ALIGN.CENTER, 0, 0)
MemberManagement_BUT_back2.set_style_pad_all(0, lv.STATE.DEFAULT)
MemberManagement_BUT_back2.set_pos(24, 17)
MemberManagement_BUT_back2.set_size(35, 32)
# Set style for MemberManagement_BUT_back2, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
MemberManagement_BUT_back2.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back2.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back2.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back2.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back2.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back2.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back2.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create MemberManagement_text_title
MemberManagement_text_title = lv.label(MemberManagement_contBG)
MemberManagement_text_title.set_text("Management")
MemberManagement_text_title.set_long_mode(lv.label.LONG.WRAP)
MemberManagement_text_title.set_pos(79, 22)
MemberManagement_text_title.set_size(323, 32)
# Set style for MemberManagement_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
MemberManagement_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create MemberManagement_BUT_back
MemberManagement_BUT_back = lv.btn(MemberManagement)
MemberManagement_BUT_back_label = lv.label(MemberManagement_BUT_back)
MemberManagement_BUT_back_label.set_text("Exit")
MemberManagement_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
MemberManagement_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
MemberManagement_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_pos(366, 224)
MemberManagement_BUT_back.set_size(100, 37)
# Set style for MemberManagement_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
MemberManagement_BUT_back.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create MemberManagement_BUT_addmember
MemberManagement_BUT_addmember = lv.btn(MemberManagement)
MemberManagement_BUT_addmember_label = lv.label(MemberManagement_BUT_addmember)
MemberManagement_BUT_addmember_label.set_text("Add Member")
MemberManagement_BUT_addmember_label.set_long_mode(lv.label.LONG.WRAP)
MemberManagement_BUT_addmember_label.align(lv.ALIGN.CENTER, 0, 0)
MemberManagement_BUT_addmember.set_style_pad_all(0, lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_pos(208, 224)
MemberManagement_BUT_addmember.set_size(149, 37)
# Set style for MemberManagement_BUT_addmember, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
MemberManagement_BUT_addmember.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_BUT_addmember.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create MemberManagement_LIST_userlist
MemberManagement_LIST_userlist = lv.list(MemberManagement)
MemberManagement_LIST_userlist_item0 = MemberManagement_LIST_userlist.add_btn(lv.SYMBOL.SAVE, "Max")
MemberManagement_LIST_userlist_item1 = MemberManagement_LIST_userlist.add_btn(lv.SYMBOL.SAVE, "Brian")
MemberManagement_LIST_userlist_item2 = MemberManagement_LIST_userlist.add_btn(lv.SYMBOL.SAVE, "Johnson")
MemberManagement_LIST_userlist.set_pos(69, 76)
MemberManagement_LIST_userlist.set_size(328, 137)
MemberManagement_LIST_userlist.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for MemberManagement_LIST_userlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
MemberManagement_LIST_userlist.set_style_pad_top(5, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_pad_left(5, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_pad_right(5, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_pad_bottom(5, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for MemberManagement_LIST_userlist, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
MemberManagement_LIST_userlist.set_style_radius(3, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_bg_opa(255, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
# Set style for MemberManagement_LIST_userlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_MemberManagement_LIST_userlist_extra_btns_main_default = lv.style_t()
style_MemberManagement_LIST_userlist_extra_btns_main_default.init()
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_pad_top(5)
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_pad_left(5)
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_pad_right(5)
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_pad_bottom(5)
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_border_width(0)
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_text_color(lv.color_hex(0x0D3055))
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_text_font(test_font("montserratMedium", 17))
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_radius(3)
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_bg_opa(255)
style_MemberManagement_LIST_userlist_extra_btns_main_default.set_bg_color(lv.color_hex(0xffffff))
MemberManagement_LIST_userlist_item2.add_style(style_MemberManagement_LIST_userlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist_item1.add_style(style_MemberManagement_LIST_userlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
MemberManagement_LIST_userlist_item0.add_style(style_MemberManagement_LIST_userlist_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for MemberManagement_LIST_userlist, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_MemberManagement_LIST_userlist_extra_texts_main_default = lv.style_t()
style_MemberManagement_LIST_userlist_extra_texts_main_default.init()
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_pad_top(5)
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_pad_left(5)
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_pad_right(5)
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_pad_bottom(5)
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_border_width(0)
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_text_color(lv.color_hex(0x0D3055))
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_text_font(test_font("montserratMedium", 12))
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_radius(3)
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_bg_opa(255)
style_MemberManagement_LIST_userlist_extra_texts_main_default.set_bg_color(lv.color_hex(0xffffff))

MemberManagement.update_layout()
# Create AddMember
AddMember = lv.obj()
g_kb_AddMember = lv.keyboard(AddMember)
g_kb_AddMember.add_event_cb(lambda e: AddMember_ta_event_cb(e, g_kb_AddMember), lv.EVENT.ALL, None)
g_kb_AddMember.add_flag(lv.obj.FLAG.HIDDEN)
g_kb_AddMember.set_style_text_font(test_font("simsun", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember.set_size(480, 272)
# Set style for AddMember, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create AddMember_contBG
AddMember_contBG = lv.obj(AddMember)
AddMember_contBG.set_pos(0, 0)
AddMember_contBG.set_size(480, 60)
AddMember_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for AddMember_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create AddMember_BUT_back
AddMember_BUT_back = lv.btn(AddMember_contBG)
AddMember_BUT_back_label = lv.label(AddMember_BUT_back)
AddMember_BUT_back_label.set_text("<")
AddMember_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
AddMember_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
AddMember_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
AddMember_BUT_back.set_pos(24, 17)
AddMember_BUT_back.set_size(35, 32)
# Set style for AddMember_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create AddMember_text_title
AddMember_text_title = lv.label(AddMember_contBG)
AddMember_text_title.set_text("Member's information")
AddMember_text_title.set_long_mode(lv.label.LONG.WRAP)
AddMember_text_title.set_pos(79, 22)
AddMember_text_title.set_size(323, 32)
# Set style for AddMember_text_title, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_text_title.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_title.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create AddMember_BUT_Add
AddMember_BUT_Add = lv.btn(AddMember)
AddMember_BUT_Add_label = lv.label(AddMember_BUT_Add)
AddMember_BUT_Add_label.set_text("Add")
AddMember_BUT_Add_label.set_long_mode(lv.label.LONG.WRAP)
AddMember_BUT_Add_label.align(lv.ALIGN.CENTER, 0, 0)
AddMember_BUT_Add.set_style_pad_all(0, lv.STATE.DEFAULT)
AddMember_BUT_Add.set_pos(366, 224)
AddMember_BUT_Add.set_size(100, 37)
# Set style for AddMember_BUT_Add, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_BUT_Add.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_Add.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_Add.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_Add.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_Add.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_Add.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_Add.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_BUT_Add.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create AddMember_text_name
AddMember_text_name = lv.label(AddMember)
AddMember_text_name.set_text("Name")
AddMember_text_name.set_long_mode(lv.label.LONG.WRAP)
AddMember_text_name.set_pos(54, 114)
AddMember_text_name.set_size(100, 32)
# Set style for AddMember_text_name, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_text_name.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_name.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create AddMember_text_age
AddMember_text_age = lv.label(AddMember)
AddMember_text_age.set_text("Age")
AddMember_text_age.set_long_mode(lv.label.LONG.WRAP)
AddMember_text_age.set_pos(190, 114)
AddMember_text_age.set_size(100, 32)
# Set style for AddMember_text_age, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_text_age.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_age.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create AddMember_text_gender
AddMember_text_gender = lv.label(AddMember)
AddMember_text_gender.set_text("Gender")
AddMember_text_gender.set_long_mode(lv.label.LONG.WRAP)
AddMember_text_gender.set_pos(328, 114)
AddMember_text_gender.set_size(100, 32)
# Set style for AddMember_text_gender, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_text_gender.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_text_gender.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create AddMember_INPUT_Gender
AddMember_INPUT_Gender = lv.dropdown(AddMember)
AddMember_INPUT_Gender.set_options("Male\nFemale")
AddMember_INPUT_Gender.set_pos(321, 138)
AddMember_INPUT_Gender.set_size(119, 35)
# Set style for AddMember_INPUT_Gender, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_INPUT_Gender.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Gender.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for AddMember_INPUT_Gender, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_AddMember_INPUT_Gender_extra_list_selected_checked = lv.style_t()
style_AddMember_INPUT_Gender_extra_list_selected_checked.init()
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_border_width(1)
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_border_opa(255)
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_radius(3)
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_bg_opa(255)
style_AddMember_INPUT_Gender_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
AddMember_INPUT_Gender.get_list().add_style(style_AddMember_INPUT_Gender_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for AddMember_INPUT_Gender, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_AddMember_INPUT_Gender_extra_list_main_default = lv.style_t()
style_AddMember_INPUT_Gender_extra_list_main_default.init()
style_AddMember_INPUT_Gender_extra_list_main_default.set_max_height(90)
style_AddMember_INPUT_Gender_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_AddMember_INPUT_Gender_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_AddMember_INPUT_Gender_extra_list_main_default.set_border_width(1)
style_AddMember_INPUT_Gender_extra_list_main_default.set_border_opa(255)
style_AddMember_INPUT_Gender_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_AddMember_INPUT_Gender_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_AddMember_INPUT_Gender_extra_list_main_default.set_radius(3)
style_AddMember_INPUT_Gender_extra_list_main_default.set_bg_opa(255)
style_AddMember_INPUT_Gender_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
AddMember_INPUT_Gender.get_list().add_style(style_AddMember_INPUT_Gender_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for AddMember_INPUT_Gender, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_AddMember_INPUT_Gender_extra_list_scrollbar_default = lv.style_t()
style_AddMember_INPUT_Gender_extra_list_scrollbar_default.init()
style_AddMember_INPUT_Gender_extra_list_scrollbar_default.set_radius(3)
style_AddMember_INPUT_Gender_extra_list_scrollbar_default.set_bg_opa(255)
style_AddMember_INPUT_Gender_extra_list_scrollbar_default.set_bg_color(lv.color_hex(0x190482))
AddMember_INPUT_Gender.get_list().add_style(style_AddMember_INPUT_Gender_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create AddMember_INPUT_Age
AddMember_INPUT_Age = lv.textarea(AddMember)
AddMember_INPUT_Age.set_text("")
AddMember_INPUT_Age.set_password_bullet("*")
AddMember_INPUT_Age.set_password_mode(True)
AddMember_INPUT_Age.set_one_line(True)
AddMember_INPUT_Age.add_event_cb(lambda e: AddMember_ta_event_cb(e, g_kb_AddMember), lv.EVENT.ALL, None)
AddMember_INPUT_Age.set_pos(183, 138)
AddMember_INPUT_Age.set_size(115, 37)
# Set style for AddMember_INPUT_Age, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_INPUT_Age.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for AddMember_INPUT_Age, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
AddMember_INPUT_Age.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
AddMember_INPUT_Age.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create AddMember_INPUT_Name
AddMember_INPUT_Name = lv.textarea(AddMember)
AddMember_INPUT_Name.set_text("")
AddMember_INPUT_Name.set_password_bullet("*")
AddMember_INPUT_Name.set_password_mode(True)
AddMember_INPUT_Name.set_one_line(True)
AddMember_INPUT_Name.add_event_cb(lambda e: AddMember_ta_event_cb(e, g_kb_AddMember), lv.EVENT.ALL, None)
AddMember_INPUT_Name.set_pos(47, 138)
AddMember_INPUT_Name.set_size(115, 37)
# Set style for AddMember_INPUT_Name, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_INPUT_Name.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for AddMember_INPUT_Name, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
AddMember_INPUT_Name.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
AddMember_INPUT_Name.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create AddMember_win_success
AddMember_win_success = lv.win(AddMember, 40)
AddMember_win_success.add_title("System")
AddMember_win_success_item0 = AddMember_win_success.add_btn(lv.SYMBOL.CLOSE, 40)
AddMember_win_success_label = lv.label(AddMember_win_success.get_content())
AddMember_win_success.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
AddMember_win_success_label.set_text("Adding successfully!!\n")
AddMember_win_success.set_pos(44, 48)
AddMember_win_success.set_size(400, 177)
AddMember_win_success.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for AddMember_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
AddMember_win_success.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_win_success.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_win_success.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
AddMember_win_success.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for AddMember_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_AddMember_win_success_extra_content_main_default = lv.style_t()
style_AddMember_win_success_extra_content_main_default.init()
style_AddMember_win_success_extra_content_main_default.set_bg_opa(255)
style_AddMember_win_success_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_AddMember_win_success_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_AddMember_win_success_extra_content_main_default.set_text_font(test_font("arial", 15))
style_AddMember_win_success_extra_content_main_default.set_text_letter_space(0)
style_AddMember_win_success_extra_content_main_default.set_text_line_space(2)
AddMember_win_success.get_content().add_style(style_AddMember_win_success_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for AddMember_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_AddMember_win_success_extra_header_main_default = lv.style_t()
style_AddMember_win_success_extra_header_main_default.init()
style_AddMember_win_success_extra_header_main_default.set_bg_opa(236)
style_AddMember_win_success_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_AddMember_win_success_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_AddMember_win_success_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_AddMember_win_success_extra_header_main_default.set_text_letter_space(0)
style_AddMember_win_success_extra_header_main_default.set_text_line_space(2)
AddMember_win_success.get_header().add_style(style_AddMember_win_success_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for AddMember_win_success, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_AddMember_win_success_extra_btns_main_default = lv.style_t()
style_AddMember_win_success_extra_btns_main_default.init()
style_AddMember_win_success_extra_btns_main_default.set_radius(8)
style_AddMember_win_success_extra_btns_main_default.set_bg_opa(255)
style_AddMember_win_success_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_AddMember_win_success_extra_btns_main_default.set_shadow_width(0)
AddMember_win_success_item0.add_style(style_AddMember_win_success_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

AddMember.update_layout()
# Create Modifymember
Modifymember = lv.obj()
Modifymember.set_size(480, 272)
# Set style for Modifymember, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember.set_style_bg_color(lv.color_hex(0xF3F8FE), lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_contBG
Modifymember_contBG = lv.obj(Modifymember)
Modifymember_contBG.set_pos(0, 0)
Modifymember_contBG.set_size(480, 60)
Modifymember_contBG.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
# Set style for Modifymember_contBG, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_contBG.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_contBG.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Create Modifymember_BUT_back
Modifymember_BUT_back = lv.btn(Modifymember_contBG)
Modifymember_BUT_back_label = lv.label(Modifymember_BUT_back)
Modifymember_BUT_back_label.set_text("<")
Modifymember_BUT_back_label.set_long_mode(lv.label.LONG.WRAP)
Modifymember_BUT_back_label.align(lv.ALIGN.CENTER, 0, 0)
Modifymember_BUT_back.set_style_pad_all(0, lv.STATE.DEFAULT)
Modifymember_BUT_back.set_pos(24, 17)
Modifymember_BUT_back.set_size(35, 32)
# Set style for Modifymember_BUT_back, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_BUT_back.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_back.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_back.set_style_radius(5, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_back.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_back.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_back.set_style_text_font(test_font("montserratMedium", 25), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_back.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_Modify
Modifymember_Modify = lv.label(Modifymember_contBG)
Modifymember_Modify.set_text("Modify information")
Modifymember_Modify.set_long_mode(lv.label.LONG.WRAP)
Modifymember_Modify.set_pos(79, 22)
Modifymember_Modify.set_size(323, 32)
# Set style for Modifymember_Modify, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_Modify.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_text_font(test_font("montserratMedium", 20), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_text_letter_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_Modify.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_BUT_Save
Modifymember_BUT_Save = lv.btn(Modifymember)
Modifymember_BUT_Save_label = lv.label(Modifymember_BUT_Save)
Modifymember_BUT_Save_label.set_text("Save")
Modifymember_BUT_Save_label.set_long_mode(lv.label.LONG.WRAP)
Modifymember_BUT_Save_label.align(lv.ALIGN.CENTER, 0, 0)
Modifymember_BUT_Save.set_style_pad_all(0, lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_pos(366, 224)
Modifymember_BUT_Save.set_size(100, 37)
# Set style for Modifymember_BUT_Save, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_BUT_Save.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_Save.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_BUT_deletemember
Modifymember_BUT_deletemember = lv.btn(Modifymember)
Modifymember_BUT_deletemember_label = lv.label(Modifymember_BUT_deletemember)
Modifymember_BUT_deletemember_label.set_text("Delete Member")
Modifymember_BUT_deletemember_label.set_long_mode(lv.label.LONG.WRAP)
Modifymember_BUT_deletemember_label.align(lv.ALIGN.CENTER, 0, 0)
Modifymember_BUT_deletemember.set_style_pad_all(0, lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_pos(206, 224)
Modifymember_BUT_deletemember.set_size(153, 37)
# Set style for Modifymember_BUT_deletemember, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_BUT_deletemember.set_style_bg_opa(206, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_style_bg_color(lv.color_hex(0x190482), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_style_radius(17, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_style_text_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_style_text_font(test_font("montserratMedium", 18), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_BUT_deletemember.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_INPUT_gender
Modifymember_INPUT_gender = lv.dropdown(Modifymember)
Modifymember_INPUT_gender.set_options("Male\nFemale")
Modifymember_INPUT_gender.set_pos(318, 138)
Modifymember_INPUT_gender.set_size(119, 35)
# Set style for Modifymember_INPUT_gender, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_INPUT_gender.set_style_text_color(lv.color_hex(0x0D3055), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_border_width(1, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_border_color(lv.color_hex(0xe1e6ee), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_pad_top(8, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_pad_left(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_pad_right(6, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_radius(3, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_gender.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Modifymember_INPUT_gender, Part: lv.PART.SELECTED, State: lv.STATE.CHECKED.
style_Modifymember_INPUT_gender_extra_list_selected_checked = lv.style_t()
style_Modifymember_INPUT_gender_extra_list_selected_checked.init()
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_text_color(lv.color_hex(0xffffff))
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_text_font(test_font("montserratMedium", 12))
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_border_width(1)
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_border_opa(255)
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_border_color(lv.color_hex(0xe1e6ee))
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_border_side(lv.BORDER_SIDE.FULL)
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_radius(3)
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_bg_opa(255)
style_Modifymember_INPUT_gender_extra_list_selected_checked.set_bg_color(lv.color_hex(0x00a1b5))
Modifymember_INPUT_gender.get_list().add_style(style_Modifymember_INPUT_gender_extra_list_selected_checked, lv.PART.SELECTED|lv.STATE.CHECKED)
# Set style for Modifymember_INPUT_gender, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Modifymember_INPUT_gender_extra_list_main_default = lv.style_t()
style_Modifymember_INPUT_gender_extra_list_main_default.init()
style_Modifymember_INPUT_gender_extra_list_main_default.set_max_height(90)
style_Modifymember_INPUT_gender_extra_list_main_default.set_text_color(lv.color_hex(0x0D3055))
style_Modifymember_INPUT_gender_extra_list_main_default.set_text_font(test_font("montserratMedium", 12))
style_Modifymember_INPUT_gender_extra_list_main_default.set_border_width(1)
style_Modifymember_INPUT_gender_extra_list_main_default.set_border_opa(255)
style_Modifymember_INPUT_gender_extra_list_main_default.set_border_color(lv.color_hex(0xe1e6ee))
style_Modifymember_INPUT_gender_extra_list_main_default.set_border_side(lv.BORDER_SIDE.FULL)
style_Modifymember_INPUT_gender_extra_list_main_default.set_radius(3)
style_Modifymember_INPUT_gender_extra_list_main_default.set_bg_opa(255)
style_Modifymember_INPUT_gender_extra_list_main_default.set_bg_color(lv.color_hex(0xffffff))
Modifymember_INPUT_gender.get_list().add_style(style_Modifymember_INPUT_gender_extra_list_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Modifymember_INPUT_gender, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
style_Modifymember_INPUT_gender_extra_list_scrollbar_default = lv.style_t()
style_Modifymember_INPUT_gender_extra_list_scrollbar_default.init()
style_Modifymember_INPUT_gender_extra_list_scrollbar_default.set_radius(3)
style_Modifymember_INPUT_gender_extra_list_scrollbar_default.set_bg_opa(255)
style_Modifymember_INPUT_gender_extra_list_scrollbar_default.set_bg_color(lv.color_hex(0x190482))
Modifymember_INPUT_gender.get_list().add_style(style_Modifymember_INPUT_gender_extra_list_scrollbar_default, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Modifymember_text_gender
Modifymember_text_gender = lv.label(Modifymember)
Modifymember_text_gender.set_text("Gender")
Modifymember_text_gender.set_long_mode(lv.label.LONG.WRAP)
Modifymember_text_gender.set_pos(327, 114)
Modifymember_text_gender.set_size(100, 32)
# Set style for Modifymember_text_gender, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_text_gender.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_gender.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_INPUT_age
Modifymember_INPUT_age = lv.textarea(Modifymember)
Modifymember_INPUT_age.set_text("")
Modifymember_INPUT_age.set_password_bullet("*")
Modifymember_INPUT_age.set_password_mode(True)
Modifymember_INPUT_age.set_one_line(True)
Modifymember_INPUT_age.set_pos(183, 138)
Modifymember_INPUT_age.set_size(115, 37)
# Set style for Modifymember_INPUT_age, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_INPUT_age.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Modifymember_INPUT_age, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Modifymember_INPUT_age.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Modifymember_INPUT_age.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Modifymember_text_age
Modifymember_text_age = lv.label(Modifymember)
Modifymember_text_age.set_text("Age")
Modifymember_text_age.set_long_mode(lv.label.LONG.WRAP)
Modifymember_text_age.set_pos(190, 114)
Modifymember_text_age.set_size(100, 32)
# Set style for Modifymember_text_age, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_text_age.set_style_border_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_radius(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_text_font(test_font("montserratMedium", 16), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_text_line_space(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_text_align(lv.TEXT_ALIGN.CENTER, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_bg_opa(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_pad_top(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_pad_right(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_pad_bottom(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_pad_left(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_text_age.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_OUTPUT_User
Modifymember_OUTPUT_User = lv.textarea(Modifymember)
Modifymember_OUTPUT_User.set_text("")
Modifymember_OUTPUT_User.set_password_bullet("*")
Modifymember_OUTPUT_User.set_password_mode(True)
Modifymember_OUTPUT_User.set_one_line(True)
Modifymember_OUTPUT_User.set_pos(47, 138)
Modifymember_OUTPUT_User.set_size(115, 37)
# Set style for Modifymember_OUTPUT_User, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_OUTPUT_User.set_style_text_color(lv.color_hex(0x000000), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_text_font(test_font("montserratMedium", 17), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_text_letter_space(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_text_align(lv.TEXT_ALIGN.LEFT, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_bg_color(lv.color_hex(0xffffff), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_border_width(2, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_border_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_border_color(lv.color_hex(0xe6e6e6), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_border_side(lv.BORDER_SIDE.FULL, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_pad_top(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_pad_right(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_pad_left(4, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_radius(4, lv.PART.MAIN|lv.STATE.DEFAULT)

# Set style for Modifymember_OUTPUT_User, Part: lv.PART.SCROLLBAR, State: lv.STATE.DEFAULT.
Modifymember_OUTPUT_User.set_style_bg_opa(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)
Modifymember_OUTPUT_User.set_style_radius(0, lv.PART.SCROLLBAR|lv.STATE.DEFAULT)

# Create Modifymember_win_save
Modifymember_win_save = lv.win(Modifymember, 40)
Modifymember_win_save.add_title("System")
Modifymember_win_save_item0 = Modifymember_win_save.add_btn(lv.SYMBOL.CLOSE, 40)
Modifymember_win_save_label = lv.label(Modifymember_win_save.get_content())
Modifymember_win_save.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Modifymember_win_save_label.set_text("Saved!\n")
Modifymember_win_save.set_pos(44, 48)
Modifymember_win_save.set_size(400, 177)
Modifymember_win_save.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Modifymember_win_save, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_win_save.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_win_save.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_win_save.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_win_save.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Modifymember_win_save, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Modifymember_win_save_extra_content_main_default = lv.style_t()
style_Modifymember_win_save_extra_content_main_default.init()
style_Modifymember_win_save_extra_content_main_default.set_bg_opa(255)
style_Modifymember_win_save_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Modifymember_win_save_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Modifymember_win_save_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Modifymember_win_save_extra_content_main_default.set_text_letter_space(0)
style_Modifymember_win_save_extra_content_main_default.set_text_line_space(2)
Modifymember_win_save.get_content().add_style(style_Modifymember_win_save_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Modifymember_win_save, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Modifymember_win_save_extra_header_main_default = lv.style_t()
style_Modifymember_win_save_extra_header_main_default.init()
style_Modifymember_win_save_extra_header_main_default.set_bg_opa(236)
style_Modifymember_win_save_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Modifymember_win_save_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Modifymember_win_save_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Modifymember_win_save_extra_header_main_default.set_text_letter_space(0)
style_Modifymember_win_save_extra_header_main_default.set_text_line_space(2)
Modifymember_win_save.get_header().add_style(style_Modifymember_win_save_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Modifymember_win_save, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Modifymember_win_save_extra_btns_main_default = lv.style_t()
style_Modifymember_win_save_extra_btns_main_default.init()
style_Modifymember_win_save_extra_btns_main_default.set_radius(8)
style_Modifymember_win_save_extra_btns_main_default.set_bg_opa(255)
style_Modifymember_win_save_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Modifymember_win_save_extra_btns_main_default.set_shadow_width(0)
Modifymember_win_save_item0.add_style(style_Modifymember_win_save_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# Create Modifymember_win_delete
Modifymember_win_delete = lv.win(Modifymember, 40)
Modifymember_win_delete.add_title("System")
Modifymember_win_delete_item0 = Modifymember_win_delete.add_btn(lv.SYMBOL.CLOSE, 40)
Modifymember_win_delete_label = lv.label(Modifymember_win_delete.get_content())
Modifymember_win_delete.get_content().set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
Modifymember_win_delete_label.set_text("Member deleted!\n")
Modifymember_win_delete.set_pos(44, 48)
Modifymember_win_delete.set_size(400, 177)
Modifymember_win_delete.add_flag(lv.obj.FLAG.HIDDEN)
# Set style for Modifymember_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
Modifymember_win_delete.set_style_bg_opa(255, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_win_delete.set_style_bg_color(lv.color_hex(0xeeeef6), lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_win_delete.set_style_outline_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
Modifymember_win_delete.set_style_shadow_width(0, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Modifymember_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Modifymember_win_delete_extra_content_main_default = lv.style_t()
style_Modifymember_win_delete_extra_content_main_default.init()
style_Modifymember_win_delete_extra_content_main_default.set_bg_opa(255)
style_Modifymember_win_delete_extra_content_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Modifymember_win_delete_extra_content_main_default.set_text_color(lv.color_hex(0x393c41))
style_Modifymember_win_delete_extra_content_main_default.set_text_font(test_font("arial", 15))
style_Modifymember_win_delete_extra_content_main_default.set_text_letter_space(0)
style_Modifymember_win_delete_extra_content_main_default.set_text_line_space(2)
Modifymember_win_delete.get_content().add_style(style_Modifymember_win_delete_extra_content_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Modifymember_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Modifymember_win_delete_extra_header_main_default = lv.style_t()
style_Modifymember_win_delete_extra_header_main_default.init()
style_Modifymember_win_delete_extra_header_main_default.set_bg_opa(236)
style_Modifymember_win_delete_extra_header_main_default.set_bg_color(lv.color_hex(0x7752FE))
style_Modifymember_win_delete_extra_header_main_default.set_text_color(lv.color_hex(0x393c41))
style_Modifymember_win_delete_extra_header_main_default.set_text_font(test_font("montserratMedium", 12))
style_Modifymember_win_delete_extra_header_main_default.set_text_letter_space(0)
style_Modifymember_win_delete_extra_header_main_default.set_text_line_space(2)
Modifymember_win_delete.get_header().add_style(style_Modifymember_win_delete_extra_header_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)
# Set style for Modifymember_win_delete, Part: lv.PART.MAIN, State: lv.STATE.DEFAULT.
style_Modifymember_win_delete_extra_btns_main_default = lv.style_t()
style_Modifymember_win_delete_extra_btns_main_default.init()
style_Modifymember_win_delete_extra_btns_main_default.set_radius(8)
style_Modifymember_win_delete_extra_btns_main_default.set_bg_opa(255)
style_Modifymember_win_delete_extra_btns_main_default.set_bg_color(lv.color_hex(0xC2D9FF))
style_Modifymember_win_delete_extra_btns_main_default.set_shadow_width(0)
Modifymember_win_delete_item0.add_style(style_Modifymember_win_delete_extra_btns_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

Modifymember.update_layout()

def Home_img_setting_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_settings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Home_img_setting.add_event_cb(lambda e: Home_img_setting_event_handler(e), lv.EVENT.ALL, None)

def Home_contSetup_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_Remind, lv.SCR_LOAD_ANIM.FADE_ON, 100, 200, False)

Home_contSetup.add_event_cb(lambda e: Home_contSetup_event_handler(e), lv.EVENT.ALL, None)

def Home_BUT_History_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_History, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)
        #Write animation: Home_upimage scale_width
        Home_upimage_anim_scale_width = lv.anim_t()
        Home_upimage_anim_scale_width.init()
        Home_upimage_anim_scale_width.set_var(Home_upimage)
        Home_upimage_anim_scale_width.set_time(200)
        Home_upimage_anim_scale_width.set_delay(0)
        Home_upimage_anim_scale_width.set_custom_exec_cb(lambda e,val: anim_width_cb(Home_upimage,val))
        Home_upimage_anim_scale_width.set_values(Home_upimage.get_width(), 480)
        Home_upimage_anim_scale_width.set_path_cb(lv.anim_t.path_ease_in)
        Home_upimage_anim_scale_width.set_repeat_count(0)
        Home_upimage_anim_scale_width.set_repeat_delay(0)
        Home_upimage_anim_scale_width.set_playback_time(0)
        Home_upimage_anim_scale_width.set_playback_delay(0)
        Home_upimage_anim_scale_width.start()
        #Write animation: Home_upimage scale_height
        Home_upimage_anim_scale_height = lv.anim_t()
        Home_upimage_anim_scale_height.init()
        Home_upimage_anim_scale_height.set_var(Home_upimage)
        Home_upimage_anim_scale_height.set_time(200)
        Home_upimage_anim_scale_height.set_delay(0)
        Home_upimage_anim_scale_height.set_custom_exec_cb(lambda e,val: anim_height_cb(Home_upimage,val))
        Home_upimage_anim_scale_height.set_values(Home_upimage.get_height(), 60)
        Home_upimage_anim_scale_height.set_path_cb(lv.anim_t.path_ease_in)
        Home_upimage_anim_scale_height.set_repeat_count(0)
        Home_upimage_anim_scale_height.set_repeat_delay(0)
        Home_upimage_anim_scale_height.set_playback_time(0)
        Home_upimage_anim_scale_height.set_playback_delay(0)
        Home_upimage_anim_scale_height.start()

Home_BUT_History.add_event_cb(lambda e: Home_BUT_History_event_handler(e), lv.EVENT.ALL, None)

def Home_BUT_Reserve_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        #Write animation: Home_upimage scale_width
        Home_upimage_anim_scale_width = lv.anim_t()
        Home_upimage_anim_scale_width.init()
        Home_upimage_anim_scale_width.set_var(Home_upimage)
        Home_upimage_anim_scale_width.set_time(200)
        Home_upimage_anim_scale_width.set_delay(0)
        Home_upimage_anim_scale_width.set_custom_exec_cb(lambda e,val: anim_width_cb(Home_upimage,val))
        Home_upimage_anim_scale_width.set_values(Home_upimage.get_width(), 480)
        Home_upimage_anim_scale_width.set_path_cb(lv.anim_t.path_ease_out)
        Home_upimage_anim_scale_width.set_repeat_count(0)
        Home_upimage_anim_scale_width.set_repeat_delay(0)
        Home_upimage_anim_scale_width.set_playback_time(0)
        Home_upimage_anim_scale_width.set_playback_delay(0)
        Home_upimage_anim_scale_width.start()
        #Write animation: Home_upimage scale_height
        Home_upimage_anim_scale_height = lv.anim_t()
        Home_upimage_anim_scale_height.init()
        Home_upimage_anim_scale_height.set_var(Home_upimage)
        Home_upimage_anim_scale_height.set_time(200)
        Home_upimage_anim_scale_height.set_delay(0)
        Home_upimage_anim_scale_height.set_custom_exec_cb(lambda e,val: anim_height_cb(Home_upimage,val))
        Home_upimage_anim_scale_height.set_values(Home_upimage.get_height(), 60)
        Home_upimage_anim_scale_height.set_path_cb(lv.anim_t.path_ease_out)
        Home_upimage_anim_scale_height.set_repeat_count(0)
        Home_upimage_anim_scale_height.set_repeat_delay(0)
        Home_upimage_anim_scale_height.set_playback_time(0)
        Home_upimage_anim_scale_height.set_playback_delay(0)
        Home_upimage_anim_scale_height.start()
        lv.scr_load_anim(Page_Reserve, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Home_BUT_Reserve.add_event_cb(lambda e: Home_BUT_Reserve_event_handler(e), lv.EVENT.ALL, None)

def Home_BUT_search_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_Search, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)
        #Write animation: Home_upimage scale_width
        Home_upimage_anim_scale_width = lv.anim_t()
        Home_upimage_anim_scale_width.init()
        Home_upimage_anim_scale_width.set_var(Home_upimage)
        Home_upimage_anim_scale_width.set_time(200)
        Home_upimage_anim_scale_width.set_delay(0)
        Home_upimage_anim_scale_width.set_custom_exec_cb(lambda e,val: anim_width_cb(Home_upimage,val))
        Home_upimage_anim_scale_width.set_values(Home_upimage.get_width(), 480)
        Home_upimage_anim_scale_width.set_path_cb(lv.anim_t.path_ease_in)
        Home_upimage_anim_scale_width.set_repeat_count(0)
        Home_upimage_anim_scale_width.set_repeat_delay(0)
        Home_upimage_anim_scale_width.set_playback_time(0)
        Home_upimage_anim_scale_width.set_playback_delay(0)
        Home_upimage_anim_scale_width.start()
        #Write animation: Home_upimage scale_height
        Home_upimage_anim_scale_height = lv.anim_t()
        Home_upimage_anim_scale_height.init()
        Home_upimage_anim_scale_height.set_var(Home_upimage)
        Home_upimage_anim_scale_height.set_time(200)
        Home_upimage_anim_scale_height.set_delay(0)
        Home_upimage_anim_scale_height.set_custom_exec_cb(lambda e,val: anim_height_cb(Home_upimage,val))
        Home_upimage_anim_scale_height.set_values(Home_upimage.get_height(), 60)
        Home_upimage_anim_scale_height.set_path_cb(lv.anim_t.path_ease_in)
        Home_upimage_anim_scale_height.set_repeat_count(0)
        Home_upimage_anim_scale_height.set_repeat_delay(0)
        Home_upimage_anim_scale_height.set_playback_time(0)
        Home_upimage_anim_scale_height.set_playback_delay(0)
        Home_upimage_anim_scale_height.start()

Home_BUT_search.add_event_cb(lambda e: Home_BUT_search_event_handler(e), lv.EVENT.ALL, None)

def Home_BUT_wifi_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Home_win_wifi.clear_flag(lv.obj.FLAG.HIDDEN)

Home_BUT_wifi.add_event_cb(lambda e: Home_BUT_wifi_event_handler(e), lv.EVENT.ALL, None)

def Home_BUT_contact_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Home_win_contact.clear_flag(lv.obj.FLAG.HIDDEN)

Home_BUT_contact.add_event_cb(lambda e: Home_BUT_contact_event_handler(e), lv.EVENT.ALL, None)

def Home_BUT_QR_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Home_QRcode.clear_flag(lv.obj.FLAG.HIDDEN);Home_win_QR.clear_flag(lv.obj.FLAG.HIDDEN)

Home_BUT_QR.add_event_cb(lambda e: Home_BUT_QR_event_handler(e), lv.EVENT.ALL, None)

def Home_BUT_video_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Video, lv.SCR_LOAD_ANIM.MOVE_BOTTOM, 200, 200, False)

Home_BUT_video.add_event_cb(lambda e: Home_BUT_video_event_handler(e), lv.EVENT.ALL, None)

def Home_win_wifi_event_handler(e):
    code = e.get_code()
def Home_win_wifi_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Home_win_wifi.add_flag(lv.obj.FLAG.HIDDEN)

Home_win_wifi_item0.add_event_cb(lambda e: Home_win_wifi_item0_event_handler(e), lv.EVENT.ALL, None)

Home_win_wifi.add_event_cb(lambda e: Home_win_wifi_event_handler(e), lv.EVENT.ALL, None)

def Home_win_contact_event_handler(e):
    code = e.get_code()
def Home_win_contact_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Home_win_contact.add_flag(lv.obj.FLAG.HIDDEN)

Home_win_contact_item0.add_event_cb(lambda e: Home_win_contact_item0_event_handler(e), lv.EVENT.ALL, None)

Home_win_contact.add_event_cb(lambda e: Home_win_contact_event_handler(e), lv.EVENT.ALL, None)

def Home_win_QR_event_handler(e):
    code = e.get_code()
def Home_win_QR_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Home_win_QR.add_flag(lv.obj.FLAG.HIDDEN);Home_QRcode.add_flag(lv.obj.FLAG.HIDDEN)

Home_win_QR_item0.add_event_cb(lambda e: Home_win_QR_item0_event_handler(e), lv.EVENT.ALL, None)

Home_win_QR.add_event_cb(lambda e: Home_win_QR_event_handler(e), lv.EVENT.ALL, None)

def Video_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Video_BUT_back.add_event_cb(lambda e: Video_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Page_Reserve_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)
        #Write animation: Page_Reserve_contBG scale_width
        Page_Reserve_contBG_anim_scale_width = lv.anim_t()
        Page_Reserve_contBG_anim_scale_width.init()
        Page_Reserve_contBG_anim_scale_width.set_var(Page_Reserve_contBG)
        Page_Reserve_contBG_anim_scale_width.set_time(100)
        Page_Reserve_contBG_anim_scale_width.set_delay(0)
        Page_Reserve_contBG_anim_scale_width.set_custom_exec_cb(lambda e,val: anim_width_cb(Page_Reserve_contBG,val))
        Page_Reserve_contBG_anim_scale_width.set_values(Page_Reserve_contBG.get_width(), 480)
        Page_Reserve_contBG_anim_scale_width.set_path_cb(lv.anim_t.path_ease_in)
        Page_Reserve_contBG_anim_scale_width.set_repeat_count(0)
        Page_Reserve_contBG_anim_scale_width.set_repeat_delay(0)
        Page_Reserve_contBG_anim_scale_width.set_playback_time(0)
        Page_Reserve_contBG_anim_scale_width.set_playback_delay(0)
        Page_Reserve_contBG_anim_scale_width.start()
        #Write animation: Page_Reserve_contBG scale_height
        Page_Reserve_contBG_anim_scale_height = lv.anim_t()
        Page_Reserve_contBG_anim_scale_height.init()
        Page_Reserve_contBG_anim_scale_height.set_var(Page_Reserve_contBG)
        Page_Reserve_contBG_anim_scale_height.set_time(100)
        Page_Reserve_contBG_anim_scale_height.set_delay(0)
        Page_Reserve_contBG_anim_scale_height.set_custom_exec_cb(lambda e,val: anim_height_cb(Page_Reserve_contBG,val))
        Page_Reserve_contBG_anim_scale_height.set_values(Page_Reserve_contBG.get_height(), 60)
        Page_Reserve_contBG_anim_scale_height.set_path_cb(lv.anim_t.path_ease_in)
        Page_Reserve_contBG_anim_scale_height.set_repeat_count(0)
        Page_Reserve_contBG_anim_scale_height.set_repeat_delay(0)
        Page_Reserve_contBG_anim_scale_height.set_playback_time(0)
        Page_Reserve_contBG_anim_scale_height.set_playback_delay(0)
        Page_Reserve_contBG_anim_scale_height.start()

Page_Reserve_BUT_back.add_event_cb(lambda e: Page_Reserve_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Page_Reserve_BUT_store_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Reserve_Storeby, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_Reserve_BUT_store.add_event_cb(lambda e: Page_Reserve_BUT_store_event_handler(e), lv.EVENT.ALL, None)

def Page_Reserve_BUT_take_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Reserve_Take, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_Reserve_BUT_take.add_event_cb(lambda e: Page_Reserve_BUT_take_event_handler(e), lv.EVENT.ALL, None)

def Page_Reserve_BUT_storage_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Reserve_Storage, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_Reserve_BUT_storage.add_event_cb(lambda e: Page_Reserve_BUT_storage_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Storeby_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_Reserve, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Storeby_BUT_back.add_event_cb(lambda e: Reserve_Storeby_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Storeby_BUT_Camera_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Reverse_Camera, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Storeby_BUT_Camera.add_event_cb(lambda e: Reserve_Storeby_BUT_Camera_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Storeby_BUT_Manual_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Reserve_Manual, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Storeby_BUT_Manual.add_event_cb(lambda e: Reserve_Storeby_BUT_Manual_event_handler(e), lv.EVENT.ALL, None)

def Reverse_Camera_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Reserve_Storeby, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reverse_Camera_BUT_back.add_event_cb(lambda e: Reverse_Camera_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Reverse_Camera_BUT_add_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Reverse_Camera_win_success.clear_flag(lv.obj.FLAG.HIDDEN)

Reverse_Camera_BUT_add.add_event_cb(lambda e: Reverse_Camera_BUT_add_event_handler(e), lv.EVENT.ALL, None)

def Reverse_Camera_BUT_home_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reverse_Camera_BUT_home.add_event_cb(lambda e: Reverse_Camera_BUT_home_event_handler(e), lv.EVENT.ALL, None)

def Reverse_Camera_win_success_event_handler(e):
    code = e.get_code()
def Reverse_Camera_win_success_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Reverse_Camera_win_success.add_flag(lv.obj.FLAG.HIDDEN)

Reverse_Camera_win_success_item0.add_event_cb(lambda e: Reverse_Camera_win_success_item0_event_handler(e), lv.EVENT.ALL, None)

Reverse_Camera_win_success.add_event_cb(lambda e: Reverse_Camera_win_success_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Manual_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Reserve_Storeby, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)
        #Write animation: Reserve_Manual_contBG scale_width
        Reserve_Manual_contBG_anim_scale_width = lv.anim_t()
        Reserve_Manual_contBG_anim_scale_width.init()
        Reserve_Manual_contBG_anim_scale_width.set_var(Reserve_Manual_contBG)
        Reserve_Manual_contBG_anim_scale_width.set_time(100)
        Reserve_Manual_contBG_anim_scale_width.set_delay(0)
        Reserve_Manual_contBG_anim_scale_width.set_custom_exec_cb(lambda e,val: anim_width_cb(Reserve_Manual_contBG,val))
        Reserve_Manual_contBG_anim_scale_width.set_values(Reserve_Manual_contBG.get_width(), 480)
        Reserve_Manual_contBG_anim_scale_width.set_path_cb(lv.anim_t.path_ease_in)
        Reserve_Manual_contBG_anim_scale_width.set_repeat_count(0)
        Reserve_Manual_contBG_anim_scale_width.set_repeat_delay(0)
        Reserve_Manual_contBG_anim_scale_width.set_playback_time(0)
        Reserve_Manual_contBG_anim_scale_width.set_playback_delay(0)
        Reserve_Manual_contBG_anim_scale_width.start()
        #Write animation: Reserve_Manual_contBG scale_height
        Reserve_Manual_contBG_anim_scale_height = lv.anim_t()
        Reserve_Manual_contBG_anim_scale_height.init()
        Reserve_Manual_contBG_anim_scale_height.set_var(Reserve_Manual_contBG)
        Reserve_Manual_contBG_anim_scale_height.set_time(100)
        Reserve_Manual_contBG_anim_scale_height.set_delay(0)
        Reserve_Manual_contBG_anim_scale_height.set_custom_exec_cb(lambda e,val: anim_height_cb(Reserve_Manual_contBG,val))
        Reserve_Manual_contBG_anim_scale_height.set_values(Reserve_Manual_contBG.get_height(), 60)
        Reserve_Manual_contBG_anim_scale_height.set_path_cb(lv.anim_t.path_ease_in)
        Reserve_Manual_contBG_anim_scale_height.set_repeat_count(0)
        Reserve_Manual_contBG_anim_scale_height.set_repeat_delay(0)
        Reserve_Manual_contBG_anim_scale_height.set_playback_time(0)
        Reserve_Manual_contBG_anim_scale_height.set_playback_delay(0)
        Reserve_Manual_contBG_anim_scale_height.start()

Reserve_Manual_BUT_back.add_event_cb(lambda e: Reserve_Manual_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Manual_BUT_home_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Manual_BUT_home.add_event_cb(lambda e: Reserve_Manual_BUT_home_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Manual_BUT_store_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Reserve_Manual_win_success.clear_flag(lv.obj.FLAG.HIDDEN)

Reserve_Manual_BUT_store.add_event_cb(lambda e: Reserve_Manual_BUT_store_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Manual_win_success_event_handler(e):
    code = e.get_code()
def Reserve_Manual_win_success_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Reserve_Manual_win_success.add_flag(lv.obj.FLAG.HIDDEN)

Reserve_Manual_win_success_item0.add_event_cb(lambda e: Reserve_Manual_win_success_item0_event_handler(e), lv.EVENT.ALL, None)

Reserve_Manual_win_success.add_event_cb(lambda e: Reserve_Manual_win_success_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Take_btn_2_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_Reserve, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Take_btn_2.add_event_cb(lambda e: Reserve_Take_btn_2_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Take_BUT_home_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Take_BUT_home.add_event_cb(lambda e: Reserve_Take_BUT_home_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Take_BUT_take_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Reserve_Take_win_success.clear_flag(lv.obj.FLAG.HIDDEN)

Reserve_Take_BUT_take.add_event_cb(lambda e: Reserve_Take_BUT_take_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Take_win_success_event_handler(e):
    code = e.get_code()
def Reserve_Take_win_success_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Reserve_Take_win_success.add_flag(lv.obj.FLAG.HIDDEN)

Reserve_Take_win_success_item0.add_event_cb(lambda e: Reserve_Take_win_success_item0_event_handler(e), lv.EVENT.ALL, None)

Reserve_Take_win_success.add_event_cb(lambda e: Reserve_Take_win_success_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Take_win_error_event_handler(e):
    code = e.get_code()
def Reserve_Take_win_error_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Reserve_Take_win_error.add_flag(lv.obj.FLAG.HIDDEN)

Reserve_Take_win_error_item0.add_event_cb(lambda e: Reserve_Take_win_error_item0_event_handler(e), lv.EVENT.ALL, None)

Reserve_Take_win_error.add_event_cb(lambda e: Reserve_Take_win_error_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Storage_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_Reserve, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Storage_BUT_back.add_event_cb(lambda e: Reserve_Storage_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Reserve_Storage_BUT_home_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Reserve_Storage_BUT_home.add_event_cb(lambda e: Reserve_Storage_BUT_home_event_handler(e), lv.EVENT.ALL, None)

def Page_Search_BUT_Next_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Search_reccomend, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_Search_BUT_Next.add_event_cb(lambda e: Page_Search_BUT_Next_event_handler(e), lv.EVENT.ALL, None)

def Page_Search_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 400, 200, False)

Page_Search_BUT_back.add_event_cb(lambda e: Page_Search_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Search_reccomend_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)
        #Write animation: Search_reccomend_contBG scale_width
        Search_reccomend_contBG_anim_scale_width = lv.anim_t()
        Search_reccomend_contBG_anim_scale_width.init()
        Search_reccomend_contBG_anim_scale_width.set_var(Search_reccomend_contBG)
        Search_reccomend_contBG_anim_scale_width.set_time(100)
        Search_reccomend_contBG_anim_scale_width.set_delay(0)
        Search_reccomend_contBG_anim_scale_width.set_custom_exec_cb(lambda e,val: anim_width_cb(Search_reccomend_contBG,val))
        Search_reccomend_contBG_anim_scale_width.set_values(Search_reccomend_contBG.get_width(), 480)
        Search_reccomend_contBG_anim_scale_width.set_path_cb(lv.anim_t.path_ease_in)
        Search_reccomend_contBG_anim_scale_width.set_repeat_count(0)
        Search_reccomend_contBG_anim_scale_width.set_repeat_delay(0)
        Search_reccomend_contBG_anim_scale_width.set_playback_time(0)
        Search_reccomend_contBG_anim_scale_width.set_playback_delay(0)
        Search_reccomend_contBG_anim_scale_width.start()
        #Write animation: Search_reccomend_contBG scale_height
        Search_reccomend_contBG_anim_scale_height = lv.anim_t()
        Search_reccomend_contBG_anim_scale_height.init()
        Search_reccomend_contBG_anim_scale_height.set_var(Search_reccomend_contBG)
        Search_reccomend_contBG_anim_scale_height.set_time(100)
        Search_reccomend_contBG_anim_scale_height.set_delay(0)
        Search_reccomend_contBG_anim_scale_height.set_custom_exec_cb(lambda e,val: anim_height_cb(Search_reccomend_contBG,val))
        Search_reccomend_contBG_anim_scale_height.set_values(Search_reccomend_contBG.get_height(), 60)
        Search_reccomend_contBG_anim_scale_height.set_path_cb(lv.anim_t.path_ease_in)
        Search_reccomend_contBG_anim_scale_height.set_repeat_count(0)
        Search_reccomend_contBG_anim_scale_height.set_repeat_delay(0)
        Search_reccomend_contBG_anim_scale_height.set_playback_time(0)
        Search_reccomend_contBG_anim_scale_height.set_playback_delay(0)
        Search_reccomend_contBG_anim_scale_height.start()

Search_reccomend_BUT_back.add_event_cb(lambda e: Search_reccomend_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Search_reccomend_BUT_take_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Search_reccomend_window_notice.clear_flag(lv.obj.FLAG.HIDDEN)

Search_reccomend_BUT_take.add_event_cb(lambda e: Search_reccomend_BUT_take_event_handler(e), lv.EVENT.ALL, None)

def Search_reccomend_window_notice_event_handler(e):
    code = e.get_code()
def Search_reccomend_window_notice_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 100, 10, False)
        Search_reccomend_window_notice.add_flag(lv.obj.FLAG.HIDDEN)

Search_reccomend_window_notice_item0.add_event_cb(lambda e: Search_reccomend_window_notice_item0_event_handler(e), lv.EVENT.ALL, None)

Search_reccomend_window_notice.add_event_cb(lambda e: Search_reccomend_window_notice_event_handler(e), lv.EVENT.ALL, None)

def Page_History_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_History_BUT_back.add_event_cb(lambda e: Page_History_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Page_History_BUT_take_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_History_BUT_take.add_event_cb(lambda e: Page_History_BUT_take_event_handler(e), lv.EVENT.ALL, None)

def Page_Remind_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_Remind_BUT_back.add_event_cb(lambda e: Page_Remind_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Page_Remind_imgbtn_1_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Page_Remind_win_importsuccess.clear_flag(lv.obj.FLAG.HIDDEN)

Page_Remind_imgbtn_1.add_event_cb(lambda e: Page_Remind_imgbtn_1_event_handler(e), lv.EVENT.ALL, None)

def Page_Remind_BUT_home_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_Remind_BUT_home.add_event_cb(lambda e: Page_Remind_BUT_home_event_handler(e), lv.EVENT.ALL, None)

def Page_Remind_BUT_Delete_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Remind_delete, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_Remind_BUT_Delete.add_event_cb(lambda e: Page_Remind_BUT_Delete_event_handler(e), lv.EVENT.ALL, None)

def Page_Remind_BUT_Add_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Page_Remind_win_success.clear_flag(lv.obj.FLAG.HIDDEN)

Page_Remind_BUT_Add.add_event_cb(lambda e: Page_Remind_BUT_Add_event_handler(e), lv.EVENT.ALL, None)

def Page_Remind_win_success_event_handler(e):
    code = e.get_code()
def Page_Remind_win_success_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Page_Remind_win_success.add_flag(lv.obj.FLAG.HIDDEN)

Page_Remind_win_success_item0.add_event_cb(lambda e: Page_Remind_win_success_item0_event_handler(e), lv.EVENT.ALL, None)

Page_Remind_win_success.add_event_cb(lambda e: Page_Remind_win_success_event_handler(e), lv.EVENT.ALL, None)

def Page_Remind_win_importsuccess_event_handler(e):
    code = e.get_code()
def Page_Remind_win_importsuccess_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Page_Remind_win_importsuccess.add_flag(lv.obj.FLAG.HIDDEN)

Page_Remind_win_importsuccess_item0.add_event_cb(lambda e: Page_Remind_win_importsuccess_item0_event_handler(e), lv.EVENT.ALL, None)

Page_Remind_win_importsuccess.add_event_cb(lambda e: Page_Remind_win_importsuccess_event_handler(e), lv.EVENT.ALL, None)

def Remind_delete_BUT_back2_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_Remind, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Remind_delete_BUT_back2.add_event_cb(lambda e: Remind_delete_BUT_back2_event_handler(e), lv.EVENT.ALL, None)

def Remind_delete_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_Remind, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Remind_delete_BUT_back.add_event_cb(lambda e: Remind_delete_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Remind_delete_BUT_Delete_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Remind_delete_win_delete.clear_flag(lv.obj.FLAG.HIDDEN)

Remind_delete_BUT_Delete.add_event_cb(lambda e: Remind_delete_BUT_Delete_event_handler(e), lv.EVENT.ALL, None)

def Remind_delete_win_delete_event_handler(e):
    code = e.get_code()
def Remind_delete_win_delete_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Remind_delete_win_delete.add_flag(lv.obj.FLAG.HIDDEN)

Remind_delete_win_delete_item0.add_event_cb(lambda e: Remind_delete_win_delete_item0_event_handler(e), lv.EVENT.ALL, None)

Remind_delete_win_delete.add_event_cb(lambda e: Remind_delete_win_delete_event_handler(e), lv.EVENT.ALL, None)

def Page_settings_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Home, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_settings_BUT_back.add_event_cb(lambda e: Page_settings_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Page_settings_BUT_RC_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(ReminderSettings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_settings_BUT_RC.add_event_cb(lambda e: Page_settings_BUT_RC_event_handler(e), lv.EVENT.ALL, None)

def Page_settings_BUT_FMM_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(MemberManagement, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_settings_BUT_FMM.add_event_cb(lambda e: Page_settings_BUT_FMM_event_handler(e), lv.EVENT.ALL, None)

def Page_settings_BUT_Net_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Networksetting, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Page_settings_BUT_Net.add_event_cb(lambda e: Page_settings_BUT_Net_event_handler(e), lv.EVENT.ALL, None)

def Networksetting_BUT_back2_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_settings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Networksetting_BUT_back2.add_event_cb(lambda e: Networksetting_BUT_back2_event_handler(e), lv.EVENT.ALL, None)

def Networksetting_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_settings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Networksetting_BUT_back.add_event_cb(lambda e: Networksetting_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def ReminderSettings_BUT_back2_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_settings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

ReminderSettings_BUT_back2.add_event_cb(lambda e: ReminderSettings_BUT_back2_event_handler(e), lv.EVENT.ALL, None)

def ReminderSettings_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_settings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

ReminderSettings_BUT_back.add_event_cb(lambda e: ReminderSettings_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def MemberManagement_BUT_back2_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_settings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

MemberManagement_BUT_back2.add_event_cb(lambda e: MemberManagement_BUT_back2_event_handler(e), lv.EVENT.ALL, None)

def MemberManagement_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Page_settings, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

MemberManagement_BUT_back.add_event_cb(lambda e: MemberManagement_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def MemberManagement_BUT_addmember_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(AddMember, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

MemberManagement_BUT_addmember.add_event_cb(lambda e: MemberManagement_BUT_addmember_event_handler(e), lv.EVENT.ALL, None)

def MemberManagement_LIST_userlist_event_handler(e):
    code = e.get_code()
def MemberManagement_LIST_userlist_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Modifymember, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

MemberManagement_LIST_userlist_item0.add_event_cb(lambda e: MemberManagement_LIST_userlist_item0_event_handler(e), lv.EVENT.ALL, None)

def MemberManagement_LIST_userlist_item1_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Modifymember, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

MemberManagement_LIST_userlist_item1.add_event_cb(lambda e: MemberManagement_LIST_userlist_item1_event_handler(e), lv.EVENT.ALL, None)

def MemberManagement_LIST_userlist_item2_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(Modifymember, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

MemberManagement_LIST_userlist_item2.add_event_cb(lambda e: MemberManagement_LIST_userlist_item2_event_handler(e), lv.EVENT.ALL, None)

MemberManagement_LIST_userlist.add_event_cb(lambda e: MemberManagement_LIST_userlist_event_handler(e), lv.EVENT.ALL, None)

def AddMember_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(MemberManagement, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

AddMember_BUT_back.add_event_cb(lambda e: AddMember_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def AddMember_BUT_Add_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        AddMember_win_success.clear_flag(lv.obj.FLAG.HIDDEN)

AddMember_BUT_Add.add_event_cb(lambda e: AddMember_BUT_Add_event_handler(e), lv.EVENT.ALL, None)

def AddMember_win_success_event_handler(e):
    code = e.get_code()
def AddMember_win_success_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        AddMember_win_success.add_flag(lv.obj.FLAG.HIDDEN)

AddMember_win_success_item0.add_event_cb(lambda e: AddMember_win_success_item0_event_handler(e), lv.EVENT.ALL, None)

AddMember_win_success.add_event_cb(lambda e: AddMember_win_success_event_handler(e), lv.EVENT.ALL, None)

def Modifymember_BUT_back_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        lv.scr_load_anim(MemberManagement, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Modifymember_BUT_back.add_event_cb(lambda e: Modifymember_BUT_back_event_handler(e), lv.EVENT.ALL, None)

def Modifymember_BUT_Save_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Modifymember_win_save.clear_flag(lv.obj.FLAG.HIDDEN)

Modifymember_BUT_Save.add_event_cb(lambda e: Modifymember_BUT_Save_event_handler(e), lv.EVENT.ALL, None)

def Modifymember_BUT_deletemember_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Modifymember_win_delete.clear_flag(lv.obj.FLAG.HIDDEN)

Modifymember_BUT_deletemember.add_event_cb(lambda e: Modifymember_BUT_deletemember_event_handler(e), lv.EVENT.ALL, None)

def Modifymember_win_save_event_handler(e):
    code = e.get_code()
def Modifymember_win_save_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Modifymember_win_save.add_flag(lv.obj.FLAG.HIDDEN)

Modifymember_win_save_item0.add_event_cb(lambda e: Modifymember_win_save_item0_event_handler(e), lv.EVENT.ALL, None)

Modifymember_win_save.add_event_cb(lambda e: Modifymember_win_save_event_handler(e), lv.EVENT.ALL, None)

def Modifymember_win_delete_event_handler(e):
    code = e.get_code()
def Modifymember_win_delete_item0_event_handler(e):
    code = e.get_code()
    if (code == lv.EVENT.CLICKED):
        Modifymember_win_delete.add_flag(lv.obj.FLAG.HIDDEN);lv.scr_load_anim(MemberManagement, lv.SCR_LOAD_ANIM.FADE_ON, 200, 200, False)

Modifymember_win_delete_item0.add_event_cb(lambda e: Modifymember_win_delete_item0_event_handler(e), lv.EVENT.ALL, None)

Modifymember_win_delete.add_event_cb(lambda e: Modifymember_win_delete_event_handler(e), lv.EVENT.ALL, None)

# content from custom.py

# Load the default screen
lv.scr_load(Home)

while SDL.check():
    time.sleep_ms(5)

