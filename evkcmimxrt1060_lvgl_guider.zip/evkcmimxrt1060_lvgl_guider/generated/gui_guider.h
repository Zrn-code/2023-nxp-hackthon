/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#ifndef GUI_GUIDER_H
#define GUI_GUIDER_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

typedef struct
{
  
	lv_obj_t *Home;
	bool Home_del;
	lv_obj_t *Home_upimage;
	lv_obj_t *Home_img_setting;
	lv_obj_t *Home_contMain;
	lv_obj_t *Home_contSetup;
	lv_obj_t *Home_img_remind;
	lv_obj_t *Home_text_remind;
	lv_obj_t *Home_BUT_History;
	lv_obj_t *Home_img_history;
	lv_obj_t *Home_text_history;
	lv_obj_t *Home_BUT_Reserve;
	lv_obj_t *Home_img_medicine;
	lv_obj_t *Home_text_reserve;
	lv_obj_t *Home_BUT_search;
	lv_obj_t *Home_img_search;
	lv_obj_t *Home_text_search;
	lv_obj_t *Home_contTop;
	lv_obj_t *Home_text_date;
	lv_obj_t *Home_BUT_wifi;
	lv_obj_t *Home_BUT_contact;
	lv_obj_t *Home_BUT_QR;
	lv_obj_t *Home_BUT_video;
	lv_obj_t *Home_text_recent;
	lv_obj_t *Home_win_wifi;
	lv_obj_t *Home_win_wifi_item0;
	lv_obj_t *Home_win_contact;
	lv_obj_t *Home_win_contact_item0;
	lv_obj_t *Home_win_QR;
	lv_obj_t *Home_win_QR_item0;
	lv_obj_t *Home_QRcode;
	lv_obj_t *Video;
	bool Video_del;
	lv_obj_t *Video_contBG;
	lv_obj_t *Video_text_title;
	lv_obj_t *Video_BUT_back;
	lv_obj_t *Video_BUT_back_label;
	lv_obj_t *Page_Reserve;
	bool Page_Reserve_del;
	lv_obj_t *Page_Reserve_contBG;
	lv_obj_t *Page_Reserve_text_title;
	lv_obj_t *Page_Reserve_BUT_back;
	lv_obj_t *Page_Reserve_BUT_back_label;
	lv_obj_t *Page_Reserve_BUT_store;
	lv_obj_t *Page_Reserve_BUT_store_label;
	lv_obj_t *Page_Reserve_text_store;
	lv_obj_t *Page_Reserve_BUT_take;
	lv_obj_t *Page_Reserve_BUT_take_label;
	lv_obj_t *Page_Reserve_text_take;
	lv_obj_t *Page_Reserve_BUT_storage;
	lv_obj_t *Page_Reserve_BUT_storage_label;
	lv_obj_t *Page_Reserve_text_storage;
	lv_obj_t *Reserve_Storeby;
	bool Reserve_Storeby_del;
	lv_obj_t *Reserve_Storeby_contBG;
	lv_obj_t *Reserve_Storeby_text_title;
	lv_obj_t *Reserve_Storeby_BUT_back;
	lv_obj_t *Reserve_Storeby_BUT_back_label;
	lv_obj_t *Reserve_Storeby_BUT_Camera;
	lv_obj_t *Reserve_Storeby_BUT_Camera_label;
	lv_obj_t *Reserve_Storeby_text_camera;
	lv_obj_t *Reserve_Storeby_BUT_Manual;
	lv_obj_t *Reserve_Storeby_BUT_Manual_label;
	lv_obj_t *Reserve_Storeby_text_take;
	lv_obj_t *Reverse_Camera;
	bool Reverse_Camera_del;
	lv_obj_t *Reverse_Camera_contBG;
	lv_obj_t *Reverse_Camera_text_title;
	lv_obj_t *Reverse_Camera_text_put;
	lv_obj_t *Reverse_Camera_text_user;
	lv_obj_t *Reverse_Camera_text_num;
	lv_obj_t *Reverse_Camera_text_med;
	lv_obj_t *Reverse_Camera_BUT_back;
	lv_obj_t *Reverse_Camera_BUT_back_label;
	lv_obj_t *Reverse_Camera_BUT_add;
	lv_obj_t *Reverse_Camera_BUT_add_label;
	lv_obj_t *Reverse_Camera_BUT_rescan;
	lv_obj_t *Reverse_Camera_BUT_rescan_label;
	lv_obj_t *Reverse_Camera_BUT_home;
	lv_obj_t *Reverse_Camera_BUT_home_label;
	lv_obj_t *Reverse_Camera_SCAN_med;
	lv_obj_t *Reverse_Camera_SCAN_num;
	lv_obj_t *Reverse_Camera_INPUT_User;
	lv_obj_t *Reverse_Camera_win_success;
	lv_obj_t *Reverse_Camera_win_success_item0;
	lv_obj_t *Reserve_Manual;
	bool Reserve_Manual_del;
	lv_obj_t *g_kb_Reserve_Manual;
	lv_obj_t *Reserve_Manual_contBG;
	lv_obj_t *Reserve_Manual_BUT_back;
	lv_obj_t *Reserve_Manual_BUT_back_label;
	lv_obj_t *Reserve_Manual_text_title;
	lv_obj_t *Reserve_Manual_text_user;
	lv_obj_t *Reserve_Manual_text_medicine;
	lv_obj_t *Reserve_Manual_text_num;
	lv_obj_t *Reserve_Manual_BUT_home;
	lv_obj_t *Reserve_Manual_BUT_home_label;
	lv_obj_t *Reserve_Manual_BUT_store;
	lv_obj_t *Reserve_Manual_BUT_store_label;
	lv_obj_t *Reserve_Manual_INPUT_User;
	lv_obj_t *Reserve_Manual_INPUT_num;
	lv_obj_t *Reserve_Manual_INPUT_medicine;
	lv_obj_t *Reserve_Manual_win_success;
	lv_obj_t *Reserve_Manual_win_success_item0;
	lv_obj_t *Reserve_Take;
	bool Reserve_Take_del;
	lv_obj_t *Reserve_Take_contBG;
	lv_obj_t *Reserve_Take_btn_2;
	lv_obj_t *Reserve_Take_btn_2_label;
	lv_obj_t *Reserve_Take_BUT_back;
	lv_obj_t *Reserve_Take_text_User;
	lv_obj_t *Reserve_Take_text_medicine;
	lv_obj_t *Reserve_Take_text_number;
	lv_obj_t *Reserve_Take_BUT_home;
	lv_obj_t *Reserve_Take_BUT_home_label;
	lv_obj_t *Reserve_Take_BUT_take;
	lv_obj_t *Reserve_Take_BUT_take_label;
	lv_obj_t *Reserve_Take_INPUT_User;
	lv_obj_t *Reserve_Take_INPUT_numbers;
	lv_obj_t *Reserve_Take_INPUT_medlist;
	lv_obj_t *Reserve_Take_win_success;
	lv_obj_t *Reserve_Take_win_success_item0;
	lv_obj_t *Reserve_Take_win_error;
	lv_obj_t *Reserve_Take_win_error_item0;
	lv_obj_t *Reserve_Storage;
	bool Reserve_Storage_del;
	lv_obj_t *Reserve_Storage_contBG;
	lv_obj_t *Reserve_Storage_BUT_back;
	lv_obj_t *Reserve_Storage_BUT_back_label;
	lv_obj_t *Reserve_Storage_text_title;
	lv_obj_t *Reserve_Storage_BUT_home;
	lv_obj_t *Reserve_Storage_BUT_home_label;
	lv_obj_t *Reserve_Storage_LIST_storagelist;
	lv_obj_t *Page_Search;
	bool Page_Search_del;
	lv_obj_t *Page_Search_contBG;
	lv_obj_t *Page_Search_text_title;
	lv_obj_t *Page_Search_text_syptoms;
	lv_obj_t *Page_Search_cb_runningnose;
	lv_obj_t *Page_Search_cb_headache;
	lv_obj_t *Page_Search_cb_sorethroat;
	lv_obj_t *Page_Search_cb_muscleaches;
	lv_obj_t *Page_Search_cb_cough;
	lv_obj_t *Page_Search_cb_fever;
	lv_obj_t *Page_Search_cb_losstaste;
	lv_obj_t *Page_Search_cb_diarrhea;
	lv_obj_t *Page_Search_cb_stomachache;
	lv_obj_t *Page_Search_cb_drowsiness;
	lv_obj_t *Page_Search_cb_chestpain;
	lv_obj_t *Page_Search_cb_Nausea;
	lv_obj_t *Page_Search_BUT_Next;
	lv_obj_t *Page_Search_BUT_Next_label;
	lv_obj_t *Page_Search_BUT_back;
	lv_obj_t *Page_Search_BUT_back_label;
	lv_obj_t *Search_reccomend;
	bool Search_reccomend_del;
	lv_obj_t *g_kb_Search_reccomend;
	lv_obj_t *Search_reccomend_contBG;
	lv_obj_t *Search_reccomend_text_title;
	lv_obj_t *Search_reccomend_BUT_back;
	lv_obj_t *Search_reccomend_BUT_back_label;
	lv_obj_t *Search_reccomend_BUT_take;
	lv_obj_t *Search_reccomend_BUT_take_label;
	lv_obj_t *Search_reccomend_text_suggested;
	lv_obj_t *Search_reccomend_text_Take;
	lv_obj_t *Search_reccomend_text_number;
	lv_obj_t *Search_reccomend_INPUT_numbers;
	lv_obj_t *Search_reccomend_INPUT_sugmedlist;
	lv_obj_t *Search_reccomend_LIST_suggestedlist;
	lv_obj_t *Search_reccomend_window_notice;
	lv_obj_t *Search_reccomend_window_notice_item0;
	lv_obj_t *Page_History;
	bool Page_History_del;
	lv_obj_t *Page_History_contBG;
	lv_obj_t *Page_History_text_title;
	lv_obj_t *Page_History_BUT_back;
	lv_obj_t *Page_History_BUT_back_label;
	lv_obj_t *Page_History_BUT_take;
	lv_obj_t *Page_History_BUT_take_label;
	lv_obj_t *Page_History_text_Take;
	lv_obj_t *Page_History_INPUT_sugmedlist;
	lv_obj_t *Page_History_LIST_suggestedlist;
	lv_obj_t *Page_Remind;
	bool Page_Remind_del;
	lv_obj_t *g_kb_Page_Remind;
	lv_obj_t *Page_Remind_contBG;
	lv_obj_t *Page_Remind_BUT_back;
	lv_obj_t *Page_Remind_BUT_back_label;
	lv_obj_t *Page_Remind_text_title;
	lv_obj_t *Page_Remind_imgbtn_1;
	lv_obj_t *Page_Remind_imgbtn_1_label;
	lv_obj_t *Page_Remind_text_addreminder;
	lv_obj_t *Page_Remind_text_Dose;
	lv_obj_t *Page_Remind_text_sym;
	lv_obj_t *Page_Remind_BUT_home;
	lv_obj_t *Page_Remind_BUT_home_label;
	lv_obj_t *Page_Remind_BUT_Delete;
	lv_obj_t *Page_Remind_BUT_Delete_label;
	lv_obj_t *Page_Remind_BUT_Add;
	lv_obj_t *Page_Remind_BUT_Add_label;
	lv_obj_t *Page_Remind_INPUT_medlist;
	lv_obj_t *Page_Remind_INPUT_dose;
	lv_obj_t *Page_Remind_INPUT_min;
	lv_obj_t *Page_Remind_INPUT_hour;
	lv_obj_t *Page_Remind_INPUT_User;
	lv_obj_t *Page_Remind_LIST_remindlist;
	lv_obj_t *Page_Remind_win_success;
	lv_obj_t *Page_Remind_win_success_item0;
	lv_obj_t *Page_Remind_win_importsuccess;
	lv_obj_t *Page_Remind_win_importsuccess_item0;
	lv_obj_t *Remind_delete;
	bool Remind_delete_del;
	lv_obj_t *Remind_delete_contBG;
	lv_obj_t *Remind_delete_BUT_back2;
	lv_obj_t *Remind_delete_BUT_back2_label;
	lv_obj_t *Remind_delete_label_1;
	lv_obj_t *Remind_delete_ddlist_1;
	lv_obj_t *Remind_delete_BUT_back;
	lv_obj_t *Remind_delete_BUT_back_label;
	lv_obj_t *Remind_delete_BUT_Delete;
	lv_obj_t *Remind_delete_BUT_Delete_label;
	lv_obj_t *Remind_delete_win_delete;
	lv_obj_t *Remind_delete_win_delete_item0;
	lv_obj_t *Page_settings;
	bool Page_settings_del;
	lv_obj_t *Page_settings_contBG;
	lv_obj_t *Page_settings_BUT_back;
	lv_obj_t *Page_settings_BUT_back_label;
	lv_obj_t *Page_settings_text_title;
	lv_obj_t *Page_settings_BUT_RC;
	lv_obj_t *Page_settings_BUT_RC_label;
	lv_obj_t *Page_settings_BUT_FMM;
	lv_obj_t *Page_settings_BUT_FMM_label;
	lv_obj_t *Page_settings_BUT_Net;
	lv_obj_t *Page_settings_BUT_Net_label;
	lv_obj_t *Page_settings_text_fmm;
	lv_obj_t *Page_settings_text_reminder;
	lv_obj_t *Page_settings_text_net;
	lv_obj_t *Networksetting;
	bool Networksetting_del;
	lv_obj_t *g_kb_Networksetting;
	lv_obj_t *Networksetting_contBG;
	lv_obj_t *Networksetting_BUT_back2;
	lv_obj_t *Networksetting_BUT_back2_label;
	lv_obj_t *Networksetting_text_title;
	lv_obj_t *Networksetting_BUT_back;
	lv_obj_t *Networksetting_BUT_back_label;
	lv_obj_t *Networksetting_text_ps;
	lv_obj_t *Networksetting_text_ssid;
	lv_obj_t *Networksetting_text_cps;
	lv_obj_t *Networksetting_INPUT_cps;
	lv_obj_t *Networksetting_INPUT_ps;
	lv_obj_t *Networksetting_INPUT_SSID;
	lv_obj_t *ReminderSettings;
	bool ReminderSettings_del;
	lv_obj_t *ReminderSettings_contBG;
	lv_obj_t *ReminderSettings_BUT_back2;
	lv_obj_t *ReminderSettings_BUT_back2_label;
	lv_obj_t *ReminderSettings_text_title;
	lv_obj_t *ReminderSettings_BUT_back;
	lv_obj_t *ReminderSettings_BUT_back_label;
	lv_obj_t *ReminderSettings_text_frequency;
	lv_obj_t *ReminderSettings_text_volume;
	lv_obj_t *ReminderSettings_text_offon;
	lv_obj_t *ReminderSettings_INPUT_Slider_freq;
	lv_obj_t *ReminderSettings_INPUT_Slider_Vol;
	lv_obj_t *ReminderSettings_INPUT_SW_offon;
	lv_obj_t *MemberManagement;
	bool MemberManagement_del;
	lv_obj_t *MemberManagement_contBG;
	lv_obj_t *MemberManagement_BUT_back2;
	lv_obj_t *MemberManagement_BUT_back2_label;
	lv_obj_t *MemberManagement_text_title;
	lv_obj_t *MemberManagement_BUT_back;
	lv_obj_t *MemberManagement_BUT_back_label;
	lv_obj_t *MemberManagement_BUT_addmember;
	lv_obj_t *MemberManagement_BUT_addmember_label;
	lv_obj_t *MemberManagement_LIST_userlist;
	lv_obj_t *AddMember;
	bool AddMember_del;
	lv_obj_t *g_kb_AddMember;
	lv_obj_t *AddMember_contBG;
	lv_obj_t *AddMember_BUT_back;
	lv_obj_t *AddMember_BUT_back_label;
	lv_obj_t *AddMember_text_title;
	lv_obj_t *AddMember_BUT_Add;
	lv_obj_t *AddMember_BUT_Add_label;
	lv_obj_t *AddMember_text_name;
	lv_obj_t *AddMember_text_age;
	lv_obj_t *AddMember_text_gender;
	lv_obj_t *AddMember_INPUT_Gender;
	lv_obj_t *AddMember_INPUT_Age;
	lv_obj_t *AddMember_INPUT_Name;
	lv_obj_t *AddMember_win_success;
	lv_obj_t *AddMember_win_success_item0;
	lv_obj_t *Modifymember;
	bool Modifymember_del;
	lv_obj_t *g_kb_Modifymember;
	lv_obj_t *Modifymember_contBG;
	lv_obj_t *Modifymember_BUT_back;
	lv_obj_t *Modifymember_BUT_back_label;
	lv_obj_t *Modifymember_Modify;
	lv_obj_t *Modifymember_BUT_Save;
	lv_obj_t *Modifymember_BUT_Save_label;
	lv_obj_t *Modifymember_BUT_deletemember;
	lv_obj_t *Modifymember_BUT_deletemember_label;
	lv_obj_t *Modifymember_INPUT_gender;
	lv_obj_t *Modifymember_text_gender;
	lv_obj_t *Modifymember_INPUT_age;
	lv_obj_t *Modifymember_text_age;
	lv_obj_t *Modifymember_label_1;
	lv_obj_t *Modifymember_OUTPUT_User;
	lv_obj_t *Modifymember_win_save;
	lv_obj_t *Modifymember_win_save_item0;
	lv_obj_t *Modifymember_win_delete;
	lv_obj_t *Modifymember_win_delete_item0;
	//-------------------------------------------------------------------------------

				int UserData_name_idx;
				int UserData_medicine_idx;
				char UserData_name[50][30];
				char UserData_medicine[50][50];
				int UserData_dose[50];
				char UserData_age[50][8];
				char UserData_gender[50][8];


				int HistoryData_idx;
				char HistoryData_name[50][50];
				char HistoryData_medicine[50][50];
				int HistoryData_dose[50];

				int ReminderData_idx;
				char ReminderData_name[50][50];
				char ReminderData_hour[50][3];
				char ReminderData_minute[50][3];
				char ReminderData_medicine[50][50];
				int ReminderData_dose[50];

			//---------------------------------------------------------------------------------
}lv_ui;

void ui_init_style(lv_style_t * style);
void init_scr_del_flag(lv_ui *ui);
void setup_ui(lv_ui *ui);
extern lv_ui guider_ui;

void setup_scr_Home(lv_ui *ui);
void setup_scr_Video(lv_ui *ui);
void setup_scr_Page_Reserve(lv_ui *ui);
void setup_scr_Reserve_Storeby(lv_ui *ui);
void setup_scr_Reverse_Camera(lv_ui *ui);
void setup_scr_Reserve_Manual(lv_ui *ui);
void setup_scr_Reserve_Take(lv_ui *ui);
void setup_scr_Reserve_Storage(lv_ui *ui);
void setup_scr_Page_Search(lv_ui *ui);
void setup_scr_Search_reccomend(lv_ui *ui);
void setup_scr_Page_History(lv_ui *ui);
void setup_scr_Page_Remind(lv_ui *ui);
void setup_scr_Remind_delete(lv_ui *ui);
void setup_scr_Page_settings(lv_ui *ui);
void setup_scr_Networksetting(lv_ui *ui);
void setup_scr_ReminderSettings(lv_ui *ui);
void setup_scr_MemberManagement(lv_ui *ui);
void setup_scr_AddMember(lv_ui *ui);
void setup_scr_Modifymember(lv_ui *ui);
LV_IMG_DECLARE(_setup_alpha_35x35);

LV_IMG_DECLARE(_btn_bg_4_100x120);
LV_IMG_DECLARE(_reminder_alpha_37x36);

LV_IMG_DECLARE(_btn_bg_3_100x120);
LV_IMG_DECLARE(_clock_alpha_39x38);

LV_IMG_DECLARE(_btn_bg_1_100x120);
LV_IMG_DECLARE(_pills_alpha_44x40);

LV_IMG_DECLARE(_btn_bg_2_100x120);
LV_IMG_DECLARE(_search_alpha_37x40);
LV_IMG_DECLARE(_wf_alpha_35x35);
LV_IMG_DECLARE(_telephone_alpha_35x35);
LV_IMG_DECLARE(_qr1_alpha_35x35);
LV_IMG_DECLARE(_youtube_alpha_35x35);
LV_IMG_DECLARE(_package_alpha_102x89);
LV_IMG_DECLARE(_takeaway_alpha_105x110);
LV_IMG_DECLARE(_warehouse_alpha_105x90);
LV_IMG_DECLARE(_camera_alpha_102x89);
LV_IMG_DECLARE(_hand_alpha_105x110);
LV_IMG_DECLARE(_LOGIN_alpha_35x35);
LV_IMG_DECLARE(_btn2_alpha_145x173);
LV_IMG_DECLARE(_btn_bg_1_alpha_145x173);
LV_IMG_DECLARE(_btn_bg_3_alpha_145x173);

LV_FONT_DECLARE(lv_font_montserratMedium_18)
LV_FONT_DECLARE(lv_font_montserratMedium_16)
LV_FONT_DECLARE(lv_font_montserratMedium_14)
LV_FONT_DECLARE(lv_font_arial_15)
LV_FONT_DECLARE(lv_font_montserratMedium_12)
LV_FONT_DECLARE(lv_font_montserratMedium_20)
LV_FONT_DECLARE(lv_font_montserratMedium_25)
LV_FONT_DECLARE(lv_font_montserratMedium_15)
LV_FONT_DECLARE(lv_font_montserratMedium_17)
LV_FONT_DECLARE(lv_font_montserratMedium_24)
LV_FONT_DECLARE(lv_font_simsun_18)


#ifdef __cplusplus
}
#endif
#endif
