/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_MemberManagement(lv_ui *ui)
{
	//Write codes MemberManagement
	ui->MemberManagement = lv_obj_create(NULL);
	lv_obj_set_size(ui->MemberManagement, 480, 272);

	//Write style for MemberManagement, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->MemberManagement, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->MemberManagement, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes MemberManagement_contBG
	ui->MemberManagement_contBG = lv_obj_create(ui->MemberManagement);
	lv_obj_set_pos(ui->MemberManagement_contBG, 0, 0);
	lv_obj_set_size(ui->MemberManagement_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->MemberManagement_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for MemberManagement_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->MemberManagement_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->MemberManagement_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->MemberManagement_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->MemberManagement_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->MemberManagement_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->MemberManagement_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->MemberManagement_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->MemberManagement_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->MemberManagement_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes MemberManagement_BUT_back2
	ui->MemberManagement_BUT_back2 = lv_btn_create(ui->MemberManagement_contBG);
	ui->MemberManagement_BUT_back2_label = lv_label_create(ui->MemberManagement_BUT_back2);
	lv_label_set_text(ui->MemberManagement_BUT_back2_label, "<");
	lv_label_set_long_mode(ui->MemberManagement_BUT_back2_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->MemberManagement_BUT_back2_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->MemberManagement_BUT_back2, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->MemberManagement_BUT_back2, 24, 17);
	lv_obj_set_size(ui->MemberManagement_BUT_back2, 35, 32);

	//Write style for MemberManagement_BUT_back2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->MemberManagement_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->MemberManagement_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->MemberManagement_BUT_back2, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->MemberManagement_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->MemberManagement_BUT_back2, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->MemberManagement_BUT_back2, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->MemberManagement_BUT_back2, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes MemberManagement_text_title
	ui->MemberManagement_text_title = lv_label_create(ui->MemberManagement_contBG);
	lv_label_set_text(ui->MemberManagement_text_title, "Management");
	lv_label_set_long_mode(ui->MemberManagement_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->MemberManagement_text_title, 79, 22);
	lv_obj_set_size(ui->MemberManagement_text_title, 323, 32);

	//Write style for MemberManagement_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->MemberManagement_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->MemberManagement_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->MemberManagement_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->MemberManagement_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes MemberManagement_BUT_back
	ui->MemberManagement_BUT_back = lv_btn_create(ui->MemberManagement);
	ui->MemberManagement_BUT_back_label = lv_label_create(ui->MemberManagement_BUT_back);
	lv_label_set_text(ui->MemberManagement_BUT_back_label, "Exit");
	lv_label_set_long_mode(ui->MemberManagement_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->MemberManagement_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->MemberManagement_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->MemberManagement_BUT_back, 366, 224);
	lv_obj_set_size(ui->MemberManagement_BUT_back, 100, 37);

	//Write style for MemberManagement_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->MemberManagement_BUT_back, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->MemberManagement_BUT_back, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->MemberManagement_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->MemberManagement_BUT_back, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->MemberManagement_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->MemberManagement_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->MemberManagement_BUT_back, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->MemberManagement_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes MemberManagement_BUT_addmember
	ui->MemberManagement_BUT_addmember = lv_btn_create(ui->MemberManagement);
	ui->MemberManagement_BUT_addmember_label = lv_label_create(ui->MemberManagement_BUT_addmember);
	lv_label_set_text(ui->MemberManagement_BUT_addmember_label, "Add Member");
	lv_label_set_long_mode(ui->MemberManagement_BUT_addmember_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->MemberManagement_BUT_addmember_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->MemberManagement_BUT_addmember, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->MemberManagement_BUT_addmember, 209, 224);
	lv_obj_set_size(ui->MemberManagement_BUT_addmember, 149, 37);

	//Write style for MemberManagement_BUT_addmember, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->MemberManagement_BUT_addmember, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->MemberManagement_BUT_addmember, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->MemberManagement_BUT_addmember, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->MemberManagement_BUT_addmember, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->MemberManagement_BUT_addmember, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->MemberManagement_BUT_addmember, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->MemberManagement_BUT_addmember, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->MemberManagement_BUT_addmember, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes MemberManagement_LIST_userlist
	ui->MemberManagement_LIST_userlist = lv_list_create(ui->MemberManagement);
	lv_obj_set_pos(ui->MemberManagement_LIST_userlist, 69, 76);
	lv_obj_set_size(ui->MemberManagement_LIST_userlist, 328, 137);
	lv_obj_set_scrollbar_mode(ui->MemberManagement_LIST_userlist, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for &style_MemberManagement_LIST_userlist_main_main_default
	static lv_style_t style_MemberManagement_LIST_userlist_main_main_default;
	ui_init_style(&style_MemberManagement_LIST_userlist_main_main_default);
	
	lv_style_set_pad_top(&style_MemberManagement_LIST_userlist_main_main_default, 5);
	lv_style_set_pad_left(&style_MemberManagement_LIST_userlist_main_main_default, 5);
	lv_style_set_pad_right(&style_MemberManagement_LIST_userlist_main_main_default, 5);
	lv_style_set_pad_bottom(&style_MemberManagement_LIST_userlist_main_main_default, 5);
	lv_style_set_bg_opa(&style_MemberManagement_LIST_userlist_main_main_default, 255);
	lv_style_set_bg_color(&style_MemberManagement_LIST_userlist_main_main_default, lv_color_hex(0xffffff));
	lv_style_set_border_width(&style_MemberManagement_LIST_userlist_main_main_default, 1);
	lv_style_set_border_opa(&style_MemberManagement_LIST_userlist_main_main_default, 255);
	lv_style_set_border_color(&style_MemberManagement_LIST_userlist_main_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_MemberManagement_LIST_userlist_main_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_MemberManagement_LIST_userlist_main_main_default, 3);
	lv_style_set_shadow_width(&style_MemberManagement_LIST_userlist_main_main_default, 0);
	lv_obj_add_style(ui->MemberManagement_LIST_userlist, &style_MemberManagement_LIST_userlist_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_MemberManagement_LIST_userlist_main_scrollbar_default
	static lv_style_t style_MemberManagement_LIST_userlist_main_scrollbar_default;
	ui_init_style(&style_MemberManagement_LIST_userlist_main_scrollbar_default);
	
	lv_style_set_radius(&style_MemberManagement_LIST_userlist_main_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_MemberManagement_LIST_userlist_main_scrollbar_default, 255);
	lv_style_set_bg_color(&style_MemberManagement_LIST_userlist_main_scrollbar_default, lv_color_hex(0xffffff));
	lv_obj_add_style(ui->MemberManagement_LIST_userlist, &style_MemberManagement_LIST_userlist_main_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_MemberManagement_LIST_userlist_extra_btns_main_default
	static lv_style_t style_MemberManagement_LIST_userlist_extra_btns_main_default;
	ui_init_style(&style_MemberManagement_LIST_userlist_extra_btns_main_default);
	
	lv_style_set_pad_top(&style_MemberManagement_LIST_userlist_extra_btns_main_default, 5);
	lv_style_set_pad_left(&style_MemberManagement_LIST_userlist_extra_btns_main_default, 5);
	lv_style_set_pad_right(&style_MemberManagement_LIST_userlist_extra_btns_main_default, 5);
	lv_style_set_pad_bottom(&style_MemberManagement_LIST_userlist_extra_btns_main_default, 5);
	lv_style_set_border_width(&style_MemberManagement_LIST_userlist_extra_btns_main_default, 0);
	lv_style_set_text_color(&style_MemberManagement_LIST_userlist_extra_btns_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_MemberManagement_LIST_userlist_extra_btns_main_default, &lv_font_montserratMedium_17);
	lv_style_set_radius(&style_MemberManagement_LIST_userlist_extra_btns_main_default, 3);
	lv_style_set_bg_opa(&style_MemberManagement_LIST_userlist_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_MemberManagement_LIST_userlist_extra_btns_main_default, lv_color_hex(0xffffff));

	//Write style state: LV_STATE_DEFAULT for &style_MemberManagement_LIST_userlist_extra_texts_main_default
	static lv_style_t style_MemberManagement_LIST_userlist_extra_texts_main_default;
	ui_init_style(&style_MemberManagement_LIST_userlist_extra_texts_main_default);
	
	lv_style_set_pad_top(&style_MemberManagement_LIST_userlist_extra_texts_main_default, 5);
	lv_style_set_pad_left(&style_MemberManagement_LIST_userlist_extra_texts_main_default, 5);
	lv_style_set_pad_right(&style_MemberManagement_LIST_userlist_extra_texts_main_default, 5);
	lv_style_set_pad_bottom(&style_MemberManagement_LIST_userlist_extra_texts_main_default, 5);
	lv_style_set_border_width(&style_MemberManagement_LIST_userlist_extra_texts_main_default, 0);
	lv_style_set_text_color(&style_MemberManagement_LIST_userlist_extra_texts_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_MemberManagement_LIST_userlist_extra_texts_main_default, &lv_font_montserratMedium_12);
	lv_style_set_radius(&style_MemberManagement_LIST_userlist_extra_texts_main_default, 3);
	lv_style_set_bg_opa(&style_MemberManagement_LIST_userlist_extra_texts_main_default, 255);
	lv_style_set_bg_color(&style_MemberManagement_LIST_userlist_extra_texts_main_default, lv_color_hex(0xffffff));

	//Update current screen layout.
	lv_obj_update_layout(ui->MemberManagement);

	
	//Init events for screen.
	events_init_MemberManagement(ui);
}
