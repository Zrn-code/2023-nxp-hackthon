/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"

void init_userData(lv_ui *ui)
{
	ui->UserData_name_idx = 0;
	ui->UserData_medicine_idx = 0;
//	strcpy(ui->UserData_name[0], "Johnson");
//	strcpy(ui->UserData_age[0], "19");
//	strcpy(ui->UserData_gender[0], "unnormal");
	for(int i = 0;i<50;i++)
		ui->UserData_dose[i] = 0;
}

void init_historyData(lv_ui *ui)
{
	ui->HistoryData_idx = 0;
	for(int i = 0;i<50;i++)
		ui->HistoryData_dose[i] = 0;
}

void init_reminderData(lv_ui *ui)
{
	ui->ReminderData_idx = 0;
	for(int i = 0;i<50;i++)
		ui->ReminderData_dose[i] = 0;
//	strcpy(ui->ReminderData_name[0], "Johnson");
//	strcpy(ui->ReminderData_medicine[0] , "Aspirin");
//	strcpy(ui->ReminderData_minute[0] , "10");
//	strcpy(ui->ReminderData_hour[0] , "20");
//	ui->ReminderData_dose[0] , "10";
}

void ui_init_style(lv_style_t * style)
{
  if (style->prop_cnt > 1)
    lv_style_reset(style);
  else
    lv_style_init(style);
}

void init_scr_del_flag(lv_ui *ui)
{
  
	ui->Home_del = true;
	ui->Video_del = true;
	ui->Page_Reserve_del = true;
	ui->Reserve_Storeby_del = true;
	ui->Reverse_Camera_del = true;
	ui->Reserve_Manual_del = true;
	ui->Reserve_Take_del = true;
	ui->Reserve_Storage_del = true;
	ui->Page_Search_del = true;
	ui->Search_reccomend_del = true;
	ui->Page_History_del = true;
	ui->Page_Remind_del = true;
	ui->Remind_delete_del = true;
	ui->Page_settings_del = true;
	ui->Networksetting_del = true;
	ui->ReminderSettings_del = true;
	ui->MemberManagement_del = true;
	ui->AddMember_del = true;
	ui->Modifymember_del = true;
}

void setup_ui(lv_ui *ui)
{
  init_scr_del_flag(ui);
  setup_scr_Home(ui);
  lv_scr_load(ui->Home);
}
