/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Search_reccomend(lv_ui *ui)
{
	//Write codes Search_reccomend
	ui->Search_reccomend = lv_obj_create(NULL);
	ui->g_kb_Search_reccomend = lv_keyboard_create(ui->Search_reccomend);
	lv_obj_add_event_cb(ui->g_kb_Search_reccomend, kb_event_cb, LV_EVENT_ALL, NULL);
	lv_obj_add_flag(ui->g_kb_Search_reccomend, LV_OBJ_FLAG_HIDDEN);
	lv_obj_set_style_text_font(ui->g_kb_Search_reccomend, &lv_font_simsun_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_size(ui->Search_reccomend, 480, 272);

	//Write style for Search_reccomend, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Search_reccomend, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Search_reccomend, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_contBG
	ui->Search_reccomend_contBG = lv_obj_create(ui->Search_reccomend);
	lv_obj_set_pos(ui->Search_reccomend_contBG, 0, 0);
	lv_obj_set_size(ui->Search_reccomend_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Search_reccomend_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Search_reccomend_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Search_reccomend_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Search_reccomend_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Search_reccomend_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Search_reccomend_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Search_reccomend_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Search_reccomend_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Search_reccomend_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_text_title
	ui->Search_reccomend_text_title = lv_label_create(ui->Search_reccomend_contBG);
	lv_label_set_text(ui->Search_reccomend_text_title, "Maybe you should take...");
	lv_label_set_long_mode(ui->Search_reccomend_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Search_reccomend_text_title, 105, 23);
	lv_obj_set_size(ui->Search_reccomend_text_title, 276, 32);

	//Write style for Search_reccomend_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Search_reccomend_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Search_reccomend_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Search_reccomend_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_BUT_back
	ui->Search_reccomend_BUT_back = lv_btn_create(ui->Search_reccomend);
	ui->Search_reccomend_BUT_back_label = lv_label_create(ui->Search_reccomend_BUT_back);
	lv_label_set_text(ui->Search_reccomend_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Search_reccomend_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Search_reccomend_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Search_reccomend_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Search_reccomend_BUT_back, 25, 17);
	lv_obj_set_size(ui->Search_reccomend_BUT_back, 35, 32);

	//Write style for Search_reccomend_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Search_reccomend_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Search_reccomend_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Search_reccomend_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Search_reccomend_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_BUT_take
	ui->Search_reccomend_BUT_take = lv_btn_create(ui->Search_reccomend);
	ui->Search_reccomend_BUT_take_label = lv_label_create(ui->Search_reccomend_BUT_take);
	lv_label_set_text(ui->Search_reccomend_BUT_take_label, "Take");
	lv_label_set_long_mode(ui->Search_reccomend_BUT_take_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Search_reccomend_BUT_take_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Search_reccomend_BUT_take, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Search_reccomend_BUT_take, 366, 224);
	lv_obj_set_size(ui->Search_reccomend_BUT_take, 100, 37);

	//Write style for Search_reccomend_BUT_take, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Search_reccomend_BUT_take, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Search_reccomend_BUT_take, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Search_reccomend_BUT_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_BUT_take, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_BUT_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Search_reccomend_BUT_take, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_BUT_take, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Search_reccomend_BUT_take, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_text_suggested
	ui->Search_reccomend_text_suggested = lv_label_create(ui->Search_reccomend);
	lv_label_set_text(ui->Search_reccomend_text_suggested, "Suggested medicine:");
	lv_label_set_long_mode(ui->Search_reccomend_text_suggested, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Search_reccomend_text_suggested, 17, 69);
	lv_obj_set_size(ui->Search_reccomend_text_suggested, 176, 32);

	//Write style for Search_reccomend_text_suggested, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Search_reccomend_text_suggested, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_text_suggested, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Search_reccomend_text_suggested, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_text_suggested, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_text_Take
	ui->Search_reccomend_text_Take = lv_label_create(ui->Search_reccomend);
	lv_label_set_text(ui->Search_reccomend_text_Take, "Take:");
	lv_label_set_long_mode(ui->Search_reccomend_text_Take, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Search_reccomend_text_Take, 190, 120);
	lv_obj_set_size(ui->Search_reccomend_text_Take, 100, 32);

	//Write style for Search_reccomend_text_Take, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Search_reccomend_text_Take, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_text_Take, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Search_reccomend_text_Take, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_text_Take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_text_number
	ui->Search_reccomend_text_number = lv_label_create(ui->Search_reccomend);
	lv_label_set_text(ui->Search_reccomend_text_number, "Numbers:");
	lv_label_set_long_mode(ui->Search_reccomend_text_number, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Search_reccomend_text_number, 199, 173);
	lv_obj_set_size(ui->Search_reccomend_text_number, 82, 17);

	//Write style for Search_reccomend_text_number, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Search_reccomend_text_number, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_text_number, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Search_reccomend_text_number, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_text_number, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_INPUT_numbers
	ui->Search_reccomend_INPUT_numbers = lv_textarea_create(ui->Search_reccomend);
	lv_textarea_set_text(ui->Search_reccomend_INPUT_numbers, "");
	lv_textarea_set_password_bullet(ui->Search_reccomend_INPUT_numbers, "*");
	lv_textarea_set_password_mode(ui->Search_reccomend_INPUT_numbers, false);
	lv_textarea_set_one_line(ui->Search_reccomend_INPUT_numbers, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->Search_reccomend_INPUT_numbers, ta_event_cb, LV_EVENT_ALL, ui->g_kb_Search_reccomend);
	#endif
	lv_obj_set_pos(ui->Search_reccomend_INPUT_numbers, 291, 166);
	lv_obj_set_size(ui->Search_reccomend_INPUT_numbers, 128, 29);

	//Write style for Search_reccomend_INPUT_numbers, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Search_reccomend_INPUT_numbers, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_INPUT_numbers, &lv_font_montserratMedium_15, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Search_reccomend_INPUT_numbers, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Search_reccomend_INPUT_numbers, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Search_reccomend_INPUT_numbers, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Search_reccomend_INPUT_numbers, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Search_reccomend_INPUT_numbers, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Search_reccomend_INPUT_numbers, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Search_reccomend_INPUT_numbers, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Search_reccomend_INPUT_numbers, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_INPUT_numbers, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Search_reccomend_INPUT_numbers, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Search_reccomend_INPUT_numbers, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Search_reccomend_INPUT_numbers, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_INPUT_numbers, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Search_reccomend_INPUT_numbers, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Search_reccomend_INPUT_numbers, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_INPUT_numbers, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_INPUT_sugmedlist
	ui->Search_reccomend_INPUT_sugmedlist = lv_dropdown_create(ui->Search_reccomend);
	lv_dropdown_set_options(ui->Search_reccomend_INPUT_sugmedlist, "");
	lv_obj_set_pos(ui->Search_reccomend_INPUT_sugmedlist, 290, 113);
	lv_obj_set_size(ui->Search_reccomend_INPUT_sugmedlist, 130, 30);

	//Write style for Search_reccomend_INPUT_sugmedlist, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Search_reccomend_INPUT_sugmedlist, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Search_reccomend_INPUT_sugmedlist, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Search_reccomend_INPUT_sugmedlist, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Search_reccomend_INPUT_sugmedlist, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Search_reccomend_INPUT_sugmedlist, lv_color_hex(0xe1e6ee), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Search_reccomend_INPUT_sugmedlist, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Search_reccomend_INPUT_sugmedlist, 8, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Search_reccomend_INPUT_sugmedlist, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Search_reccomend_INPUT_sugmedlist, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Search_reccomend_INPUT_sugmedlist, 3, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Search_reccomend_INPUT_sugmedlist, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Search_reccomend_INPUT_sugmedlist, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_INPUT_sugmedlist, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_CHECKED for &style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked
	static lv_style_t style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked;
	ui_init_style(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked);
	
	lv_style_set_text_color(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, lv_color_hex(0xffffff));
	lv_style_set_text_font(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, 1);
	lv_style_set_border_opa(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, 255);
	lv_style_set_border_color(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, 3);
	lv_style_set_bg_opa(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, 255);
	lv_style_set_bg_color(&style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, lv_color_hex(0x00a1b5));
	lv_obj_add_style(lv_dropdown_get_list(ui->Search_reccomend_INPUT_sugmedlist), &style_Search_reccomend_INPUT_sugmedlist_extra_list_selected_checked, LV_PART_SELECTED|LV_STATE_CHECKED);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default
	static lv_style_t style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default;
	ui_init_style(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default);
	
	lv_style_set_max_height(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, 90);
	lv_style_set_text_color(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, 1);
	lv_style_set_border_opa(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, 255);
	lv_style_set_border_color(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, 3);
	lv_style_set_bg_opa(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, 255);
	lv_style_set_bg_color(&style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, lv_color_hex(0xffffff));
	lv_obj_add_style(lv_dropdown_get_list(ui->Search_reccomend_INPUT_sugmedlist), &style_Search_reccomend_INPUT_sugmedlist_extra_list_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default
	static lv_style_t style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default;
	ui_init_style(&style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default);
	
	lv_style_set_radius(&style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default, 0);
	lv_obj_add_style(lv_dropdown_get_list(ui->Search_reccomend_INPUT_sugmedlist), &style_Search_reccomend_INPUT_sugmedlist_extra_list_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Search_reccomend_LIST_suggestedlist
	ui->Search_reccomend_LIST_suggestedlist = lv_list_create(ui->Search_reccomend);
	lv_obj_set_pos(ui->Search_reccomend_LIST_suggestedlist, 25, 93);
	lv_obj_set_size(ui->Search_reccomend_LIST_suggestedlist, 161, 159);
	lv_obj_set_scrollbar_mode(ui->Search_reccomend_LIST_suggestedlist, LV_SCROLLBAR_MODE_ACTIVE);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_LIST_suggestedlist_main_main_default
	static lv_style_t style_Search_reccomend_LIST_suggestedlist_main_main_default;
	ui_init_style(&style_Search_reccomend_LIST_suggestedlist_main_main_default);
	
	lv_style_set_pad_top(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_pad_left(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_pad_right(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_pad_bottom(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 5);
	lv_style_set_bg_opa(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 255);
	lv_style_set_bg_color(&style_Search_reccomend_LIST_suggestedlist_main_main_default, lv_color_hex(0xffffff));
	lv_style_set_border_width(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 1);
	lv_style_set_border_opa(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 255);
	lv_style_set_border_color(&style_Search_reccomend_LIST_suggestedlist_main_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Search_reccomend_LIST_suggestedlist_main_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 3);
	lv_style_set_shadow_width(&style_Search_reccomend_LIST_suggestedlist_main_main_default, 0);
	lv_obj_add_style(ui->Search_reccomend_LIST_suggestedlist, &style_Search_reccomend_LIST_suggestedlist_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_LIST_suggestedlist_main_scrollbar_default
	static lv_style_t style_Search_reccomend_LIST_suggestedlist_main_scrollbar_default;
	ui_init_style(&style_Search_reccomend_LIST_suggestedlist_main_scrollbar_default);
	
	lv_style_set_radius(&style_Search_reccomend_LIST_suggestedlist_main_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Search_reccomend_LIST_suggestedlist_main_scrollbar_default, 255);
	lv_style_set_bg_color(&style_Search_reccomend_LIST_suggestedlist_main_scrollbar_default, lv_color_hex(0xffffff));
	lv_obj_add_style(ui->Search_reccomend_LIST_suggestedlist, &style_Search_reccomend_LIST_suggestedlist_main_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default
	static lv_style_t style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default;
	ui_init_style(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default);
	
	lv_style_set_pad_top(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_pad_left(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_pad_right(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_pad_bottom(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, 5);
	lv_style_set_border_width(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, 0);
	lv_style_set_text_color(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, &lv_font_montserratMedium_12);
	lv_style_set_radius(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, 3);
	lv_style_set_bg_opa(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Search_reccomend_LIST_suggestedlist_extra_btns_main_default, lv_color_hex(0xffffff));

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default
	static lv_style_t style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default;
	ui_init_style(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default);
	
	lv_style_set_pad_top(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_pad_left(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_pad_right(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_pad_bottom(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, 5);
	lv_style_set_border_width(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, 0);
	lv_style_set_text_color(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, &lv_font_montserratMedium_12);
	lv_style_set_radius(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, 3);
	lv_style_set_bg_opa(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, 255);
	lv_style_set_bg_color(&style_Search_reccomend_LIST_suggestedlist_extra_texts_main_default, lv_color_hex(0xffffff));

	//Write codes Search_reccomend_window_notice
	ui->Search_reccomend_window_notice = lv_win_create(ui->Search_reccomend, 40);
	lv_win_add_title(ui->Search_reccomend_window_notice, "NOTICE");
	ui->Search_reccomend_window_notice_item0 = lv_win_add_btn(ui->Search_reccomend_window_notice, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *Search_reccomend_window_notice_label = lv_label_create(lv_win_get_content(ui->Search_reccomend_window_notice));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->Search_reccomend_window_notice), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(Search_reccomend_window_notice_label, "Taking successfully!!\nDon't forget to see a doctor!!\nTaking Medicine only ease your pain\nin a SHORT time.\n");
	lv_obj_set_pos(ui->Search_reccomend_window_notice, 51, 69);
	lv_obj_set_size(ui->Search_reccomend_window_notice, 400, 177);
	lv_obj_add_flag(ui->Search_reccomend_window_notice, LV_OBJ_FLAG_HIDDEN);

	//Write style for Search_reccomend_window_notice, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Search_reccomend_window_notice, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Search_reccomend_window_notice, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->Search_reccomend_window_notice, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Search_reccomend_window_notice, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_window_notice_extra_content_main_default
	static lv_style_t style_Search_reccomend_window_notice_extra_content_main_default;
	ui_init_style(&style_Search_reccomend_window_notice_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_Search_reccomend_window_notice_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_Search_reccomend_window_notice_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_Search_reccomend_window_notice_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Search_reccomend_window_notice_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_Search_reccomend_window_notice_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_Search_reccomend_window_notice_extra_content_main_default, 7);
	lv_obj_add_style(lv_win_get_content(ui->Search_reccomend_window_notice), &style_Search_reccomend_window_notice_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_window_notice_extra_header_main_default
	static lv_style_t style_Search_reccomend_window_notice_extra_header_main_default;
	ui_init_style(&style_Search_reccomend_window_notice_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_Search_reccomend_window_notice_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_Search_reccomend_window_notice_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_Search_reccomend_window_notice_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Search_reccomend_window_notice_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_Search_reccomend_window_notice_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_Search_reccomend_window_notice_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->Search_reccomend_window_notice), &style_Search_reccomend_window_notice_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Search_reccomend_window_notice_extra_btns_main_default
	static lv_style_t style_Search_reccomend_window_notice_extra_btns_main_default;
	ui_init_style(&style_Search_reccomend_window_notice_extra_btns_main_default);
	
	lv_style_set_radius(&style_Search_reccomend_window_notice_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_Search_reccomend_window_notice_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Search_reccomend_window_notice_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_Search_reccomend_window_notice_extra_btns_main_default, 0);
	lv_obj_add_style(ui->Search_reccomend_window_notice_item0, &style_Search_reccomend_window_notice_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Search_reccomend);

	
	//Init events for screen.
	events_init_Search_reccomend(ui);
}
