/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Reverse_Camera(lv_ui *ui)
{
	//Write codes Reverse_Camera
	ui->Reverse_Camera = lv_obj_create(NULL);
	lv_obj_set_size(ui->Reverse_Camera, 480, 272);

	//Write style for Reverse_Camera, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_contBG
	ui->Reverse_Camera_contBG = lv_obj_create(ui->Reverse_Camera);
	lv_obj_set_pos(ui->Reverse_Camera_contBG, 0, 0);
	lv_obj_set_size(ui->Reverse_Camera_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Reverse_Camera_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Reverse_Camera_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reverse_Camera_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reverse_Camera_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_text_title
	ui->Reverse_Camera_text_title = lv_label_create(ui->Reverse_Camera);
	lv_label_set_text(ui->Reverse_Camera_text_title, "Storing Medicine");
	lv_label_set_long_mode(ui->Reverse_Camera_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reverse_Camera_text_title, 135, 23);
	lv_obj_set_size(ui->Reverse_Camera_text_title, 210, 32);

	//Write style for Reverse_Camera_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reverse_Camera_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_text_put
	ui->Reverse_Camera_text_put = lv_label_create(ui->Reverse_Camera);
	lv_label_set_text(ui->Reverse_Camera_text_put, "Put your medicine under camera...");
	lv_label_set_long_mode(ui->Reverse_Camera_text_put, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reverse_Camera_text_put, 25, 108);
	lv_obj_set_size(ui->Reverse_Camera_text_put, 289, 21);

	//Write style for Reverse_Camera_text_put, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_text_put, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_text_put, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_text_put, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_text_put, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_text_user
	ui->Reverse_Camera_text_user = lv_label_create(ui->Reverse_Camera);
	lv_label_set_text(ui->Reverse_Camera_text_user, "User :");
	lv_label_set_long_mode(ui->Reverse_Camera_text_user, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reverse_Camera_text_user, 18, 77);
	lv_obj_set_size(ui->Reverse_Camera_text_user, 72, 17);

	//Write style for Reverse_Camera_text_user, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_text_user, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_text_user, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_text_user, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_text_user, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_text_num
	ui->Reverse_Camera_text_num = lv_label_create(ui->Reverse_Camera);
	lv_label_set_text(ui->Reverse_Camera_text_num, "Numbers");
	lv_label_set_long_mode(ui->Reverse_Camera_text_num, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reverse_Camera_text_num, 210, 137);
	lv_obj_set_size(ui->Reverse_Camera_text_num, 100, 32);

	//Write style for Reverse_Camera_text_num, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_text_num, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_text_num, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reverse_Camera_text_num, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_text_num, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_text_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_text_med
	ui->Reverse_Camera_text_med = lv_label_create(ui->Reverse_Camera);
	lv_label_set_text(ui->Reverse_Camera_text_med, "Medicine");
	lv_label_set_long_mode(ui->Reverse_Camera_text_med, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reverse_Camera_text_med, 71, 137);
	lv_obj_set_size(ui->Reverse_Camera_text_med, 100, 32);

	//Write style for Reverse_Camera_text_med, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_text_med, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_text_med, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reverse_Camera_text_med, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_text_med, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_text_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_BUT_back
	ui->Reverse_Camera_BUT_back = lv_btn_create(ui->Reverse_Camera);
	ui->Reverse_Camera_BUT_back_label = lv_label_create(ui->Reverse_Camera_BUT_back);
	lv_label_set_text(ui->Reverse_Camera_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Reverse_Camera_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reverse_Camera_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reverse_Camera_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reverse_Camera_BUT_back, 25, 17);
	lv_obj_set_size(ui->Reverse_Camera_BUT_back, 35, 32);

	//Write style for Reverse_Camera_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reverse_Camera_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_BUT_add
	ui->Reverse_Camera_BUT_add = lv_btn_create(ui->Reverse_Camera);
	ui->Reverse_Camera_BUT_add_label = lv_label_create(ui->Reverse_Camera_BUT_add);
	lv_label_set_text(ui->Reverse_Camera_BUT_add_label, "Add");
	lv_label_set_long_mode(ui->Reverse_Camera_BUT_add_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reverse_Camera_BUT_add_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reverse_Camera_BUT_add, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reverse_Camera_BUT_add, 98, 205);
	lv_obj_set_size(ui->Reverse_Camera_BUT_add, 91, 29);

	//Write style for Reverse_Camera_BUT_add, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_BUT_add, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera_BUT_add, lv_color_hex(0x0506a0), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reverse_Camera_BUT_add, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_BUT_add, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_BUT_add, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_BUT_add, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_BUT_add, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_BUT_add, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_BUT_rescan
	ui->Reverse_Camera_BUT_rescan = lv_btn_create(ui->Reverse_Camera);
	ui->Reverse_Camera_BUT_rescan_label = lv_label_create(ui->Reverse_Camera_BUT_rescan);
	lv_label_set_text(ui->Reverse_Camera_BUT_rescan_label, "Re-Scan");
	lv_label_set_long_mode(ui->Reverse_Camera_BUT_rescan_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reverse_Camera_BUT_rescan_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reverse_Camera_BUT_rescan, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reverse_Camera_BUT_rescan, 196, 205);
	lv_obj_set_size(ui->Reverse_Camera_BUT_rescan, 91, 29);

	//Write style for Reverse_Camera_BUT_rescan, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_BUT_rescan, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera_BUT_rescan, lv_color_hex(0x0506a0), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reverse_Camera_BUT_rescan, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_BUT_rescan, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_BUT_rescan, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_BUT_rescan, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_BUT_rescan, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_BUT_rescan, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_BUT_home
	ui->Reverse_Camera_BUT_home = lv_btn_create(ui->Reverse_Camera);
	ui->Reverse_Camera_BUT_home_label = lv_label_create(ui->Reverse_Camera_BUT_home);
	lv_label_set_text(ui->Reverse_Camera_BUT_home_label, "Finish");
	lv_label_set_long_mode(ui->Reverse_Camera_BUT_home_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reverse_Camera_BUT_home_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reverse_Camera_BUT_home, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reverse_Camera_BUT_home, 366, 224);
	lv_obj_set_size(ui->Reverse_Camera_BUT_home, 100, 37);

	//Write style for Reverse_Camera_BUT_home, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_BUT_home, 204, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera_BUT_home, lv_color_hex(0x0506a0), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reverse_Camera_BUT_home, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_BUT_home, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_BUT_home, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reverse_Camera_BUT_home, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_BUT_home, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_BUT_home, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_SCAN_med
	ui->Reverse_Camera_SCAN_med = lv_textarea_create(ui->Reverse_Camera);
	lv_textarea_set_text(ui->Reverse_Camera_SCAN_med, "");
	lv_textarea_set_password_bullet(ui->Reverse_Camera_SCAN_med, "*");
	lv_textarea_set_password_mode(ui->Reverse_Camera_SCAN_med, false);
	lv_textarea_set_one_line(ui->Reverse_Camera_SCAN_med, true);
	lv_obj_set_pos(ui->Reverse_Camera_SCAN_med, 54, 161);
	lv_obj_set_size(ui->Reverse_Camera_SCAN_med, 135, 29);

	//Write style for Reverse_Camera_SCAN_med, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reverse_Camera_SCAN_med, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_SCAN_med, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reverse_Camera_SCAN_med, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_SCAN_med, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_SCAN_med, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera_SCAN_med, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reverse_Camera_SCAN_med, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Reverse_Camera_SCAN_med, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Reverse_Camera_SCAN_med, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Reverse_Camera_SCAN_med, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_SCAN_med, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_SCAN_med, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_SCAN_med, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_SCAN_med, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_SCAN_med, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Reverse_Camera_SCAN_med, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_SCAN_med, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_SCAN_med, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_SCAN_num
	ui->Reverse_Camera_SCAN_num = lv_textarea_create(ui->Reverse_Camera);
	lv_textarea_set_text(ui->Reverse_Camera_SCAN_num, "");
	lv_textarea_set_password_bullet(ui->Reverse_Camera_SCAN_num, "*");
	lv_textarea_set_password_mode(ui->Reverse_Camera_SCAN_num, false);
	lv_textarea_set_one_line(ui->Reverse_Camera_SCAN_num, false);
	lv_obj_set_pos(ui->Reverse_Camera_SCAN_num, 196, 161);
	lv_obj_set_size(ui->Reverse_Camera_SCAN_num, 135, 29);

	//Write style for Reverse_Camera_SCAN_num, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reverse_Camera_SCAN_num, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_SCAN_num, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reverse_Camera_SCAN_num, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reverse_Camera_SCAN_num, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_SCAN_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reverse_Camera_SCAN_num, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Reverse_Camera_SCAN_num, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Reverse_Camera_SCAN_num, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Reverse_Camera_SCAN_num, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_SCAN_num, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_SCAN_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_SCAN_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_SCAN_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_SCAN_num, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Reverse_Camera_SCAN_num, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_SCAN_num, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_SCAN_num, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_INPUT_User
	ui->Reverse_Camera_INPUT_User = lv_dropdown_create(ui->Reverse_Camera);
	lv_dropdown_set_options(ui->Reverse_Camera_INPUT_User, "");
	lv_obj_set_pos(ui->Reverse_Camera_INPUT_User, 90, 70);
	lv_obj_set_size(ui->Reverse_Camera_INPUT_User, 130, 30);

	//Write style for Reverse_Camera_INPUT_User, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reverse_Camera_INPUT_User, lv_color_hex(0x0D3055), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reverse_Camera_INPUT_User, &lv_font_montserratMedium_15, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reverse_Camera_INPUT_User, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Reverse_Camera_INPUT_User, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Reverse_Camera_INPUT_User, lv_color_hex(0xe1e6ee), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Reverse_Camera_INPUT_User, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reverse_Camera_INPUT_User, 8, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reverse_Camera_INPUT_User, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reverse_Camera_INPUT_User, 6, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reverse_Camera_INPUT_User, 3, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_INPUT_User, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera_INPUT_User, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_INPUT_User, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_CHECKED for &style_Reverse_Camera_INPUT_User_extra_list_selected_checked
	static lv_style_t style_Reverse_Camera_INPUT_User_extra_list_selected_checked;
	ui_init_style(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked);
	
	lv_style_set_text_color(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, lv_color_hex(0xffffff));
	lv_style_set_text_font(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, &lv_font_montserratMedium_15);
	lv_style_set_border_width(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, 1);
	lv_style_set_border_opa(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, 255);
	lv_style_set_border_color(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, 3);
	lv_style_set_bg_opa(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, 255);
	lv_style_set_bg_color(&style_Reverse_Camera_INPUT_User_extra_list_selected_checked, lv_color_hex(0x00a1b5));
	lv_obj_add_style(lv_dropdown_get_list(ui->Reverse_Camera_INPUT_User), &style_Reverse_Camera_INPUT_User_extra_list_selected_checked, LV_PART_SELECTED|LV_STATE_CHECKED);

	//Write style state: LV_STATE_DEFAULT for &style_Reverse_Camera_INPUT_User_extra_list_main_default
	static lv_style_t style_Reverse_Camera_INPUT_User_extra_list_main_default;
	ui_init_style(&style_Reverse_Camera_INPUT_User_extra_list_main_default);
	
	lv_style_set_max_height(&style_Reverse_Camera_INPUT_User_extra_list_main_default, 90);
	lv_style_set_text_color(&style_Reverse_Camera_INPUT_User_extra_list_main_default, lv_color_hex(0x0D3055));
	lv_style_set_text_font(&style_Reverse_Camera_INPUT_User_extra_list_main_default, &lv_font_montserratMedium_12);
	lv_style_set_border_width(&style_Reverse_Camera_INPUT_User_extra_list_main_default, 1);
	lv_style_set_border_opa(&style_Reverse_Camera_INPUT_User_extra_list_main_default, 255);
	lv_style_set_border_color(&style_Reverse_Camera_INPUT_User_extra_list_main_default, lv_color_hex(0xe1e6ee));
	lv_style_set_border_side(&style_Reverse_Camera_INPUT_User_extra_list_main_default, LV_BORDER_SIDE_FULL);
	lv_style_set_radius(&style_Reverse_Camera_INPUT_User_extra_list_main_default, 3);
	lv_style_set_bg_opa(&style_Reverse_Camera_INPUT_User_extra_list_main_default, 255);
	lv_style_set_bg_color(&style_Reverse_Camera_INPUT_User_extra_list_main_default, lv_color_hex(0xffffff));
	lv_obj_add_style(lv_dropdown_get_list(ui->Reverse_Camera_INPUT_User), &style_Reverse_Camera_INPUT_User_extra_list_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default
	static lv_style_t style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default;
	ui_init_style(&style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default);
	
	lv_style_set_radius(&style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default, 3);
	lv_style_set_bg_opa(&style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default, 0);
	lv_obj_add_style(lv_dropdown_get_list(ui->Reverse_Camera_INPUT_User), &style_Reverse_Camera_INPUT_User_extra_list_scrollbar_default, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Reverse_Camera_win_success
	ui->Reverse_Camera_win_success = lv_win_create(ui->Reverse_Camera, 40);
	lv_win_add_title(ui->Reverse_Camera_win_success, "System");
	ui->Reverse_Camera_win_success_item0 = lv_win_add_btn(ui->Reverse_Camera_win_success, LV_SYMBOL_CLOSE, 40);
	lv_obj_t *Reverse_Camera_win_success_label = lv_label_create(lv_win_get_content(ui->Reverse_Camera_win_success));
	lv_obj_set_scrollbar_mode(lv_win_get_content(ui->Reverse_Camera_win_success), LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(Reverse_Camera_win_success_label, "Storing successfully!!\n");
	lv_obj_set_pos(ui->Reverse_Camera_win_success, 49, 48);
	lv_obj_set_size(ui->Reverse_Camera_win_success, 400, 177);
	lv_obj_add_flag(ui->Reverse_Camera_win_success, LV_OBJ_FLAG_HIDDEN);

	//Write style for Reverse_Camera_win_success, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reverse_Camera_win_success, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reverse_Camera_win_success, lv_color_hex(0xeeeef6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->Reverse_Camera_win_success, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reverse_Camera_win_success, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reverse_Camera_win_success_extra_content_main_default
	static lv_style_t style_Reverse_Camera_win_success_extra_content_main_default;
	ui_init_style(&style_Reverse_Camera_win_success_extra_content_main_default);
	
	lv_style_set_bg_opa(&style_Reverse_Camera_win_success_extra_content_main_default, 255);
	lv_style_set_bg_color(&style_Reverse_Camera_win_success_extra_content_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_text_color(&style_Reverse_Camera_win_success_extra_content_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Reverse_Camera_win_success_extra_content_main_default, &lv_font_arial_15);
	lv_style_set_text_letter_space(&style_Reverse_Camera_win_success_extra_content_main_default, 0);
	lv_style_set_text_line_space(&style_Reverse_Camera_win_success_extra_content_main_default, 2);
	lv_obj_add_style(lv_win_get_content(ui->Reverse_Camera_win_success), &style_Reverse_Camera_win_success_extra_content_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reverse_Camera_win_success_extra_header_main_default
	static lv_style_t style_Reverse_Camera_win_success_extra_header_main_default;
	ui_init_style(&style_Reverse_Camera_win_success_extra_header_main_default);
	
	lv_style_set_bg_opa(&style_Reverse_Camera_win_success_extra_header_main_default, 236);
	lv_style_set_bg_color(&style_Reverse_Camera_win_success_extra_header_main_default, lv_color_hex(0x7752FE));
	lv_style_set_text_color(&style_Reverse_Camera_win_success_extra_header_main_default, lv_color_hex(0x393c41));
	lv_style_set_text_font(&style_Reverse_Camera_win_success_extra_header_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_letter_space(&style_Reverse_Camera_win_success_extra_header_main_default, 0);
	lv_style_set_text_line_space(&style_Reverse_Camera_win_success_extra_header_main_default, 2);
	lv_obj_add_style(lv_win_get_header(ui->Reverse_Camera_win_success), &style_Reverse_Camera_win_success_extra_header_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_Reverse_Camera_win_success_extra_btns_main_default
	static lv_style_t style_Reverse_Camera_win_success_extra_btns_main_default;
	ui_init_style(&style_Reverse_Camera_win_success_extra_btns_main_default);
	
	lv_style_set_radius(&style_Reverse_Camera_win_success_extra_btns_main_default, 8);
	lv_style_set_bg_opa(&style_Reverse_Camera_win_success_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_Reverse_Camera_win_success_extra_btns_main_default, lv_color_hex(0xC2D9FF));
	lv_style_set_shadow_width(&style_Reverse_Camera_win_success_extra_btns_main_default, 0);
	lv_obj_add_style(ui->Reverse_Camera_win_success_item0, &style_Reverse_Camera_win_success_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Reverse_Camera);

	
	//Init events for screen.
	events_init_Reverse_Camera(ui);
}
