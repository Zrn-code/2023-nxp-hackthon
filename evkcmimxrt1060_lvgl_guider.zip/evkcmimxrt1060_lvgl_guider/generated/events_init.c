/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "events_init.h"
#include <stdio.h>
#include "lvgl.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"

#include "MIMXRT1062.h"
#include <string.h>

int which[3] = {0};
volatile bool isLight = false;
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_LED_GPIO     BOARD_USER_LED_GPIO
#define EXAMPLE_LED_GPIO_PIN BOARD_USER_LED_PIN

lv_obj_t * target, * ls_target;

static void event_cb_remind(lv_event_t * e)
{
    target = lv_event_get_target(e);

    //lv_obj_t * cont = lv_event_get_current_target(e);

    /*if(target == cont) return;*/

    if(target != ls_target)
    {
        lv_obj_set_style_bg_color(target, lv_palette_main(LV_PALETTE_GREY), 0);
        ls_target = target;
    }
    else
    {
    	lv_obj_set_style_bg_color(target, lv_color_hex(0xFFFFFF), 0);
    	ls_target = NULL;
    	target = NULL;
    }
    GPIO_PinWrite(GPIO1, 9U, 1U);
}

static void event_cb(lv_event_t * e)
{
    target = lv_event_get_target(e);

    //lv_obj_t * cont = lv_event_get_current_target(e);

    /*if(target == cont) return;*/

    if(target != ls_target)
    {
        lv_obj_set_style_bg_color(target, lv_palette_main(LV_PALETTE_GREY), 0);
        ls_target = target;
    }
    else
    {
    	lv_obj_set_style_bg_color(target, lv_color_hex(0xFFFFFF), 0);
    	ls_target = NULL;
    	target = NULL;
    }
    GPIO_PinWrite(GPIO1, 9U, 0U);
}

static void Home_img_setting_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_settings_del == true) {
	          setup_scr_Page_settings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_settings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Home_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Home_contSetup_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Remind_del == true) {
	          setup_scr_Page_Remind(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Remind, LV_SCR_LOAD_ANIM_FADE_ON, 100, 100, true);
	        guider_ui.Home_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Home_BUT_History_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_History_del == true) {
	          setup_scr_Page_History(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_History, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Home_del = true;
	    }
		//Write animation: Home_upimage scale_width
	  	lv_anim_t Home_upimage_anim_scale_width;
	  	lv_anim_init(&Home_upimage_anim_scale_width);
	  	lv_anim_set_var(&Home_upimage_anim_scale_width, guider_ui.Home_upimage);
	  	lv_anim_set_time(&Home_upimage_anim_scale_width, 200);
	  	lv_anim_set_delay(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_exec_cb(&Home_upimage_anim_scale_width, (lv_anim_exec_xcb_t)lv_obj_set_width);
		lv_anim_set_values(&Home_upimage_anim_scale_width, lv_obj_get_width(guider_ui.Home_upimage), 480);
	  	lv_anim_set_path_cb(&Home_upimage_anim_scale_width, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_repeat_delay(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_playback_time(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_playback_delay(&Home_upimage_anim_scale_width, 0);
		lv_anim_start(&Home_upimage_anim_scale_width);
		//Write animation: Home_upimage scale_height
	  	lv_anim_t Home_upimage_anim_scale_height;
	  	lv_anim_init(&Home_upimage_anim_scale_height);
	  	lv_anim_set_var(&Home_upimage_anim_scale_height, guider_ui.Home_upimage);
	  	lv_anim_set_time(&Home_upimage_anim_scale_height, 200);
	  	lv_anim_set_delay(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_exec_cb(&Home_upimage_anim_scale_height, (lv_anim_exec_xcb_t)lv_obj_set_height);
		lv_anim_set_values(&Home_upimage_anim_scale_height, lv_obj_get_height(guider_ui.Home_upimage), 60);
	  	lv_anim_set_path_cb(&Home_upimage_anim_scale_height, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_repeat_delay(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_playback_time(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_playback_delay(&Home_upimage_anim_scale_height, 0);
		lv_anim_start(&Home_upimage_anim_scale_height);
		break;
	}
	default:
		break;
	}
}
static void Home_BUT_Reserve_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write animation: Home_upimage scale_width
	  	lv_anim_t Home_upimage_anim_scale_width;
	  	lv_anim_init(&Home_upimage_anim_scale_width);
	  	lv_anim_set_var(&Home_upimage_anim_scale_width, guider_ui.Home_upimage);
	  	lv_anim_set_time(&Home_upimage_anim_scale_width, 200);
	  	lv_anim_set_delay(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_exec_cb(&Home_upimage_anim_scale_width, (lv_anim_exec_xcb_t)lv_obj_set_width);
		lv_anim_set_values(&Home_upimage_anim_scale_width, lv_obj_get_width(guider_ui.Home_upimage), 480);
	  	lv_anim_set_path_cb(&Home_upimage_anim_scale_width, &lv_anim_path_ease_out);
	  	lv_anim_set_repeat_count(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_repeat_delay(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_playback_time(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_playback_delay(&Home_upimage_anim_scale_width, 0);
		lv_anim_start(&Home_upimage_anim_scale_width);
		//Write animation: Home_upimage scale_height
	  	lv_anim_t Home_upimage_anim_scale_height;
	  	lv_anim_init(&Home_upimage_anim_scale_height);
	  	lv_anim_set_var(&Home_upimage_anim_scale_height, guider_ui.Home_upimage);
	  	lv_anim_set_time(&Home_upimage_anim_scale_height, 200);
	  	lv_anim_set_delay(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_exec_cb(&Home_upimage_anim_scale_height, (lv_anim_exec_xcb_t)lv_obj_set_height);
		lv_anim_set_values(&Home_upimage_anim_scale_height, lv_obj_get_height(guider_ui.Home_upimage), 60);
	  	lv_anim_set_path_cb(&Home_upimage_anim_scale_height, &lv_anim_path_ease_out);
	  	lv_anim_set_repeat_count(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_repeat_delay(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_playback_time(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_playback_delay(&Home_upimage_anim_scale_height, 0);
		lv_anim_start(&Home_upimage_anim_scale_height);
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Reserve_del == true) {
	          setup_scr_Page_Reserve(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Reserve, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Home_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Home_BUT_search_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Search_del == true) {
	          setup_scr_Page_Search(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Search, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Home_del = true;
	    }
		//Write animation: Home_upimage scale_width
	  	lv_anim_t Home_upimage_anim_scale_width;
	  	lv_anim_init(&Home_upimage_anim_scale_width);
	  	lv_anim_set_var(&Home_upimage_anim_scale_width, guider_ui.Home_upimage);
	  	lv_anim_set_time(&Home_upimage_anim_scale_width, 200);
	  	lv_anim_set_delay(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_exec_cb(&Home_upimage_anim_scale_width, (lv_anim_exec_xcb_t)lv_obj_set_width);
		lv_anim_set_values(&Home_upimage_anim_scale_width, lv_obj_get_width(guider_ui.Home_upimage), 480);
	  	lv_anim_set_path_cb(&Home_upimage_anim_scale_width, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_repeat_delay(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_playback_time(&Home_upimage_anim_scale_width, 0);
	  	lv_anim_set_playback_delay(&Home_upimage_anim_scale_width, 0);
		lv_anim_start(&Home_upimage_anim_scale_width);
		//Write animation: Home_upimage scale_height
	  	lv_anim_t Home_upimage_anim_scale_height;
	  	lv_anim_init(&Home_upimage_anim_scale_height);
	  	lv_anim_set_var(&Home_upimage_anim_scale_height, guider_ui.Home_upimage);
	  	lv_anim_set_time(&Home_upimage_anim_scale_height, 200);
	  	lv_anim_set_delay(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_exec_cb(&Home_upimage_anim_scale_height, (lv_anim_exec_xcb_t)lv_obj_set_height);
		lv_anim_set_values(&Home_upimage_anim_scale_height, lv_obj_get_height(guider_ui.Home_upimage), 60);
	  	lv_anim_set_path_cb(&Home_upimage_anim_scale_height, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_repeat_delay(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_playback_time(&Home_upimage_anim_scale_height, 0);
	  	lv_anim_set_playback_delay(&Home_upimage_anim_scale_height, 0);
		lv_anim_start(&Home_upimage_anim_scale_height);
		break;
	}
	default:
		break;
	}
}
static void Home_BUT_wifi_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Home_win_wifi, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Home_BUT_contact_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Home_win_contact, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Home_BUT_QR_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Home_QRcode, LV_OBJ_FLAG_HIDDEN);
		lv_obj_clear_flag(guider_ui.Home_win_QR, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Home_BUT_video_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Video_del == true) {
	          setup_scr_Video(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Video, LV_SCR_LOAD_ANIM_MOVE_BOTTOM, 200, 200, true);
	        guider_ui.Home_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Home_win_wifi_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Home_win_wifi, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Home_win_contact_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Home_win_contact, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Home_win_QR_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Home_win_QR, LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(guider_ui.Home_QRcode, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_Home(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Home_img_setting, Home_img_setting_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_contSetup, Home_contSetup_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_BUT_History, Home_BUT_History_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_BUT_Reserve, Home_BUT_Reserve_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_BUT_search, Home_BUT_search_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_BUT_wifi, Home_BUT_wifi_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_BUT_contact, Home_BUT_contact_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_BUT_QR, Home_BUT_QR_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_BUT_video, Home_BUT_video_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_win_wifi_item0, Home_win_wifi_item0_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_win_contact_item0, Home_win_contact_item0_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Home_win_QR_item0, Home_win_QR_item0_event_handler, LV_EVENT_ALL, NULL);
}
static void Video_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Video_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Video(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Video_BUT_back, Video_BUT_back_event_handler, LV_EVENT_ALL, NULL);
}
static void Page_Reserve_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Reserve_del = true;
	    }
		//Write animation: Page_Reserve_contBG scale_width
	  	lv_anim_t Page_Reserve_contBG_anim_scale_width;
	  	lv_anim_init(&Page_Reserve_contBG_anim_scale_width);
	  	lv_anim_set_var(&Page_Reserve_contBG_anim_scale_width, guider_ui.Page_Reserve_contBG);
	  	lv_anim_set_time(&Page_Reserve_contBG_anim_scale_width, 100);
	  	lv_anim_set_delay(&Page_Reserve_contBG_anim_scale_width, 0);
	  	lv_anim_set_exec_cb(&Page_Reserve_contBG_anim_scale_width, (lv_anim_exec_xcb_t)lv_obj_set_width);
		lv_anim_set_values(&Page_Reserve_contBG_anim_scale_width, lv_obj_get_width(guider_ui.Page_Reserve_contBG), 480);
	  	lv_anim_set_path_cb(&Page_Reserve_contBG_anim_scale_width, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Page_Reserve_contBG_anim_scale_width, 0);
	  	lv_anim_set_repeat_delay(&Page_Reserve_contBG_anim_scale_width, 0);
	  	lv_anim_set_playback_time(&Page_Reserve_contBG_anim_scale_width, 0);
	  	lv_anim_set_playback_delay(&Page_Reserve_contBG_anim_scale_width, 0);
		lv_anim_start(&Page_Reserve_contBG_anim_scale_width);
		//Write animation: Page_Reserve_contBG scale_height
	  	lv_anim_t Page_Reserve_contBG_anim_scale_height;
	  	lv_anim_init(&Page_Reserve_contBG_anim_scale_height);
	  	lv_anim_set_var(&Page_Reserve_contBG_anim_scale_height, guider_ui.Page_Reserve_contBG);
	  	lv_anim_set_time(&Page_Reserve_contBG_anim_scale_height, 100);
	  	lv_anim_set_delay(&Page_Reserve_contBG_anim_scale_height, 0);
	  	lv_anim_set_exec_cb(&Page_Reserve_contBG_anim_scale_height, (lv_anim_exec_xcb_t)lv_obj_set_height);
		lv_anim_set_values(&Page_Reserve_contBG_anim_scale_height, lv_obj_get_height(guider_ui.Page_Reserve_contBG), 60);
	  	lv_anim_set_path_cb(&Page_Reserve_contBG_anim_scale_height, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Page_Reserve_contBG_anim_scale_height, 0);
	  	lv_anim_set_repeat_delay(&Page_Reserve_contBG_anim_scale_height, 0);
	  	lv_anim_set_playback_time(&Page_Reserve_contBG_anim_scale_height, 0);
	  	lv_anim_set_playback_delay(&Page_Reserve_contBG_anim_scale_height, 0);
		lv_anim_start(&Page_Reserve_contBG_anim_scale_height);
		break;
	}
	default:
		break;
	}
}
static void Page_Reserve_BUT_store_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Reserve_Storeby_del == true) {
	          setup_scr_Reserve_Storeby(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Reserve_Storeby, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Reserve_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_Reserve_BUT_take_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Reserve_Take_del == true) {
	          setup_scr_Reserve_Take(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Reserve_Take, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Reserve_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_Reserve_BUT_storage_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Reserve_Storage_del == true) {
	          setup_scr_Reserve_Storage(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Reserve_Storage, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Reserve_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Page_Reserve(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Page_Reserve_BUT_back, Page_Reserve_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Reserve_BUT_store, Page_Reserve_BUT_store_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Reserve_BUT_take, Page_Reserve_BUT_take_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Reserve_BUT_storage, Page_Reserve_BUT_storage_event_handler, LV_EVENT_ALL, NULL);
}
static void Reserve_Storeby_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Reserve_del == true) {
	          setup_scr_Page_Reserve(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Reserve, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Storeby_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reserve_Storeby_BUT_Camera_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Reverse_Camera_del == true) {
	          setup_scr_Reverse_Camera(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Reverse_Camera, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Storeby_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reserve_Storeby_BUT_Manual_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Reserve_Manual_del == true) {
	          setup_scr_Reserve_Manual(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Reserve_Manual, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Storeby_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Reserve_Storeby(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Reserve_Storeby_BUT_back, Reserve_Storeby_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Storeby_BUT_Camera, Reserve_Storeby_BUT_Camera_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Storeby_BUT_Manual, Reserve_Storeby_BUT_Manual_event_handler, LV_EVENT_ALL, NULL);
}
static void Reverse_Camera_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Reserve_Storeby_del == true) {
	          setup_scr_Reserve_Storeby(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Reserve_Storeby, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reverse_Camera_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reverse_Camera_BUT_add_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Reverse_Camera_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Reverse_Camera_BUT_home_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reverse_Camera_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reverse_Camera_win_success_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Reverse_Camera_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_Reverse_Camera(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Reverse_Camera_BUT_back, Reverse_Camera_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reverse_Camera_BUT_add, Reverse_Camera_BUT_add_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reverse_Camera_BUT_home, Reverse_Camera_BUT_home_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reverse_Camera_win_success_item0, Reverse_Camera_win_success_item0_event_handler, LV_EVENT_ALL, NULL);
}
static void Reserve_Manual_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Reserve_Storeby_del == true) {
	          setup_scr_Reserve_Storeby(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Reserve_Storeby, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Manual_del = true;
	    }
		//Write animation: Reserve_Manual_contBG scale_width
	  	lv_anim_t Reserve_Manual_contBG_anim_scale_width;
	  	lv_anim_init(&Reserve_Manual_contBG_anim_scale_width);
	  	lv_anim_set_var(&Reserve_Manual_contBG_anim_scale_width, guider_ui.Reserve_Manual_contBG);
	  	lv_anim_set_time(&Reserve_Manual_contBG_anim_scale_width, 100);
	  	lv_anim_set_delay(&Reserve_Manual_contBG_anim_scale_width, 0);
	  	lv_anim_set_exec_cb(&Reserve_Manual_contBG_anim_scale_width, (lv_anim_exec_xcb_t)lv_obj_set_width);
		lv_anim_set_values(&Reserve_Manual_contBG_anim_scale_width, lv_obj_get_width(guider_ui.Reserve_Manual_contBG), 480);
	  	lv_anim_set_path_cb(&Reserve_Manual_contBG_anim_scale_width, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Reserve_Manual_contBG_anim_scale_width, 0);
	  	lv_anim_set_repeat_delay(&Reserve_Manual_contBG_anim_scale_width, 0);
	  	lv_anim_set_playback_time(&Reserve_Manual_contBG_anim_scale_width, 0);
	  	lv_anim_set_playback_delay(&Reserve_Manual_contBG_anim_scale_width, 0);
		lv_anim_start(&Reserve_Manual_contBG_anim_scale_width);
		//Write animation: Reserve_Manual_contBG scale_height
	  	lv_anim_t Reserve_Manual_contBG_anim_scale_height;
	  	lv_anim_init(&Reserve_Manual_contBG_anim_scale_height);
	  	lv_anim_set_var(&Reserve_Manual_contBG_anim_scale_height, guider_ui.Reserve_Manual_contBG);
	  	lv_anim_set_time(&Reserve_Manual_contBG_anim_scale_height, 100);
	  	lv_anim_set_delay(&Reserve_Manual_contBG_anim_scale_height, 0);
	  	lv_anim_set_exec_cb(&Reserve_Manual_contBG_anim_scale_height, (lv_anim_exec_xcb_t)lv_obj_set_height);
		lv_anim_set_values(&Reserve_Manual_contBG_anim_scale_height, lv_obj_get_height(guider_ui.Reserve_Manual_contBG), 60);
	  	lv_anim_set_path_cb(&Reserve_Manual_contBG_anim_scale_height, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Reserve_Manual_contBG_anim_scale_height, 0);
	  	lv_anim_set_repeat_delay(&Reserve_Manual_contBG_anim_scale_height, 0);
	  	lv_anim_set_playback_time(&Reserve_Manual_contBG_anim_scale_height, 0);
	  	lv_anim_set_playback_delay(&Reserve_Manual_contBG_anim_scale_height, 0);
		lv_anim_start(&Reserve_Manual_contBG_anim_scale_height);
		break;
	}
	default:
		break;
	}
}
static void Reserve_Manual_BUT_home_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Manual_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reserve_Manual_BUT_store_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		char name[50] = "";
		char num[5] = "";
		char med[50] = "";
		strcpy(num ,lv_textarea_get_text(guider_ui.Reserve_Manual_INPUT_num));
		strcpy(med ,lv_textarea_get_text(guider_ui.Reserve_Manual_INPUT_medicine));
		lv_dropdown_get_selected_str(guider_ui.Reserve_Manual_INPUT_User, name, 50);
		guider_ui.HistoryData_dose[guider_ui.HistoryData_idx] = atoi(num);
		strcpy(guider_ui.HistoryData_name[guider_ui.HistoryData_idx], name);
		strcpy(guider_ui.HistoryData_medicine[guider_ui.HistoryData_idx], med);
		guider_ui.HistoryData_idx++;
		int isfind = 0;
		for(int i = 0;i < 50;i++)
		{
			if(!strcmp(guider_ui.UserData_medicine[i], med))
			{
				guider_ui.UserData_dose[i] += atoi(num);
				isfind = 1;
				break;
			}
		}
		if(isfind == 0)
		{
			guider_ui.UserData_dose[guider_ui.UserData_medicine_idx] = atoi(num);
			strcpy(guider_ui.UserData_medicine[guider_ui.UserData_medicine_idx] ,med);
			guider_ui.UserData_medicine_idx++;
		}
		lv_obj_clear_flag(guider_ui.Reserve_Manual_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Reserve_Manual_win_success_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Reserve_Manual_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_Reserve_Manual(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Reserve_Manual_BUT_back, Reserve_Manual_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Manual_BUT_home, Reserve_Manual_BUT_home_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Manual_BUT_store, Reserve_Manual_BUT_store_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Manual_win_success_item0, Reserve_Manual_win_success_item0_event_handler, LV_EVENT_ALL, NULL);
	for(int i = 0;i < ui->UserData_name_idx;i++)
		lv_dropdown_add_option(ui->Reserve_Manual_INPUT_User, ui->UserData_name[i], 0);
}
static void Reserve_Take_btn_2_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Reserve_del == true) {
	          setup_scr_Page_Reserve(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Reserve, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Take_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reserve_Take_BUT_home_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Take_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reserve_Take_BUT_take_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
				char name[50] = "";
				char num[3] = "";
				char med[50] = "";
				lv_dropdown_get_selected_str(guider_ui.Reserve_Take_INPUT_medlist, med, 50);
				lv_dropdown_get_selected_str(guider_ui.Reserve_Take_INPUT_User, name, 50);
				lv_dropdown_get_selected_str(guider_ui.Reserve_Take_INPUT_numbers, num, 2);
				guider_ui.HistoryData_dose[guider_ui.HistoryData_idx] = -1*atoi(num);
				strcpy(guider_ui.HistoryData_name[guider_ui.HistoryData_idx], name);
				strcpy(guider_ui.HistoryData_medicine[guider_ui.HistoryData_idx], med);
				guider_ui.HistoryData_idx++;
				for(int i = 0;i < 50;i++)
				{
					if(!strcmp(guider_ui.UserData_medicine[i], med))
					{
						guider_ui.UserData_dose[i] -= atoi(num);
						break;
					}
				}
		lv_obj_clear_flag(guider_ui.Reserve_Take_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Reserve_Take_win_success_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Reserve_Take_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Reserve_Take_win_error_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Reserve_Take_win_error, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_Reserve_Take(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Reserve_Take_btn_2, Reserve_Take_btn_2_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Take_BUT_home, Reserve_Take_BUT_home_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Take_BUT_take, Reserve_Take_BUT_take_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Take_win_success_item0, Reserve_Take_win_success_item0_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Take_win_error_item0, Reserve_Take_win_error_item0_event_handler, LV_EVENT_ALL, NULL);
	for(int i = 0;i < ui->UserData_name_idx;i++)
			lv_dropdown_add_option(ui->Reserve_Take_INPUT_User, ui->UserData_name[i], 0);
	for(int i = 0;i < ui->UserData_medicine_idx;i++)
			lv_dropdown_add_option(ui->Reserve_Take_INPUT_medlist, ui->UserData_medicine[i], 0);
}
static void Reserve_Storage_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Reserve_del == true) {
	          setup_scr_Page_Reserve(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Reserve, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Storage_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Reserve_Storage_BUT_home_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Reserve_Storage_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Reserve_Storage(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Reserve_Storage_BUT_back, Reserve_Storage_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Reserve_Storage_BUT_home, Reserve_Storage_BUT_home_event_handler, LV_EVENT_ALL, NULL);
	for(int i = 0;i < ui->UserData_medicine_idx;i++)
				{
					char str[50] = "";
					char med[6] = "";
					char num[10] = "";
					strcpy(med, guider_ui.UserData_medicine[i]);
					itoa(guider_ui.UserData_dose[i], num, 10);

					strcat(str, med);
					strcat(str, "     ");
					strcat(str, num);

					lv_obj_t * t = lv_list_add_btn(guider_ui.Reserve_Storage_LIST_storagelist, LV_SYMBOL_VOLUME_MAX, str);
					static lv_style_t style;
					lv_style_init(&style);
					lv_style_set_radius(&style, 10);
					lv_style_set_bg_opa(&style, LV_OPA_COVER);
					lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);
					lv_obj_add_style(t, &style, 0);
					lv_obj_add_event_cb(t, event_cb, LV_EVENT_CLICKED, NULL);
				}
	//lv_obj_t * t = lv_list_add_btn(guider_ui.Reserve_Storage_LIST_storagelist, LV_SYMBOL_VOLUME_MAX, guider_ui.UserData_medicine[0]);
}
static void Page_Search_cb_headache_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		if(which[0] == 0)
			which[0] = 1;
		else
			which[0] = 0;
		break;
	}
	default:
		break;
	}
}
static void Page_Search_cb_cough_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		if(which[1] == 0)
			which[1] = 1;
		else
			which[1] = 0;
		break;
	}
	default:
		break;
	}
}
static void Page_Search_cb_stomachache_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{

		if(which[2] == 0)
			which[2] = 1;
		else
			which[2] = 0;
		break;
	}
	default:
		break;
	}
}
static void Page_Search_BUT_Next_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Search_reccomend_del == true) {
	          setup_scr_Search_reccomend(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Search_reccomend, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Search_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_Search_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 400, 200, true);
	        guider_ui.Page_Search_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Page_Search(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Page_Search_cb_headache, Page_Search_cb_headache_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Search_cb_cough, Page_Search_cb_cough_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Search_cb_stomachache, Page_Search_cb_stomachache_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Search_BUT_Next, Page_Search_BUT_Next_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Search_BUT_back, Page_Search_BUT_back_event_handler, LV_EVENT_ALL, NULL);
}
static void Search_reccomend_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Search_reccomend_del = true;
	    }
		//Write animation: Search_reccomend_contBG scale_width
	  	lv_anim_t Search_reccomend_contBG_anim_scale_width;
	  	lv_anim_init(&Search_reccomend_contBG_anim_scale_width);
	  	lv_anim_set_var(&Search_reccomend_contBG_anim_scale_width, guider_ui.Search_reccomend_contBG);
	  	lv_anim_set_time(&Search_reccomend_contBG_anim_scale_width, 100);
	  	lv_anim_set_delay(&Search_reccomend_contBG_anim_scale_width, 0);
	  	lv_anim_set_exec_cb(&Search_reccomend_contBG_anim_scale_width, (lv_anim_exec_xcb_t)lv_obj_set_width);
		lv_anim_set_values(&Search_reccomend_contBG_anim_scale_width, lv_obj_get_width(guider_ui.Search_reccomend_contBG), 480);
	  	lv_anim_set_path_cb(&Search_reccomend_contBG_anim_scale_width, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Search_reccomend_contBG_anim_scale_width, 0);
	  	lv_anim_set_repeat_delay(&Search_reccomend_contBG_anim_scale_width, 0);
	  	lv_anim_set_playback_time(&Search_reccomend_contBG_anim_scale_width, 0);
	  	lv_anim_set_playback_delay(&Search_reccomend_contBG_anim_scale_width, 0);
		lv_anim_start(&Search_reccomend_contBG_anim_scale_width);
		//Write animation: Search_reccomend_contBG scale_height
	  	lv_anim_t Search_reccomend_contBG_anim_scale_height;
	  	lv_anim_init(&Search_reccomend_contBG_anim_scale_height);
	  	lv_anim_set_var(&Search_reccomend_contBG_anim_scale_height, guider_ui.Search_reccomend_contBG);
	  	lv_anim_set_time(&Search_reccomend_contBG_anim_scale_height, 100);
	  	lv_anim_set_delay(&Search_reccomend_contBG_anim_scale_height, 0);
	  	lv_anim_set_exec_cb(&Search_reccomend_contBG_anim_scale_height, (lv_anim_exec_xcb_t)lv_obj_set_height);
		lv_anim_set_values(&Search_reccomend_contBG_anim_scale_height, lv_obj_get_height(guider_ui.Search_reccomend_contBG), 60);
	  	lv_anim_set_path_cb(&Search_reccomend_contBG_anim_scale_height, &lv_anim_path_ease_in);
	  	lv_anim_set_repeat_count(&Search_reccomend_contBG_anim_scale_height, 0);
	  	lv_anim_set_repeat_delay(&Search_reccomend_contBG_anim_scale_height, 0);
	  	lv_anim_set_playback_time(&Search_reccomend_contBG_anim_scale_height, 0);
	  	lv_anim_set_playback_delay(&Search_reccomend_contBG_anim_scale_height, 0);
		lv_anim_start(&Search_reccomend_contBG_anim_scale_height);
		break;
	}
	default:
		break;
	}
}
static void Search_reccomend_BUT_take_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Search_reccomend_window_notice, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Search_reccomend_window_notice_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 100, 10, true);
	        guider_ui.Search_reccomend_del = true;
	    }
		lv_obj_add_flag(guider_ui.Search_reccomend_window_notice, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_Search_reccomend(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Search_reccomend_BUT_back, Search_reccomend_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Search_reccomend_BUT_take, Search_reccomend_BUT_take_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Search_reccomend_window_notice_item0, Search_reccomend_window_notice_item0_event_handler, LV_EVENT_ALL, NULL);

		if(which[0]==1)
		{
			lv_obj_t * t = lv_list_add_btn(guider_ui.Search_reccomend_LIST_suggestedlist, LV_SYMBOL_VOLUME_MAX, "Aspirin");
							static lv_style_t style;
							lv_style_init(&style);
							lv_style_set_radius(&style, 10);
							lv_style_set_bg_opa(&style, LV_OPA_COVER);
							lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);
							lv_obj_add_style(t, &style, 0);
							lv_obj_add_event_cb(t, event_cb, LV_EVENT_CLICKED, NULL);
		}
		if(which[1]==1)
				{
					lv_obj_t * t = lv_list_add_btn(guider_ui.Search_reccomend_LIST_suggestedlist, LV_SYMBOL_VOLUME_MAX, "Penicillin");
									static lv_style_t style;
									lv_style_init(&style);
									lv_style_set_radius(&style, 10);
									lv_style_set_bg_opa(&style, LV_OPA_COVER);
									lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);
									lv_obj_add_style(t, &style, 0);
									lv_obj_add_event_cb(t, event_cb, LV_EVENT_CLICKED, NULL);
				}
		if(which[2]==1)
				{
					lv_obj_t * t = lv_list_add_btn(guider_ui.Search_reccomend_LIST_suggestedlist, LV_SYMBOL_VOLUME_MAX, "Ibuprofen");
									static lv_style_t style;
									lv_style_init(&style);
									lv_style_set_radius(&style, 10);
									lv_style_set_bg_opa(&style, LV_OPA_COVER);
									lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);
									lv_obj_add_style(t, &style, 0);
									lv_obj_add_event_cb(t, event_cb, LV_EVENT_CLICKED, NULL);
				}


}
static void Page_History_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_History_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_History_BUT_take_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_History_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Page_History(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Page_History_BUT_back, Page_History_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_History_BUT_take, Page_History_BUT_take_event_handler, LV_EVENT_ALL, NULL);
	for(int i = ui->HistoryData_idx - 1;i >= 0;i--)
				{
					char str[110] = "";
					char name[50] = "";
					char med[50] = "";
					char num[4] = "";
					strcpy(name, guider_ui.HistoryData_name[i]);
					strcpy(med, guider_ui.HistoryData_medicine[i]);
					itoa(guider_ui.HistoryData_dose[i], num, 10);
					//strcpy(num, guider_ui.HistoryData_dose[i]);

					strcat(str, name);
					strcat(str, "     ");
					strcat(str, med);
					strcat(str, ":");
					strcat(str, num);

					lv_obj_t * t = lv_list_add_btn(guider_ui.Page_History_LIST_suggestedlist, LV_SYMBOL_VOLUME_MAX, str);
					static lv_style_t style;
					lv_style_init(&style);
					lv_style_set_radius(&style, 10);
					lv_style_set_bg_opa(&style, LV_OPA_COVER);
					lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);
					lv_obj_add_style(t, &style, 0);
					lv_obj_add_event_cb(t, event_cb, LV_EVENT_CLICKED, NULL);
				}
}
static void Page_Remind_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Remind_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_Remind_imgbtn_1_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Page_Remind_win_importsuccess, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Page_Remind_BUT_home_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Remind_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_Remind_BUT_Delete_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		if(target != NULL)
		{
			lv_obj_del(target);
			target = NULL;
		    GPIO_PinWrite(GPIO1, 9U, 0U);
		}
		//lv_list_remove(guider_ui.Page_Remind_LIST_remindlist, 1);
		//lv_obj_get_child();
		//Write the load screen code.
	    /*lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Remind_delete_del == true) {
	          setup_scr_Remind_delete(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Remind_delete, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_Remind_del = true;
	    }*/
		break;
	}
	default:
		break;
	}
}
static void Page_Remind_BUT_Add_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		char str[6] = "";
		char hour[3], min[3];
		lv_dropdown_get_selected_str(guider_ui.Page_Remind_INPUT_hour, hour, 3);
		lv_dropdown_get_selected_str(guider_ui.Page_Remind_INPUT_min, min, 3);
		strcat(str, hour);
		strcat(str, ":");
		strcat(str, min);
		lv_obj_t * t = lv_list_add_btn(guider_ui.Page_Remind_LIST_remindlist, LV_SYMBOL_VOLUME_MAX, str);
		static lv_style_t style;
		    lv_style_init(&style);

		    lv_style_set_radius(&style, 10);
		    lv_style_set_bg_opa(&style, LV_OPA_COVER);
	    	lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);

		    lv_obj_add_style(t, &style, 0);
		lv_obj_add_event_cb(t, event_cb_remind, LV_EVENT_CLICKED, NULL);
		strcpy(guider_ui.ReminderData_hour[guider_ui.ReminderData_idx], hour);
		strcpy(guider_ui.ReminderData_minute[guider_ui.ReminderData_idx], min);
		guider_ui.ReminderData_idx++;
		//GPIO_PinWrite(GPIO1, 9U, (isLight)? 0U:1U);
		//isLight = !isLight;
		lv_obj_clear_flag(guider_ui.Page_Remind_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Page_Remind_win_success_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Page_Remind_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Page_Remind_win_importsuccess_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Page_Remind_win_importsuccess, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_Page_Remind(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Page_Remind_BUT_back, Page_Remind_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Remind_imgbtn_1, Page_Remind_imgbtn_1_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Remind_BUT_home, Page_Remind_BUT_home_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Remind_BUT_Delete, Page_Remind_BUT_Delete_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Remind_BUT_Add, Page_Remind_BUT_Add_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Remind_win_success_item0, Page_Remind_win_success_item0_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_Remind_win_importsuccess_item0, Page_Remind_win_importsuccess_item0_event_handler, LV_EVENT_ALL, NULL);
	for(int i = 0;i < ui->UserData_name_idx;i++)
			lv_dropdown_add_option(ui->Page_Remind_INPUT_User, ui->UserData_name[i], 0);
	for(int i = 0;i < ui->UserData_medicine_idx;i++)
			lv_dropdown_add_option(ui->Page_Remind_INPUT_medlist, ui->UserData_medicine[i], 0);
	for(int i = 1;i < ui->ReminderData_idx;i++)
		{
			char str[6] = "";
			strcat(str, ui->ReminderData_hour[i]);
			strcat(str, ":");
			strcat(str, ui->ReminderData_minute[i]);
			lv_obj_t * t = lv_list_add_btn(guider_ui.Page_Remind_LIST_remindlist, LV_SYMBOL_VOLUME_MAX, str);
			static lv_style_t style;
			lv_style_init(&style);
			lv_style_set_radius(&style, 10);
			lv_style_set_bg_opa(&style, LV_OPA_COVER);
			lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);
			lv_obj_add_style(t, &style, 0);
			lv_obj_add_event_cb(t, event_cb, LV_EVENT_CLICKED, NULL);
		}
}
static void Remind_delete_BUT_back2_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Remind_del == true) {
	          setup_scr_Page_Remind(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Remind, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Remind_delete_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Remind_delete_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_Remind_del == true) {
	          setup_scr_Page_Remind(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_Remind, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Remind_delete_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Remind_delete_BUT_Delete_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Remind_delete_win_delete, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Remind_delete_win_delete_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Remind_delete_win_delete, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_Remind_delete(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Remind_delete_BUT_back2, Remind_delete_BUT_back2_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Remind_delete_BUT_back, Remind_delete_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Remind_delete_BUT_Delete, Remind_delete_BUT_Delete_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Remind_delete_win_delete_item0, Remind_delete_win_delete_item0_event_handler, LV_EVENT_ALL, NULL);
}
static void Page_settings_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Home_del == true) {
	          setup_scr_Home(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Home, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_settings_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_settings_BUT_RC_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.ReminderSettings_del == true) {
	          setup_scr_ReminderSettings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.ReminderSettings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_settings_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_settings_BUT_FMM_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.MemberManagement_del == true) {
	          setup_scr_MemberManagement(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.MemberManagement, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_settings_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Page_settings_BUT_Net_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Networksetting_del == true) {
	          setup_scr_Networksetting(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Networksetting, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Page_settings_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Page_settings(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Page_settings_BUT_back, Page_settings_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_settings_BUT_RC, Page_settings_BUT_RC_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_settings_BUT_FMM, Page_settings_BUT_FMM_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Page_settings_BUT_Net, Page_settings_BUT_Net_event_handler, LV_EVENT_ALL, NULL);
}
static void Networksetting_BUT_back2_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_settings_del == true) {
	          setup_scr_Page_settings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_settings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Networksetting_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Networksetting_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_settings_del == true) {
	          setup_scr_Page_settings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_settings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Networksetting_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Networksetting(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Networksetting_BUT_back2, Networksetting_BUT_back2_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Networksetting_BUT_back, Networksetting_BUT_back_event_handler, LV_EVENT_ALL, NULL);
}
static void ReminderSettings_BUT_back2_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_settings_del == true) {
	          setup_scr_Page_settings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_settings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.ReminderSettings_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void ReminderSettings_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_settings_del == true) {
	          setup_scr_Page_settings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_settings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.ReminderSettings_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_ReminderSettings(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->ReminderSettings_BUT_back2, ReminderSettings_BUT_back2_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->ReminderSettings_BUT_back, ReminderSettings_BUT_back_event_handler, LV_EVENT_ALL, NULL);
}
static void MemberManagement_BUT_back2_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_settings_del == true) {
	          setup_scr_Page_settings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_settings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.MemberManagement_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void MemberManagement_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.Page_settings_del == true) {
	          setup_scr_Page_settings(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.Page_settings, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.MemberManagement_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void MemberManagement_BUT_addmember_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.AddMember_del == true) {
	          setup_scr_AddMember(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.AddMember, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.MemberManagement_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_MemberManagement(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->MemberManagement_BUT_back2, MemberManagement_BUT_back2_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->MemberManagement_BUT_back, MemberManagement_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->MemberManagement_BUT_addmember, MemberManagement_BUT_addmember_event_handler, LV_EVENT_ALL, NULL);
	for(int i = 0;i < ui->UserData_name_idx;i++)
			{
				char str[50] = "";
				char name[30] = "";
				char years[8] = "";
				char gender[8] = "";
				strcpy(name, guider_ui.UserData_name[i]);
				strcpy(years, guider_ui.UserData_age[i]);
				strcpy(gender, guider_ui.UserData_gender[i]);

				strcat(str, name);
				strcat(str, "     ");
				strcat(str, years);
				strcat(str, "     ");
				strcat(str, gender);

				lv_obj_t * t = lv_list_add_btn(guider_ui.MemberManagement_LIST_userlist, LV_SYMBOL_VOLUME_MAX, str);
				static lv_style_t style;
				lv_style_init(&style);
				lv_style_set_radius(&style, 10);
				lv_style_set_bg_opa(&style, LV_OPA_COVER);
				lv_obj_set_style_bg_color(t, lv_color_hex(0xFFFFFF), 0);
				lv_obj_add_style(t, &style, 0);
				lv_obj_add_event_cb(t, event_cb, LV_EVENT_CLICKED, NULL);
			}
}
static void AddMember_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.MemberManagement_del == true) {
	          setup_scr_MemberManagement(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.MemberManagement, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.AddMember_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void AddMember_BUT_Add_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
				char name[50], gender[8], age[4];
				strcpy(name ,lv_textarea_get_text(guider_ui.AddMember_INPUT_Name));
				strcpy(age ,lv_textarea_get_text(guider_ui.AddMember_INPUT_Age));
				lv_dropdown_get_selected_str(guider_ui.AddMember_INPUT_Gender, gender, 8);
				strcat(guider_ui.UserData_name[guider_ui.UserData_name_idx], name);
				strcat(guider_ui.UserData_age[guider_ui.UserData_name_idx] ,  age);
				strcat(guider_ui.UserData_gender[guider_ui.UserData_name_idx] ,  gender);
				guider_ui.UserData_name_idx++;
				//GPIO_PinWrite(GPIO1, 9U, (isLight)? 0U:1U);
				//isLight = !isLight;
		lv_obj_clear_flag(guider_ui.AddMember_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void AddMember_win_success_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.AddMember_win_success, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
void events_init_AddMember(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->AddMember_BUT_back, AddMember_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->AddMember_BUT_Add, AddMember_BUT_Add_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->AddMember_win_success_item0, AddMember_win_success_item0_event_handler, LV_EVENT_ALL, NULL);
}
static void Modifymember_BUT_back_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.MemberManagement_del == true) {
	          setup_scr_MemberManagement(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.MemberManagement, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Modifymember_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
static void Modifymember_BUT_Save_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Modifymember_win_save, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Modifymember_BUT_deletemember_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_clear_flag(guider_ui.Modifymember_win_delete, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Modifymember_win_save_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Modifymember_win_save, LV_OBJ_FLAG_HIDDEN);
		break;
	}
	default:
		break;
	}
}
static void Modifymember_win_delete_item0_event_handler (lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);

	switch (code) {
	case LV_EVENT_CLICKED:
	{
		lv_obj_add_flag(guider_ui.Modifymember_win_delete, LV_OBJ_FLAG_HIDDEN);
		//Write the load screen code.
	    lv_obj_t * act_scr = lv_scr_act();
	    lv_disp_t * d = lv_obj_get_disp(act_scr);
	    if (d->prev_scr == NULL && (d->scr_to_load == NULL || d->scr_to_load == act_scr)) {
	        if (guider_ui.MemberManagement_del == true) {
	          setup_scr_MemberManagement(&guider_ui);
	        }
	        lv_scr_load_anim(guider_ui.MemberManagement, LV_SCR_LOAD_ANIM_FADE_ON, 200, 200, true);
	        guider_ui.Modifymember_del = true;
	    }
		break;
	}
	default:
		break;
	}
}
void events_init_Modifymember(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->Modifymember_BUT_back, Modifymember_BUT_back_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Modifymember_BUT_Save, Modifymember_BUT_Save_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Modifymember_BUT_deletemember, Modifymember_BUT_deletemember_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Modifymember_win_save_item0, Modifymember_win_save_item0_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->Modifymember_win_delete_item0, Modifymember_win_delete_item0_event_handler, LV_EVENT_ALL, NULL);
}

void events_init(lv_ui *ui)
{

}
