/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Networksetting(lv_ui *ui)
{
	//Write codes Networksetting
	ui->Networksetting = lv_obj_create(NULL);
	ui->g_kb_Networksetting = lv_keyboard_create(ui->Networksetting);
	lv_obj_add_event_cb(ui->g_kb_Networksetting, kb_event_cb, LV_EVENT_ALL, NULL);
	lv_obj_add_flag(ui->g_kb_Networksetting, LV_OBJ_FLAG_HIDDEN);
	lv_obj_set_style_text_font(ui->g_kb_Networksetting, &lv_font_simsun_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_size(ui->Networksetting, 480, 272);

	//Write style for Networksetting, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Networksetting, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Networksetting, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_contBG
	ui->Networksetting_contBG = lv_obj_create(ui->Networksetting);
	lv_obj_set_pos(ui->Networksetting_contBG, 0, 0);
	lv_obj_set_size(ui->Networksetting_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Networksetting_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Networksetting_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Networksetting_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Networksetting_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Networksetting_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_BUT_back2
	ui->Networksetting_BUT_back2 = lv_btn_create(ui->Networksetting_contBG);
	ui->Networksetting_BUT_back2_label = lv_label_create(ui->Networksetting_BUT_back2);
	lv_label_set_text(ui->Networksetting_BUT_back2_label, "<");
	lv_label_set_long_mode(ui->Networksetting_BUT_back2_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Networksetting_BUT_back2_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Networksetting_BUT_back2, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Networksetting_BUT_back2, 24, 17);
	lv_obj_set_size(ui->Networksetting_BUT_back2, 35, 32);

	//Write style for Networksetting_BUT_back2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Networksetting_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Networksetting_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_BUT_back2, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_BUT_back2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Networksetting_BUT_back2, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_BUT_back2, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_BUT_back2, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_text_title
	ui->Networksetting_text_title = lv_label_create(ui->Networksetting_contBG);
	lv_label_set_text(ui->Networksetting_text_title, "Network Settings");
	lv_label_set_long_mode(ui->Networksetting_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Networksetting_text_title, 79, 22);
	lv_obj_set_size(ui->Networksetting_text_title, 323, 32);

	//Write style for Networksetting_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Networksetting_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_BUT_back
	ui->Networksetting_BUT_back = lv_btn_create(ui->Networksetting);
	ui->Networksetting_BUT_back_label = lv_label_create(ui->Networksetting_BUT_back);
	lv_label_set_text(ui->Networksetting_BUT_back_label, "Save");
	lv_label_set_long_mode(ui->Networksetting_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Networksetting_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Networksetting_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Networksetting_BUT_back, 366, 224);
	lv_obj_set_size(ui->Networksetting_BUT_back, 100, 37);

	//Write style for Networksetting_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Networksetting_BUT_back, 206, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Networksetting_BUT_back, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Networksetting_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_BUT_back, 17, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Networksetting_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_BUT_back, &lv_font_montserratMedium_18, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_text_ps
	ui->Networksetting_text_ps = lv_label_create(ui->Networksetting);
	lv_label_set_text(ui->Networksetting_text_ps, "Password");
	lv_label_set_long_mode(ui->Networksetting_text_ps, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Networksetting_text_ps, 67, 138);
	lv_obj_set_size(ui->Networksetting_text_ps, 86, 20);

	//Write style for Networksetting_text_ps, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Networksetting_text_ps, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_text_ps, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_text_ps, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_text_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_text_ssid
	ui->Networksetting_text_ssid = lv_label_create(ui->Networksetting);
	lv_label_set_text(ui->Networksetting_text_ssid, "SSID");
	lv_label_set_long_mode(ui->Networksetting_text_ssid, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Networksetting_text_ssid, 72, 102);
	lv_obj_set_size(ui->Networksetting_text_ssid, 87, 20);

	//Write style for Networksetting_text_ssid, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Networksetting_text_ssid, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_text_ssid, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_text_ssid, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_text_ssid, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_text_cps
	ui->Networksetting_text_cps = lv_label_create(ui->Networksetting);
	lv_label_set_text(ui->Networksetting_text_cps, "Comfirmed Password");
	lv_label_set_long_mode(ui->Networksetting_text_cps, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Networksetting_text_cps, 67, 174);
	lv_obj_set_size(ui->Networksetting_text_cps, 184, 35);

	//Write style for Networksetting_text_cps, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Networksetting_text_cps, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_text_cps, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_text_cps, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_text_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Networksetting_INPUT_cps
	ui->Networksetting_INPUT_cps = lv_textarea_create(ui->Networksetting);
	lv_textarea_set_text(ui->Networksetting_INPUT_cps, "");
	lv_textarea_set_password_bullet(ui->Networksetting_INPUT_cps, "*");
	lv_textarea_set_password_mode(ui->Networksetting_INPUT_cps, true);
	lv_textarea_set_one_line(ui->Networksetting_INPUT_cps, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->Networksetting_INPUT_cps, ta_event_cb, LV_EVENT_ALL, ui->g_kb_Networksetting);
	#endif
	lv_obj_set_pos(ui->Networksetting_INPUT_cps, 262, 167);
	lv_obj_set_size(ui->Networksetting_INPUT_cps, 168, 28);

	//Write style for Networksetting_INPUT_cps, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Networksetting_INPUT_cps, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_INPUT_cps, &lv_font_montserratMedium_14, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Networksetting_INPUT_cps, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_INPUT_cps, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_INPUT_cps, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Networksetting_INPUT_cps, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Networksetting_INPUT_cps, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Networksetting_INPUT_cps, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Networksetting_INPUT_cps, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Networksetting_INPUT_cps, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_INPUT_cps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_INPUT_cps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_INPUT_cps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_INPUT_cps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_INPUT_cps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Networksetting_INPUT_cps, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Networksetting_INPUT_cps, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_INPUT_cps, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Networksetting_INPUT_ps
	ui->Networksetting_INPUT_ps = lv_textarea_create(ui->Networksetting);
	lv_textarea_set_text(ui->Networksetting_INPUT_ps, "");
	lv_textarea_set_password_bullet(ui->Networksetting_INPUT_ps, "*");
	lv_textarea_set_password_mode(ui->Networksetting_INPUT_ps, true);
	lv_textarea_set_one_line(ui->Networksetting_INPUT_ps, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->Networksetting_INPUT_ps, ta_event_cb, LV_EVENT_ALL, ui->g_kb_Networksetting);
	#endif
	lv_obj_set_pos(ui->Networksetting_INPUT_ps, 262, 130);
	lv_obj_set_size(ui->Networksetting_INPUT_ps, 168, 28);

	//Write style for Networksetting_INPUT_ps, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Networksetting_INPUT_ps, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_INPUT_ps, &lv_font_montserratMedium_14, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Networksetting_INPUT_ps, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_INPUT_ps, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_INPUT_ps, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Networksetting_INPUT_ps, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Networksetting_INPUT_ps, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Networksetting_INPUT_ps, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Networksetting_INPUT_ps, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Networksetting_INPUT_ps, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_INPUT_ps, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_INPUT_ps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_INPUT_ps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_INPUT_ps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_INPUT_ps, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Networksetting_INPUT_ps, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Networksetting_INPUT_ps, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_INPUT_ps, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Write codes Networksetting_INPUT_SSID
	ui->Networksetting_INPUT_SSID = lv_textarea_create(ui->Networksetting);
	lv_textarea_set_text(ui->Networksetting_INPUT_SSID, "");
	lv_textarea_set_password_bullet(ui->Networksetting_INPUT_SSID, "*");
	lv_textarea_set_password_mode(ui->Networksetting_INPUT_SSID, false);
	lv_textarea_set_one_line(ui->Networksetting_INPUT_SSID, true);
	#if LV_USE_KEYBOARD != 0 || LV_USE_ZH_KEYBOARD != 0
		lv_obj_add_event_cb(ui->Networksetting_INPUT_SSID, ta_event_cb, LV_EVENT_ALL, ui->g_kb_Networksetting);
	#endif
	lv_obj_set_pos(ui->Networksetting_INPUT_SSID, 262, 94);
	lv_obj_set_size(ui->Networksetting_INPUT_SSID, 168, 28);

	//Write style for Networksetting_INPUT_SSID, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Networksetting_INPUT_SSID, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Networksetting_INPUT_SSID, &lv_font_montserratMedium_14, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Networksetting_INPUT_SSID, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Networksetting_INPUT_SSID, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Networksetting_INPUT_SSID, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Networksetting_INPUT_SSID, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Networksetting_INPUT_SSID, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->Networksetting_INPUT_SSID, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->Networksetting_INPUT_SSID, lv_color_hex(0xe6e6e6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->Networksetting_INPUT_SSID, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Networksetting_INPUT_SSID, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Networksetting_INPUT_SSID, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Networksetting_INPUT_SSID, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Networksetting_INPUT_SSID, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_INPUT_SSID, 4, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Networksetting_INPUT_SSID, Part: LV_PART_SCROLLBAR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Networksetting_INPUT_SSID, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Networksetting_INPUT_SSID, 0, LV_PART_SCROLLBAR|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Networksetting);

	
	//Init events for screen.
	events_init_Networksetting(ui);
}
