/*
* Copyright 2023 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"


void setup_scr_Reserve_Storeby(lv_ui *ui)
{
	//Write codes Reserve_Storeby
	ui->Reserve_Storeby = lv_obj_create(NULL);
	lv_obj_set_size(ui->Reserve_Storeby, 480, 272);

	//Write style for Reserve_Storeby, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Storeby, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Storeby, lv_color_hex(0xF3F8FE), LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storeby_contBG
	ui->Reserve_Storeby_contBG = lv_obj_create(ui->Reserve_Storeby);
	lv_obj_set_pos(ui->Reserve_Storeby_contBG, 0, 0);
	lv_obj_set_size(ui->Reserve_Storeby_contBG, 480, 60);
	lv_obj_set_scrollbar_mode(ui->Reserve_Storeby_contBG, LV_SCROLLBAR_MODE_OFF);

	//Write style for Reserve_Storeby_contBG, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Storeby_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storeby_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Storeby_contBG, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->Reserve_Storeby_contBG, lv_color_hex(0x190482), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Storeby_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Storeby_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Storeby_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Storeby_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_contBG, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storeby_text_title
	ui->Reserve_Storeby_text_title = lv_label_create(ui->Reserve_Storeby);
	lv_label_set_text(ui->Reserve_Storeby_text_title, "Storing by...");
	lv_label_set_long_mode(ui->Reserve_Storeby_text_title, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Storeby_text_title, 135, 23);
	lv_obj_set_size(ui->Reserve_Storeby_text_title, 210, 32);

	//Write style for Reserve_Storeby_text_title, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_text_title, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_text_title, &lv_font_montserratMedium_20, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Storeby_text_title, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storeby_text_title, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_text_title, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storeby_BUT_back
	ui->Reserve_Storeby_BUT_back = lv_btn_create(ui->Reserve_Storeby);
	ui->Reserve_Storeby_BUT_back_label = lv_label_create(ui->Reserve_Storeby_BUT_back);
	lv_label_set_text(ui->Reserve_Storeby_BUT_back_label, "<");
	lv_label_set_long_mode(ui->Reserve_Storeby_BUT_back_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Storeby_BUT_back_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Storeby_BUT_back, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Storeby_BUT_back, 25, 17);
	lv_obj_set_size(ui->Reserve_Storeby_BUT_back, 35, 32);

	//Write style for Reserve_Storeby_BUT_back, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->Reserve_Storeby_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->Reserve_Storeby_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storeby_BUT_back, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_BUT_back, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_BUT_back, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_BUT_back, &lv_font_montserratMedium_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storeby_BUT_back, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storeby_BUT_Camera
	ui->Reserve_Storeby_BUT_Camera = lv_imgbtn_create(ui->Reserve_Storeby);
	lv_obj_add_flag(ui->Reserve_Storeby_BUT_Camera, LV_OBJ_FLAG_CHECKABLE);
	lv_imgbtn_set_src(ui->Reserve_Storeby_BUT_Camera, LV_IMGBTN_STATE_RELEASED, NULL, &_camera_alpha_102x89, NULL);
	ui->Reserve_Storeby_BUT_Camera_label = lv_label_create(ui->Reserve_Storeby_BUT_Camera);
	lv_label_set_text(ui->Reserve_Storeby_BUT_Camera_label, "");
	lv_label_set_long_mode(ui->Reserve_Storeby_BUT_Camera_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Storeby_BUT_Camera_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Storeby_BUT_Camera, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Storeby_BUT_Camera, 105, 111);
	lv_obj_set_size(ui->Reserve_Storeby_BUT_Camera, 102, 89);

	//Write style for Reserve_Storeby_BUT_Camera, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reserve_Storeby_BUT_Camera, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_BUT_Camera, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storeby_BUT_Camera, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_BUT_Camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Reserve_Storeby_BUT_Camera, Part: LV_PART_MAIN, State: LV_STATE_PRESSED.
	lv_obj_set_style_img_opa(ui->Reserve_Storeby_BUT_Camera, 255, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_BUT_Camera, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_BUT_Camera, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_BUT_Camera, 0, LV_PART_MAIN|LV_STATE_PRESSED);

	//Write style for Reserve_Storeby_BUT_Camera, Part: LV_PART_MAIN, State: LV_STATE_CHECKED.
	lv_obj_set_style_img_opa(ui->Reserve_Storeby_BUT_Camera, 255, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_BUT_Camera, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_BUT_Camera, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_BUT_Camera, 0, LV_PART_MAIN|LV_STATE_CHECKED);

	//Write style for Reserve_Storeby_BUT_Camera, Part: LV_PART_MAIN, State: LV_IMGBTN_STATE_RELEASED.
	lv_obj_set_style_img_opa(ui->Reserve_Storeby_BUT_Camera, 255, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);

	//Write codes Reserve_Storeby_text_camera
	ui->Reserve_Storeby_text_camera = lv_label_create(ui->Reserve_Storeby);
	lv_label_set_text(ui->Reserve_Storeby_text_camera, "Camera\n");
	lv_label_set_long_mode(ui->Reserve_Storeby_text_camera, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Storeby_text_camera, 99, 211);
	lv_obj_set_size(ui->Reserve_Storeby_text_camera, 108, 14);

	//Write style for Reserve_Storeby_text_camera, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_text_camera, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_text_camera, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Storeby_text_camera, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storeby_text_camera, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_text_camera, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes Reserve_Storeby_BUT_Manual
	ui->Reserve_Storeby_BUT_Manual = lv_imgbtn_create(ui->Reserve_Storeby);
	lv_obj_add_flag(ui->Reserve_Storeby_BUT_Manual, LV_OBJ_FLAG_CHECKABLE);
	lv_imgbtn_set_src(ui->Reserve_Storeby_BUT_Manual, LV_IMGBTN_STATE_RELEASED, NULL, &_hand_alpha_105x110, NULL);
	ui->Reserve_Storeby_BUT_Manual_label = lv_label_create(ui->Reserve_Storeby_BUT_Manual);
	lv_label_set_text(ui->Reserve_Storeby_BUT_Manual_label, "");
	lv_label_set_long_mode(ui->Reserve_Storeby_BUT_Manual_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->Reserve_Storeby_BUT_Manual_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->Reserve_Storeby_BUT_Manual, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->Reserve_Storeby_BUT_Manual, 291, 90);
	lv_obj_set_size(ui->Reserve_Storeby_BUT_Manual, 105, 110);

	//Write style for Reserve_Storeby_BUT_Manual, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->Reserve_Storeby_BUT_Manual, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_BUT_Manual, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storeby_BUT_Manual, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_BUT_Manual, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for Reserve_Storeby_BUT_Manual, Part: LV_PART_MAIN, State: LV_STATE_PRESSED.
	lv_obj_set_style_img_opa(ui->Reserve_Storeby_BUT_Manual, 255, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_BUT_Manual, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_BUT_Manual, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_PRESSED);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_BUT_Manual, 0, LV_PART_MAIN|LV_STATE_PRESSED);

	//Write style for Reserve_Storeby_BUT_Manual, Part: LV_PART_MAIN, State: LV_STATE_CHECKED.
	lv_obj_set_style_img_opa(ui->Reserve_Storeby_BUT_Manual, 255, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_BUT_Manual, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_BUT_Manual, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_BUT_Manual, 0, LV_PART_MAIN|LV_STATE_CHECKED);

	//Write style for Reserve_Storeby_BUT_Manual, Part: LV_PART_MAIN, State: LV_IMGBTN_STATE_RELEASED.
	lv_obj_set_style_img_opa(ui->Reserve_Storeby_BUT_Manual, 255, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);

	//Write codes Reserve_Storeby_text_take
	ui->Reserve_Storeby_text_take = lv_label_create(ui->Reserve_Storeby);
	lv_label_set_text(ui->Reserve_Storeby_text_take, "Manual");
	lv_label_set_long_mode(ui->Reserve_Storeby_text_take, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->Reserve_Storeby_text_take, 306, 209);
	lv_obj_set_size(ui->Reserve_Storeby_text_take, 74, 16);

	//Write style for Reserve_Storeby_text_take, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->Reserve_Storeby_text_take, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->Reserve_Storeby_text_take, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->Reserve_Storeby_text_take, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->Reserve_Storeby_text_take, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->Reserve_Storeby_text_take, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update current screen layout.
	lv_obj_update_layout(ui->Reserve_Storeby);

	
	//Init events for screen.
	events_init_Reserve_Storeby(ui);
}
